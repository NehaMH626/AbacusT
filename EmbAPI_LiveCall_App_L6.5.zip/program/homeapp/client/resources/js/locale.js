/* Copyright(c) 2015-2016 TOSHIBA TEC CORPORATION, All Rights Reserved. */

App.Locale = (function (global, $, undefined) {

    /* ------------------------------------------------- */
    /* MESSAGES */
    /* 
        Different language supported are
        
        English
        Japanese
    */
    /* ------------------------------------------------- */

    var messages = {
        // English
        en_US: {
            code000: 'Event Data',
            code001: 'Clear',
            code002: 'Refresh'
            
        },

        // Japanese
        ja_JP: {
            code000:  'Event Data',
            code001: 'Clear',
            code002: 'Refresh'
        }
    };


    /* ------------------------------------------------- */
    /* MODULE APIs */
    /* ------------------------------------------------- */

    return {
        messages: messages
    };

})(window, jQuery);
