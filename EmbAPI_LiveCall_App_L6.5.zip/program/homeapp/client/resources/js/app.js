/* Copyright(c) 2015-2016 TOSHIBA TEC CORPORATION, All Rights Reserved. */

var App = (function (global, $, undefined) {

    /* ------------------------------------------------- */
    /* APP SPECIFIC VARIABLES */
    /* ------------------------------------------------- */

    var appId = '00cdefbb-068b-11e6-9463-ffffffffff00';
    var appToken = {};
    var appLanguage = 'en_US'; //Deafult language is en_US

    /* ------------------------------------------------- */
    /* APPLICATION INITIALIZATION */
    /* ------------------------------------------------- */
    function getCookie(name) {
        var value = "; " + document.cookie;
        var parts = value.split("; " + name + "=");
        if (parts.length === 2) return parts.pop().split(";").shift();
    }

    var init = function () {
        console.log('Application initialized...');
        var location = '';
        var arr = [];

        /* Extract the access token and appId from the query string and save it 
        in a scope that other parts of the application can access */

        App.appToken['X-WebAPI-AccessToken'] = getCookie('accessToken');
        console.log("X-WebAPI-AccessToken-");
        console.log(App.appToken['X-WebAPI-AccessToken']);
        App.Util.updateMessages();
        App.Home.show();

        /* Set the servlet context root and other servlet URLs */
        if (App.appId) {
            App.URL.setServletContextRoot(App.appId);
        }

        /* Subscribe for SSE events */
        App.Util.subscribeSSE();
        /* Event subscriptions */
        /* This section contains all the event subscriptions that the app needs */
    };

    /* ------------------------------------------------- */
    /* MODULE PUBLIC APIs */
    /* ------------------------------------------------- */

    return {
        init: init,
        appId: appId,
        appToken: appToken,
        appLanguage: appLanguage,
    };
}(window, jQuery));
