App.Home = (function (global, $, undefined) {

    /* --------------------------- clear data button click event ---------------------------*/

    $("#clearData").click(function () {
        $("#eventPanel").empty();
    });

    var show = function () {

        App.Util.serverRequest('/server/' + App.appId + "/updateConfig", "POST", true, function (response) {
            if (response) {
                console.log(JSON.stringify(response));
            } else {
                console.log("error at UpadateConfig HomeApp");
            }
        }, {
            "X-WebAPI-AccessToken": App.appToken['X-WebAPI-AccessToken']
        });

    };
    return {
        show: show
    };

})(window, jQuery);