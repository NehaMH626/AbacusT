#!/usr/bin/env python
#-*- coding: utf-8 -*-
from pyramid.view import view_config
from pyramid.response import Response
import json
import requests
import os
import re
import logging
from hmserver.apps.common.logger import logger_obj
from hmserver.apps.common.eventmanagement.eventhandler import EventHandler

webapi_server = "embapp-local.toshibatec.co.jp"
webapi_port = "50187"

log = logging.getLogger("homeserver")


@view_config(route_name='updateConfig', xhr=True, renderer='jsonp')
def updateConfig(request):

    setdata = request.json
    logger_obj.log(str(setdata))
    param = setdata["X-WebAPI-AccessToken"]
    post_data = {"type": "string", "section": "Config",
                 "name": "HomeApp", "value": param}
    logger_obj.log(str(post_data))
    headers = {"X-WebAPI-AccessToken": request.headers["X-WebAPI-AccessToken"]}
    response = requests.post(
        "http://" + webapi_server + ":" + webapi_port + "/v1.0/app/config", headers=headers, data=json.dumps(post_data))
    logger_obj.log(str(response.text))
    return response.json()


@view_config(route_name='test_callback', renderer='jsonp')
def callback1(request):
    try:
        
        headers = {"X-Webapi-Accesstoken": request.headers['X-Webapi-Accesstoken']}
        logger_obj.log("Entered webhooks callback and the params received are:")
        logger_obj.log(request.json_body)
        data = request.json_body
        
        #data["event_name"]="sendNotificationFromServer"
        
        
        logger_obj.log(data)
        logger_obj.log(str(data["event_name"]))
        
        
        EH = EventHandler()
        EH.sendNotification(request.headers['X-Webapi-Accesstoken'], data)
        return data
    
    except Exception as err:
        logger_obj.log(str(err),log_level='exception')