/* Copyright(c) 2015-2016 TOSHIBA TEC CORPORATION, All Rights Reserved. */

App.Locale = (function (global, $, undefined) {

    /* ------------------------------------------------- */
    /* MESSAGES */
    /* -------------------------------------------------*/
    

    var messages = {
        // English
        en_US: {
            code000: '',
           
        },

        // Japanese
        ja_JP: {
            code000: '',
           
           
        }
    };


    /* ------------------------------------------------- */
    /* MODULE APIs */
    /* ------------------------------------------------- */

    return {
        messages: messages
    };

})(window, jQuery);
