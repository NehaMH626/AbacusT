App.Home = (function (global, $, undefined) {

    /*----------------------------------------------*/
    /*-----------    INITIALIZE VARIABLES  ---------*/
    /*----------------------------------------------*/
    //    var paths;
    var _selectedCategoryName;
    var objExport;
    var uniqueIdFinal;
    var httpCodeValidationResult;
    var httpResponseValidationResult;
    var httpSchemaValidationResult;
    var response_schema;
    var paths;
    var _init = function () {

    };
    var _show = function () {

    };

    var _initialDisplay = function () {
        _populateCategories();
        _getUrlMethodDetails();

    };

    /*-------Handlebars Import Screen Start-----*/
    // Grab the template script
    var theTemplateImport = $("#template-import-screen").html();
    // Compile the template
    var theTemplateImport = Handlebars.compile(theTemplateImport);

    /*-------Handlebars Import Screen End-----*/

    /*-------get category list ---------*/
    var _populateCategories = function () {
        for (var categoryName in App.categoryPathMethodMap) {
            //  console.log(categoryName);
            $("#sidebar").append("<li><a href='#' data-target-id='" + categoryName + "'>" + categoryName + "</a></li>")
                //    var value = categoryPathMethodMap[name];
        }
//        $("#sidebar").append("<ul class='sidebar-nav'><li class='sidebar-brand'>Import Test Case</li><li><a href='#' data-target-id='import_screen' class='noborder'><button type='button' class='btn btn-warning' id='import_btn'>Import</button></a></li></ul>");
        $("ul.nav-pills li:first-child a").click();

    };

    $(".clear-console-btn").on("click", function () {
        $("#global-console-wrapper .panel-body p").empty();
    });


    $("#sidebar").on("click", "a", function () {
        $(".row").empty();
        _selectedCategoryName = $(this).closest("a").text();

        //console.log(_selectedCategoryName);

        $(".row").append("<div class='col-sm-12 col-md-12 col-lg-12 admin-content' id='" + _selectedCategoryName + "'><p class='h4 text-primary'>" + _selectedCategoryName + "</p><div class='panel-group' id='accordion-" + _selectedCategoryName + "'></div></div>");
        //if (_selectedCategoryName !== "Import") {
        if (!$(this).closest('li').hasClass('active')) {
            $(this).closest('ul').find('.active').removeClass('active');
            $(this).closest('li').addClass('active');
        }

        var parser = new SwaggerParser();
        parser.dereference("vendors/js/swagger.json")
            .then(function (api) {
                var paths = api.paths;
                console.log(paths);
                if (_selectedCategoryName !== "Import") {

                    $.each(App.categoryPathMethodMap[_selectedCategoryName], function (index, value) {
                        var url = index;
                        $.each(value, function (index1, value1) {
                            var method = value1;
                            if ((method) == "post") {
                                var lbClass = "label-success";
                                var txtRight = "text-right-success";
                            } else if ((method) == "get") {
                                var lbClass = "label-primary";
                                var txtRight = "text-right-primary";
                            } else if ((method) == "delete") {
                                var lbClass = "label-danger";
                                var txtRight = "text-right-danger";
                            } else if ((method) == "put") {
                                var lbClass = "label-warning";
                                var txtRight = "text-right-warning";
                            } else if ((method) == "patch") {
                                var lbClass = "label-info";
                                var txtRight = "text-right-info";
                            }
                            var uniqueId = method + url;
                            var uniqueIdModified = uniqueId.replace(/[^a-zA-Z0-9]/g, '-');
                            var uniqueIdFinal = uniqueIdModified.replace(/--/g, '-');
                            $('#accordion-' + _selectedCategoryName).append("<div class='panel panel-default'><div class='panel-heading' data-toggle='collapse' data-parent='#accordion-" + _selectedCategoryName + "' data-target='#collapse-" + uniqueIdFinal + "' id=" + uniqueIdFinal + "><h4 class='panel-title'><span class='label " + lbClass + "'>" + method + "</span><a> " + url + " <p class='panel-title pull-right " + txtRight + "'>" + paths[url][method]['summary'] + "</p></a></h4></div><div id='collapse-" + uniqueIdFinal + "' class='panel-collapse collapse'><div class='panel-body'></div></div></div>");

                            $("#collapse-" + uniqueIdFinal).on('show.bs.collapse', function (e) {
                                _getUrlMethodDetails(url, method, uniqueIdFinal);

                            });


                            //---- clear all checkboxes when panel is closed--------------------
                            $("#collapse-" + uniqueIdFinal).on('hidden.bs.collapse', function (e) {
                                $('input:checkbox').removeAttr('checked');

                            });
                            //--------------------------------------------------------------------------
                            var lbClass = null;
                            var txtRight = null;
                        });
                    });
                } else {
                    $('#accordion-' + _selectedCategoryName).append(theTemplateImport);
                    App.Import.show(paths);
                }
            })
            .catch(function (err) {
                console.error('The API is invalid. ' + err.message);
            });

    });


    //-----------------------------------------------------------------------------------------------------------------------------
    var _getUrlMethodDetails = function (url, method, uniqueIdFinal, ) {
        var parser = new SwaggerParser();
        parser.dereference("vendors/js/swagger.json")
            .then(function (api) {
                paths = api.paths;
                var urlMethodsDetails = paths[url][method];
                var description = paths[url][method]["description"];
                var produces = paths[url][method]["produces"][0];
                var responses = paths[url][method]["responses"];
                var parameters = paths[url][method]["parameters"];

                /*------------------- mandatory fields-----------------------------------------------*/
                Handlebars.registerHelper("ifvalue", function (conditional, options) {
                    if (conditional == options.hash.equals) {
                        return options.fn(this);
                    } else {
                        return options.inverse(this);
                    }
                });
                //-------------------------------------------------------------------------------
                if ((method == "get") || (method == "delete")) {
                    // console.log(JSON.stringify(urlParam,null, 4));
                    var theTemplateScriptGetDelete = $("#template-get-delete").html();
                    var theTemplateGetDelete = Handlebars.compile(theTemplateScriptGetDelete);
                    var theCompiledHtmlGetDelete = theTemplateGetDelete(urlMethodsDetails);
                    $('#collapse-' + uniqueIdFinal + " .panel-body").html(theCompiledHtmlGetDelete);
                    $('#collapse-' + uniqueIdFinal + " .panel-body").find('table').attr("id", "tbl-" + uniqueIdFinal);

                    //-----------------------------------------------------------------------------------------------------------------
                    /*-------------ajax call execute button click------------------------------------*/
                    $('.ajax-btn').on('click', function () {
                        //console.log("in parameter is" + paths[url][method]["parameters"][i].in);
                        _ajaxCall(url, method, urlMethodsDetails, uniqueIdFinal);
                    });

                    //-----------------------------------------------------------------------------------------------------------
                    // *---------------------------- verify schema button click------------------------------
                    $(".verify-schema").on("click", function () {
                        _responseSchema(url, method, urlMethodsDetails, uniqueIdFinal);
                    });
                    //---------------------------------------------------------------------------------------


                    //loading js from customscript.js-----------------------------------------------------------

                    loadJsGetDelete(uniqueIdFinal);
                    //-----------------------------------------------------------------------------------------

                } else if ((method == "post") || (method == "put") || (method == "patch")) {

                    // Register a helper
                    //                      Handlebars.registerHelper('equals', function (v1,v2) {
                    //                         return (v1 === v2);
                    //                    });

                    // Grab the template script
                    var theTemplateScriptPostPutPatch = $("#template-post-put-patch").html();

                    // Compile the template
                    var theTemplatePostPutPatch = Handlebars.compile(theTemplateScriptPostPutPatch);



                    // Pass our data to the template


                    //script to chk json payload data and properties in parameters
                    if (urlMethodsDetails.hasOwnProperty("parameters")) {
                        var count = 0;
                        for (var obj in paths[url][method]["parameters"]) {
                            //console.log(obj);
                            if (paths[url][method]["parameters"].hasOwnProperty(obj)) {
                                count++;
                            }
                        }

                        var pathQueryParam = [];
                        for (var i = 0; i < count; i++) {
                            console.log("in is " + paths[url][method]["parameters"][i].in);

                            var parameterIn = (paths[url][method]["parameters"][i].in).toLowerCase();

                            if ((parameterIn == 'query') || (parameterIn == 'path')) {
                                var obj1 = {};
                                var parameterName = paths[url][method]["parameters"][i]["name"];
                                var parameterDesc = paths[url][method]["parameters"][i]["description"];
                                var parameterType = paths[url][method]["parameters"][i]["type"];
                                var obj1 = {
                                    name: parameterName,
                                    description: parameterDesc,
                                    type: parameterType,
                                    in : parameterIn

                                };
                                pathQueryParam.push(obj1);
                                var pathQueryParamObject = {
                                    pathQueryParam
                                };
                                //console.log(JSON.stringify(pathQueryParamObject));
                            } else if ((parameterIn == 'body')) {
                                var notExampleObj = [];
                                var notExampleObjObj;
                                if (paths[url][method]["parameters"][i]["schema"]["example"]) {
                                    if (typeof (paths[url][method]["parameters"][i]["schema"]["example"]) === 'object') {
                                        var example = paths[url][method]["parameters"][i]["schema"]["example"];
                                    }
                                } else if (typeof (paths[url][method]["parameters"][i]["schema"]["properties"]) === 'object') {
                                    var schemaProperties = paths[url][method]["parameters"][i]["schema"]["properties"];
                                    console.log(schemaProperties);

                                    $.each(schemaProperties, function (index, value) {
                                        $.each(value, function (i, v) {

                                            if (value.hasOwnProperty("enum")) {
                                                if (i === "enum") {
                                                    console.log(i + ": " + v["0"]);

                                                    notExampleObjObj = {
                                                      [index]: v["0"]
                                                    }

                                                    notExampleObj.push(notExampleObjObj);
                                                }
                                            } else if (value.hasOwnProperty("items")) {
                                                if (i == "items") {
                                                    console.log(i + ": " + v);

                                                    $.each(v, function (i1, v1) {

                                                        if (i1 === "enum") {
                                                            console.log(i1 + ": " + v1[0]);
                                                            notExampleObjObj = {
                                                               [i]: [v1[0]]
                                                            }
                                                        }
                                                        notExampleObj.push(notExampleObjObj);
                                                    });


                                                }

                                            } else if (value.hasOwnProperty("type")) {
                                                var eg;
                                                if (v == "string") {
                                                    eg = "abcde";
                                                } else if (v == "integer") {
                                                    eg = "123";
                                                }

                                                notExampleObjObj = {
                                                      [index]: eg
                                                }

                                                notExampleObj.push(notExampleObjObj);
                                            }
                                            //                                            

                                        });

                                    });

                                    var notExampleObjMerged = JSON.stringify(mergeObjects(notExampleObj));
                                    //console.log(JSON.stringify(mergeObjects(notExampleObj)));

                                }
                            }
                        }
                    }
                    var theCompiledHtmlPostPutPatch = theTemplatePostPutPatch(pathQueryParamObject);
                    $('#collapse-' + uniqueIdFinal + " .panel-body").html(theCompiledHtmlPostPutPatch);
                    $('#collapse-' + uniqueIdFinal + " .panel-body").find('table').attr("id", "tbl-" + uniqueIdFinal);
                    if (example) {
                        $(".post_data").html(JSON.stringify(example));
                    } else if (notExampleObjMerged) {
                        $(".post_data").html(notExampleObjMerged);
                    }
                    //-----------------------------------------------------------------------------------------------------------------
                    // ajax call execute button click
                    $('.ajax-btn').on('click', function () {
                        _ajaxCall(url, method, urlMethodsDetails, uniqueIdFinal);
                    });

                    //-----------------------------------------------------------------------------------------------------------
                    // *---------------------------- verify schema button click------------------------------
                    $(".verify-schema").on("click", function () {
                        _responseSchema(url, method, urlMethodsDetails, uniqueIdFinal);
                    });
                    //---------------------------------------------------------------------------------------

                    //loading js from customscript.js-------------------------------------------------------------------------------

                    loadJsPostPutPatch(uniqueIdFinal);
                    //------------------------------------------------------------------------------------


                }
            })
            .catch(function (err) {
                console.error('The API is invalid. ' + err.message);
            });


    };
    //-------------------------------------------------------------------------------------------------------------

    /*-------------- function to merge objects----------------------------------------------------------------------------------------*/
    var mergeObjects = function (object) {
        var paramsMerged = {};
        object.forEach(function (object) {
            for (var propName in object) {
                paramsMerged[propName] = object[propName];
            }
        });
        return paramsMerged;
    };
    //---------------------------------------------------------------------------------------------------------------------------------


    var _ajaxCall = function (url, method, urlMethodsDetails, uniqueIdFinal, theCompiledHtmlGetDelete, theCompiledHtmlPostPutPatch) {

        /*--------------------Url Creation-----------------------------------------------------------------------------------*/
        var baseurl = url;
        var parametersObj = [];
        $('.row-select input:checked').each(function () {
            var paramName, paramValue, paramIn;
            paramName = $(this).closest('tr').find('.name').text();
            if (paramName == "") {
                paramName = $(this).closest('tr').find('.name').val();
            }
            paramValue = $(this).closest('tr').find('.param_value').val();
            paramIn = $(this).data('type');

            console.log("in is" + paramIn);

            if (paramIn == 'path') {
                if (paramValue == '') {
                    $(this).closest('tr').find('.param_value').focus();
                    $(this).closest('tr').find('.param_value').css('border-color', 'red');
                    return false;
                } else {
                    $(this).closest('tr').find('.param_value').css('border-color', '');
                }

            }

            var parametersObjObj = {};
            parametersObjObj = {
                [paramName]: paramValue,
                "in": paramIn
            };
            parametersObj.push(parametersObjObj);

        })
        var paylaodData = $('#collapse-' + uniqueIdFinal + ' .post_data').val();
        console.log(paylaodData);

        if (paylaodData == "") {
            $('#collapse-' + uniqueIdFinal + ' .post_data').focus();
            $('#collapse-' + uniqueIdFinal + ' .post_data').css('border-color', 'red');
            return false;
        } else {
            $('#collapse-' + uniqueIdFinal + ' .post_data').css('border-color', '');
        }


        var objWithPathParam = parametersObj.filter(function (parametersObj) {
            return parametersObj.in === "path";
        });

        var objWithQueryParam = parametersObj.filter(function (parametersObj) {
            return parametersObj.in === "query";
        });


        if (objWithPathParam.length > 0) {
            var PathParammergedObject = mergeObjects(objWithPathParam);
            delete PathParammergedObject['in'];
            $.each(PathParammergedObject, function (k, v) {

                if (baseurl.indexOf("{" + k + "}") != -1) {
                    baseurl = baseurl.replace("{" + k + "}", v);
                }
            });

            console.log("URL with path parameters is " + baseurl);

        }
        if (objWithQueryParam.length > 0) {
            var QueryParammergedObject = mergeObjects(objWithQueryParam);
            delete QueryParammergedObject['in'];
            baseurl = baseurl + "?" + jQuery.param(QueryParammergedObject);

            console.log("URL with query parameters is " + baseurl);
        }

        //---------------------------------------------------------------------------------------------------------------------------------------------

        /*----------------------------Read Json Payload ---------------------------------------------------------------------------------------*/
        var jsonPayload = $('#collapse-' + uniqueIdFinal + ' .post_data').val();
        console.log("payload data" + jsonPayload);
        //----------------------------------------------------------------------------------------------------------------------------------------

        var parammergedObject = mergeObjects(parametersObj);
        delete parammergedObject['in'];
        var parametersObjWithoutIn = parammergedObject;

        console.log("json is " + JSON.stringify(parammergedObject));



        /*---------------------------- export testcase result button click-------------------------------------------------------------*/
        $(".export_testcase").on("click", function () {
            console.log(uniqueIdFinal);
            var actual_response_code = $('#collapse-' + uniqueIdFinal + ' .http_actualresponse_code').html();
            var actual_response = JSON.parse($('#collapse-' + uniqueIdFinal + ' .actual-response').val());
            //var parsedActualResponse=JSON.parse(actual_response); 

            // schema
            response_schema = urlMethodsDetails["responses"][actual_response_code]["schema"];
            console.log(JSON.stringify(response_schema));

            /*---------------------------json data for get delete export ---------------------------------------------------------------------------- */
            if ((method == "get") || (method == "delete")) {

                var expectedResponse = JSON.parse($('#collapse-' + uniqueIdFinal + ' .expected-response').val());

                console.log("expected response" + $('#collapse-' + uniqueIdFinal + ' .expected-response').val());
                var expectedResponseCode = $('#collapse-' + uniqueIdFinal + ' .http_expected_response_code').val();
                console.log("expected response code" + $('#collapse-' + uniqueIdFinal + '.http_expected_response_code').val());
                var expectedResponseSchema = "";
                var result = "";
                if (httpCodeValidationResult === "success") {
                    if (httpResponseValidationResult === "success") {
                        if (httpSchemaValidationResult === "success") {
                            result = "success";
                        } else {
                            result = "fail";
                        }
                    }
                }


                var objExport = {
                    "hostname": "embapp-local.toshibatec.co.jp",
                    "port": "50187",
                    "baseurl": "v1.0",
                    "auth_headers": [
                        {
                            "key": "X-WebAPI-AccessToken",
                            "value": App.access_Token
                                                      }
                                                    ],
                    "cases": [
                        {
                            "id": 1,
                            "http_method": method,
                            "querystring": parametersObjWithoutIn,
                            "url": baseurl,
                            "expect_code": expectedResponseCode,
                            "expect_response_schema": expectedResponseSchema,
                            "expect_response": expectedResponse,
                            "actual_code": actual_response_code,
                            "actual_response_schema": response_schema,
                            "actual_response": actual_response,
                            "httpCodeValidation": httpCodeValidationResult,
                            "httpResponseValidation": httpResponseValidationResult,
                            "httpSchemaValidation": httpSchemaValidationResult,
                            "result": result
                                                      }
                                                    ]
                };
            }
            //---------------------------------------------------------------------------------------------------------------------------------

            /*-----------------json object for export post-put-delete--------------------------------------------------------------------------*/
            if ((method == "post") || (method == "put") || (method == "patch")) {

                var expectedResponse = JSON.parse($('#collapse-' + uniqueIdFinal + ' .expected-response').val());
                var expectedResponseCode = $('#collapse-' + uniqueIdFinal + ' .http_expected_response_code').val();
                var expectedResponseSchema = "";
                var result = "";
                if (httpCodeValidationResult === "success") {
                    if (httpResponseValidationResult === "success") {
                        if (httpSchemaValidationResult === "success") {
                            result = "success";
                        } else {
                            result = "fail";
                        }
                    }
                }
                var jsonPayloadData = JSON.parse(jsonPayload);

                var objExport = {
                    "hostname": "embapp-local.toshibatec.co.jp",
                    "port": "50187",
                    "baseurl": "v1.0",
                    "auth_headers": [
                        {
                            "key": "X-WebAPI-AccessToken",
                            "value": App.access_Token
                                                      }
                                                    ],
                    "cases": [
                        {
                            "id": 1,
                            "http_method": method,
                            "querystring": parametersObjWithoutIn,
                            "requestbody": jsonPayloadData,
                            "url": baseurl,
                            "expect_code": expectedResponseCode,
                            "expect_response_schema": expectedResponseSchema,
                            "expect_response": expectedResponse,
                            "actual_code": actual_response_code,
                            "actual_response_schema": response_schema,
                            "actual_response": actual_response,
                            "httpCodeValidation": httpCodeValidationResult,
                            "httpResponseValidation": httpResponseValidationResult,
                            "httpSchemaValidation": httpSchemaValidationResult,
                            "result": result
                                                      }
                                                    ]
                };
            }
            _exportTestCaseResult(objExport);
        });
        //---------------------------------------------------------------------------------------------------------------------------


        /*---------------------------- Ajax Call ------------------------------------------------------------------------------------- */

        if ((method == "post") || (method == "put") || (method == "patch")) {
            console.log(App.appToken, App.access_Token);
            if (baseurl.indexOf("?") != -1) {
                var requestParameters = baseurl.substr(baseurl.indexOf("?") + 1);
            } else {
                var requestParameters = "";
            }
            var jsonPayloadData = JSON.parse(jsonPayload);
            // console.log(jsonPayloadData);
            //console.log(JSON.stringify(jsonPayloadData));
            // var jsonValid = JSON.stringify(jsonPayloadData);
            var objAjaxPost = {
                urlVal: baseurl,
                methodVal: method,
                json_payload: jsonPayloadData
            };
            console.log(objAjaxPost);
            console.log(JSON.stringify(objAjaxPost));
            $.ajax({
                type: "POST",
                url: "/aplpx/server/" + App.appId + "/makeAjaxCallPostPutPatch",
                cache: false,
                data: JSON.stringify(objAjaxPost),
                contentType: 'application/json',
                dataType: "json",
                headers: {"X-WebAPI-AccessToken" : App.access_Token},
                success: function (json_data) {
                    console.log("Success : At Post/Put/Patch web-api call : " + JSON.stringify(json_data));
                    $('#collapse-' + uniqueIdFinal + ' .actual-response').html(JSON.stringify(json_data["responseJson"]));
                    $('#collapse-' + uniqueIdFinal + ' .http_actualresponse_code').html(JSON.stringify(json_data["responseCode"]));
                    $('<p> Method : ' + method + ' | Url : ' + baseurl + ' | ' + 'Request Parameters : ' + requestParameters + ' | Response Code : ' + JSON.stringify(json_data["responseCode"]) + ' | Response : ' + JSON.stringify(json_data["responseJson"]) + '</p>').appendTo('#global-console-wrapper .panel-body');
                },
                error: function (json_data) {
                    console.log("Server error : At Post/Put/Patch web-api call" + JSON.stringify(json_data));
                    $('#collapse-' + uniqueIdFinal + ' .actual-response').html(JSON.stringify(json_data));
                    //document.getElementById("eventText").innerHTML = "Server error!!：At AppAddress Allowed";
                },
                complete: function () {}
            });


        } else if ((method == "get") || (method == "delete")) {
            console.log(App.appToken, App.access_Token);
            if (baseurl.indexOf("?") != -1) {
                var requestParameters = baseurl.substr(baseurl.indexOf("?") + 1);
            } else {
                var requestParameters = "";
            }
            var objAjaxGet = {
                urlVal: baseurl,
                methodVal: method
            };

            $.ajax({
                type: "POST",
                url: "/aplpx/server/" + App.appId + "/makeAjaxCallGetDelete",
                cache: false,
                data: JSON.stringify(objAjaxGet),
                contentType: 'application/json',
                dataType: "json",
                headers: {"X-WebAPI-AccessToken" : App.access_Token},
                success: function (json_data) {
                    console.log("Success : At Get/Delete web-api call" + JSON.stringify(json_data));
                    $('#collapse-' + uniqueIdFinal + ' .actual-response').html(JSON.stringify(json_data["responseJson"]));
                    $('#collapse-' + uniqueIdFinal + ' .http_actualresponse_code').html(JSON.stringify(json_data["responseCode"]));
                    $('<p> Method : ' + method + ' | Url : ' + baseurl + ' | ' + 'Request Parameters : ' + requestParameters + ' | Response Code : ' + JSON.stringify(json_data["responseCode"]) + ' | Response : ' + JSON.stringify(json_data["responseJson"]) + '</p>').appendTo('#global-console-wrapper .panel-body');
                },
                error: function (json_data) {
                    console.log("Server error : At Get/Delete web-api call" + JSON.stringify(json_data));
                    $('#collapse-' + uniqueIdFinal + ' .actual-response').html(JSON.stringify(json_data));
                    //document.getElementById("eventText").innerHTML = "Server error!!：At AppAddress Allowed";
                },
                complete: function () {}
            });


        }

        // ----------------------------------------Clear test case result---------------------------------
        $(".clear_testcase").on("click", function (theCompiledHtmlGetDelete, theCompiledHtmlPostPutPatch) {
            console.log(uniqueIdFinal);

            $('#collapse-' + uniqueIdFinal + ' .http_actualresponse_code').empty();
            $('.http_expected_response_code').val("");
            $('#collapse-' + uniqueIdFinal + ' .actual-response').empty();
            $('.expected-response').val("");
            $('.response_checkbox').attr('checked', false);
            $('.row-select input:checked').attr('checked', false);
            $('.row-select').closest('tr').find('.param_value').val("");
            $('.schema_validation').empty();
            $('.http_code_validation').empty();
            $('.http_response_validation').empty();

        });
    };
    //-----------------------------------------------------------------------------------------------------------------------------------------

    /*---------------------------- Response Schema ------------------------------------------------------------------------------------------- */

    var _responseSchema = function (url, method, urlMethodsDetails, uniqueIdFinal) {

        var responses = urlMethodsDetails["responses"];
        console.log(responses);

        var actual_response_code = $('#collapse-' + uniqueIdFinal + ' .http_actualresponse_code').html();

        var expected_response_code = $('#collapse-' + uniqueIdFinal + ' .http_expected_response_code').val();

        // schema
        var response_schema = urlMethodsDetails["responses"][actual_response_code]["schema"];
        console.log(JSON.stringify(response_schema));
        // responses
        var actual_response = $('#collapse-' + uniqueIdFinal + ' .actual-response').val();
        console.log(actual_response);
        var expected_response = $('#collapse-' + uniqueIdFinal + ' .expected-response').val();

        var objSchema = {
            actualResponse: actual_response,
            responseSchema: response_schema
        };
        // schema validation
        $.ajax({
            type: "POST",
            url: "/aplpx/server/" + App.appId + "/responseSchema",
            cache: false,
            data: JSON.stringify(objSchema),
            contentType: 'application/json',
            dataType: "json",
            headers: {"X-WebAPI-AccessToken" : App.access_Token},
            success: function (json_data) {
                console.log("Success : Schema Validation " + json_data);
                //document.getElementById("eventText").innerHTML = JSON.stringify(json_data);
                if (json_data == null) {
                    $('.schema_validation').html('<span class="label label-success"><i class="glyphicon glyphicon-ok"></i> Passed</span>');
                    httpSchemaValidationResult = "success";
                } else {
                    $('.schema_validation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                    httpSchemaValidationResult = "fail";
                    $('#global-console-wrapper .panel-body').append(json_data);
                }

            },
            error: function (json_data) {
                console.log("Server error : Schema Validation" + json_data)
                    //document.getElementById("eventText").innerHTML = "Server error!!：At AppAddress Allowed";
                $('.schema_validation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                httpSchemaValidationResult = "fail";
                $('#global-console-wrapper .panel-body').append(json_data);
            },
            complete: function () {}
        });


        // http code validation
        if (expected_response_code != "") {
            if (actual_response_code === expected_response_code) {

                $('#collapse-' + uniqueIdFinal + ' .http_code_validation').html('<span class="label label-success"><i class="glyphicon glyphicon-ok"></i> Passed</span>');
                httpCodeValidationResult = "success";

            } else {
                $('#collapse-' + uniqueIdFinal + ' .http_code_validation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                httpCodeValidationResult = "fail";
            }
        }

        // response validation
        if (expected_response != "") {


            try {
                $('#collapse-' + uniqueIdFinal + ' .invalid_json_error').empty();
                var parseActualResponse = JSON.parse(actual_response);
                var parseExpectedResponse = JSON.parse(expected_response);
            } catch (e) {
                //console.log(e);                
                $('#collapse-' + uniqueIdFinal + ' .invalid_json_error').text(e);
            }

            function checkActualResponse(parseActualResponse, parseExpectedResponse) {
                console.log(_.isEqual(parseActualResponse, parseExpectedResponse));
                return _.isEqual(parseActualResponse, parseExpectedResponse)

            }

            if (checkActualResponse(parseActualResponse, parseExpectedResponse)) {
                $('#collapse-' + uniqueIdFinal + ' .http_response_validation').html('<span class="label label-success"><i class="glyphicon glyphicon-ok"></i> Passed</span>');
                httpResponseValidationResult = "success";
            } else {
                $('#collapse-' + uniqueIdFinal + ' .http_response_validation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                httpResponseValidationResult = "fail";
            }
        }


    };

    //-----------------------------------------------------------------------------------------------------------------------------------------

    /* ----------------------------- export test case ------------------------------------------------------------------------------------------ */
    var _exportTestCaseResult = function (objExport) {
            console.log("inside export function" + JSON.stringify(objExport));
            var exportFile = {
                objExportTestCase: objExport
            }
            $.ajax({
                type: "POST",
                url: "/aplpx/server/" + App.appId + "/exportTestCaseResult",
                cache: false,
                data: JSON.stringify(exportFile),
                contentType: 'application/json',
                dataType: "json",
                headers: {"X-WebAPI-AccessToken" : App.access_Token},
                success: function (json_data) {
                    console.log("Success : Export Test case :" + JSON.stringify(json_data));
                    var a = document.createElement("a");
                    var dict = {
                        filePathtoDowload: json_data
                    }
                    a.href = "/aplpx/server/00cdefbb-068b-11e6-9463-ffffffffff00/exportTestCaseResult1" + "?fileRoute=" + json_data;
                    a.click();
                    // $('.actual-response').push(JSON.stringify(json_data));
                    //document.getElementById("eventText").innerHTML = JSON.stringify(json_data);
                },
                error: function (json_data) {
                    console.log("Server error : Export Test case" + json_data);
                    // $('.actual-response').push(JSON.stringify(json_data));
                    //document.getElementById("eventText").innerHTML = "Server error!!：At AppAddress Allowed";
                },
                complete: function () {}
            });
        }
        //----------------------------------------------------------------------------------------------------------------------------


    return {
        _init: _init,
        _show: _show,
        _initialDisplay: _initialDisplay,
        _populateCategories: _populateCategories,
        _getUrlMethodDetails: _getUrlMethodDetails,
        _selectedCategoryName: _selectedCategoryName,


    };

})(window, jQuery);
