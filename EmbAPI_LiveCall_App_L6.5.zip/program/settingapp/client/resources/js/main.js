/* Copyright(c) 2016-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */

$(function () {

    /* -------------------------------------------------------------- */
    /* INITIALIZE APP MODULE FOLLOWED BY ANY OTHER REQUIRED MODULE */
    /* -------------------------------------------------------------- */
    App.init();
});