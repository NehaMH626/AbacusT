/* Copyright(c) 2016-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */

App.EventReceiver = (function (global, $, undefined) {

    var eventReceiver = function (data) {
         console.log('Event Receiver');
    };

    return {
        eventReceiver: eventReceiver
    };

})(window, jQuery);
