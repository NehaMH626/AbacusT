#! /usr/bin/env python
#-*- coding: utf-8 -*-

""" Copyright 2016 TOSHIBA TEC CORPORATION All rights reserved """

from pyramid.config import Configurator


def includeme(config):
    config.add_route('getAccesstoken', 'getAccesstoken', xhr=True)
    config.add_route('updateConfig', 'updateConfig', xhr=True)
    config.add_route('getConfigHome', 'getConfigHome', xhr=True)
    config.add_route('getConfigBackground', 'getConfigBackground', xhr=True)
    config.add_route('dummyToken', 'dummyToken', xhr=True)
    config.add_route('makeAjaxCallPostPutPatch', 'makeAjaxCallPostPutPatch', xhr=True)
    config.add_route('makeAjaxCallGetDelete', 'makeAjaxCallGetDelete', xhr=True)
    config.add_route('responseSchema', 'responseSchema', xhr=True)
    config.add_route('exportTestCaseResult', 'exportTestCaseResult', xhr=True)
    config.add_route('exportTestCaseResult1', 'exportTestCaseResult1', xhr=False)



def main(global_config, **settings):
    """ This function returns a Pyramid WSGI application.
    """
    config = Configurator(settings=settings)
    config.add_renderer('jsonp', JSONP(param_name='callback'))
    config.include(includeme, route_prefix='/')
    config.scan()
    return config.make_wsgi_app()
