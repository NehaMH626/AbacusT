# -*- coding: utf-8 -*-

import requests
import threading
import time
import logging
import json
import os
from itertools import *
#=========================================================================
# logging = logging.getLogger(__name__)
# FORMAT = "%(asctime)s%(msecs)03d Pid= %(process)d Tid= %(thread)d %(filename)s    %(lineno)d %(levelname)s %(message)s"
# logging.basicConfig(format=FORMAT)
# hdlr = logging.FileHandler('/work/log/al/appmanager.pythonlog.txt')
#=========================================================================

#=========================================================================
# logging.addHandler(hdlr)
# logging.setLevel(logging.INFO)
#=========================================================================
logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s Pid= %(process)d Tid= %(thread)d %(filename)s  %(lineno)d %(module)s %(levelname)s %(message)s",
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='/work/log/al/app/00cdefbb-068b-11e6-9463-ffffffffff00/applog.0.log',
                    filemode='a')

webapi_server = "embapp-local.toshibatec.co.jp"
webapi_port = "50187"

class logger(object):
    def __init__(self):
        self.headers = None

    def log(self,msg,log_level='warning',tag='bgapp'):
        name = str(os.path.basename(__file__))
        logData = {'log_level':log_level, 'msg':msg, 'tag':tag}
        requests.post("http://" + webapi_server + ":" + webapi_port + "/v1.0/app/debuglog/line", data=json.dumps(logData), headers=self.headers)

    def update_header(self,new_header):
        self.headers = new_header

logger_obj = logger()


class myMainThread(threading.Thread):
    headers = None
    stop_event = None

    def __init__(self, headers):
        logger_obj.log("enter myMainThread.__init__")
        super(myMainThread, self).__init__()
        self.headers = headers
        self.stop_event = threading.Event()
        logger_obj.log("exit myMainThread.__init__")

    def run(self):
        logger_obj.log("enter myMainThread.run")
        headers=self.headers
        logger_obj.log(str(headers))
        
        body_data = {"type": "string", "section": "Config", "name": "BackgroundApp", "value": str(headers['X-WebAPI-AccessToken'])}
        r = requests.post("http://" + webapi_server + ":" + webapi_port + "/v1.0/app/config", headers=self.headers, data = json.dumps(body_data))
        logger_obj.log(str(r.text))
       
        logger_obj.log("exit myMainThread.run")

    def stop(self):
        logger_obj.log("enter myMainThread.stop")
        self.stop_event.set()
        logger_obj.log("exit myMainThread.stop")


class WebBackgroundAppImpl:
    headers = None
    myProc = None

    def __init__(self, headers):

        self.headers = headers
        self.logger = logger_obj
        self.logger.update_header(headers)
        logger_obj.log("At WebBackgroundAppImpl.__init__")

    def onStart(self):
        self.logger.log("enter onStart")
        self.myProc = myMainThread(self.headers)
        self.myProc.start()
        self.logger.log("exit onStart")

    def onStop(self):
        self.logger.log("enter onStop")
        self.myProc.stop()
        self.logger.log("exit onStop")

    def onEvent(self, strEvent):
        self.logger.log("enter onEvent") 
        self.logger.log("exit onEvent")
