#! /usr/bin/env python
#-*- coding: utf-8 -*-

""" Copyright 2016 TOSHIBA TEC CORPORATION All rights reserved """
import sys
sys.path.append("/application/app/00cdefab-068b-11e6-9463-008091aec8b8/package/program/settingapp/server/lib")
sys.path.append("/application/app/00cdefab-068b-11e6-9463-008091aec8b8/package/program/settingapp/server/lib/jsonschema-2.6.0-py3.5.egg")


import json
import requests
import os.path
from pyramid.view import view_config
from pyramid.response import Response
from jsonschema import validate
import jsonschema
from pyramid.config import Configurator
from pyramid.response import FileResponse
# from paste import httpserver
import time
import logging


from stserver.apps.common.logger import logger_obj
log = logging.getLogger("settingtserver")
webapi_server = "embapp-local.toshibatec.co.jp"
webapi_port = "50187"
appId = "00cdefab-068b-11e6-9463-008091aec8b8"


@view_config(route_name='getAccesstoken', xhr=True, renderer='jsonp')
def getAccesstoken(request):
    tempData = {}
    try:
        headers = {"X-WebAPI-AccessToken": request.session["X-WebAPI-AccessToken"]}
        logger_obj.log(headers)
        return json.dumps(headers)
    except Exception as err:
        logger_obj.log(str(err),log_level='exception')


@view_config(route_name='updateConfig', xhr=True, renderer='jsonp')
def updateConfig(request):

    setdata = request.json
    logger_obj.log(str(setdata))
    param = setdata["App_config_param"]
    post_data = {"type": "string", "section": "Config",
                 "name": "DisplayText", "value": str(param)}
    logger_obj.log(str(post_data))
    headers = {"X-WebAPI-AccessToken": request.session["X-WebAPI-AccessToken"]}
    response = requests.post(
        "http://" + webapi_server + ":" + webapi_port + "/v1.0/app/config/settings", headers=headers, data=json.dumps(post_data))
    logger_obj.log(str(response.text))
    return response.json()


@view_config(route_name='getConfigHome', xhr=True, renderer='jsonp')
def getConfigHome(request):
    logger_obj.log("getConfig-Home!!")
    headers = {"X-WebAPI-AccessToken": request.session["X-WebAPI-AccessToken"]}
    response = requests.get("http://" + webapi_server + ":" + webapi_port + "/v1.0/app/config?type=string&section=Config&name=HomeApp", headers=headers)
    logger_obj.log("Exit:getConfig-Home!!")
    return response.json()

@view_config(route_name='getConfigBackground', xhr=True, renderer='jsonp')
def getConfigBackground(request):
    logger_obj.log("getConfig-Backgroundapp!!")
    headers = {"X-WebAPI-AccessToken": request.session["X-WebAPI-AccessToken"]}
    response = requests.get("http://" + webapi_server + ":" + webapi_port + "/v1.0/app/config?type=string&section=Config&name=BackgroundApp", headers=headers)
    logger_obj.log("Exit:getConfig-Background!!")
    return response.json()


@view_config(route_name='dummyToken', xhr=True, renderer='jsonp')
def dummyToken(request):
    logger_obj.log("getDummyToken-settingapp!!")
    response = requests.get("http://" + webapi_server + ":" + webapi_port + "/v1.0/app_framework/access_token_dummy", headers=request.headers)
    logger_obj.log("Exit:getDummyToken-settingapp!!")
    return response.json()

@view_config(route_name='makeAjaxCallPostPutPatch', xhr=True, renderer='jsonp')
def makeAjaxCallPostPutPatch(request):

    setdata = request.json
    logger_obj.log(str(setdata))
    # param = setdata["App_config_param"]
    # post_data = {"type": "string", "section": "Config", "name": "DisplayText", "value": str(param)}
    post_data = setdata["json_payload"]
    logger_obj.log(str(post_data))
    logger_obj.log(request.headers["X-WebAPI-AccessToken"])
    headers = {"X-WebAPI-AccessToken": request.headers["X-WebAPI-AccessToken"]}
    
    method = setdata["methodVal"]
    if method == "post":
        response = requests.post("http://" + webapi_server + ":" + webapi_port + "/v1.0" + setdata["urlVal"], headers=headers, data=json.dumps(post_data))
    elif method == "put":
        response = requests.put("http://" + webapi_server + ":" + webapi_port + "/v1.0" + setdata["urlVal"], headers=headers, data=json.dumps(post_data))
    elif method == "patch":
        response = requests.patch("http://" + webapi_server + ":" + webapi_port + "/v1.0" + setdata["urlVal"], headers=headers, data=json.dumps(post_data))
    logger_obj.log(str(response.text))
    responseData = {'responseJson': response.json(), 'responseCode': response.status_code}
    return responseData

@view_config(route_name='makeAjaxCallGetDelete', xhr=True, renderer='jsonp')
def makeAjaxCallGetDelete(request):

    setdata = request.json
    logger_obj.log(str(setdata))
    logger_obj.log(request.headers["X-WebAPI-AccessToken"])
    headers = {"X-WebAPI-AccessToken": request.headers["X-WebAPI-AccessToken"]}
    
    method = setdata["methodVal"]
    if method == "get":
        response = requests.get("http://" + webapi_server + ":" + webapi_port + "/v1.0" + setdata["urlVal"], headers=headers)
    elif method == "delete":
        response = requests.delete("http://" + webapi_server + ":" + webapi_port + "/v1.0" + setdata["urlVal"], headers=headers)
    logger_obj.log(str(response.text))
    responseData = {'responseJson': response.json(), 'responseCode': response.status_code}
    return responseData




@view_config(route_name='responseSchema', xhr=True, renderer='jsonp')
def responseSchema(request):
    try:
        logger_obj.log("responseSchema Enter")
        setdata = request.json
        logger_obj.log(str(setdata))
        schema = setdata["responseSchema"]
        actual_res = {}
        actual_res = setdata["actualResponse"]
        log.info(actual_res)
        response = validate(actual_res, schema)
        logger_obj.log("responseSchema Exit")
        return response
    except jsonschema.exceptions.ValidationError as err:
        log.exception(err.message)
        return err.message
    finally:
        return

@view_config(route_name='exportTestCaseResult', xhr=True, renderer='jsonp')
def exportTestCaseResult(request):

    setdata = request.json
    logger_obj.log(str(setdata))
    timestamp = time.strftime("%Y%m%d%H%M%S")
    filepath = os.path.join("/application/app/00cdefab-068b-11e6-9463-008091aec8b8/appstorage/normal", timestamp + ".json")
    file = open(filepath,"w")
    testCaseResult = json.dumps(setdata["objExportTestCase"])
    file.write(testCaseResult)
    file.close()
    # response = FileResponse(filepath, request=request, content_type='application/download')
    return filepath

@view_config(route_name='exportTestCaseResult1', xhr=False)
def exportTestCaseResult1(request):
    setdata = request.params
    file_path = os.path.join(setdata["fileRoute"])
    response = FileResponse(file_path, request=request, content_type='application/download')
    return response
