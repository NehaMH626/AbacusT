//js for upload test case in import screen

$(document).on('click', '.browse', function () {
    var file = $(this).parent().parent().parent().find('.file');
    file.trigger('click');
});
$(document).on('change', '.file', function () {
    $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
});


//js for vertical tabs in sidebar active class

$(document).ready(function () {
    var navItems = $('.admin-menu li > a');
    var navListItems = $('.admin-menu li');
    var allWells = $('.admin-content');
    var allWellsExceptFirst = $('.admin-content:not(:first)');

    allWellsExceptFirst.hide();
    navItems.click(function (e) {
        e.preventDefault();
        navListItems.removeClass('active');
        $(this).closest('li').addClass('active');

        allWells.hide();
        var target = $(this).attr('data-target-id');
        $('#' + target).show();
    });
});


//js for sidebar

$("#menu-toggle").click(function (e) {
    e.preventDefault();
    $("#wrapper").toggleClass("active");
});
//tooltip js
//$(document).ready(function(){
//    $('[data-toggle="tooltip"]').tooltip({
//        placement : 'right'
//    });
//});

function loadJsGetDelete(uniqueIdFinal) {
    //javascript code-----------------------------------------------------------------------------------------------------------------
    // tooltip javascript
    $('[data-toggle="tooltip"]').tooltip({
        placement: 'bottom',
        container: 'body'
    });
    // tooltip javascript  ends
    //add text box dynamically
    $(document).ready(function () {
        var max_fields = 10; //maximum input boxes allowed
        var wrapper = $("#tbl-" + uniqueIdFinal); //Fields wrapper
        var add_button = $(".add_field_button"); //Add button ID
        var x = 1; //initlal text box count
        $(add_button).click(function (e) { //on add input button click
            e.preventDefault();
            if (x < max_fields) { //max input box allowed
                x++; //text box increment
                $(wrapper).append('<tr class="row-select"><td class="text-middle"><input type="checkbox" class="checkbox" data-type="query"></td><td><input type="text" class="form-control name"></td><td></td><td><select class="form-control"><option>integer</option><option>string</option><option>float</option><option>array</option><option>object</option></select></td><td><input type="text" class="form-control param_value"><a href="#" class="remove_field_get_delete pull-right">Remove</a></td></tr>'); //add input box
            }
        });
        $(wrapper).on("click", ".remove_field_get_delete", function (e) { //user click on remove text
            // e.preventDefault();
            $("#tbl-" + uniqueIdFinal + ' tr:last').remove();
            x--;
        })
    });    
  
      $("input[name='chk_http_expected_code']").click(function(){
               if ($(this).is(':checked')) { 
                    $('.http_expected_response_code:text').attr("disabled", false);               
                 }  
          
          else if ($(this).not(':checked')) {   
                $('.http_expected_response_code:text').attr("disabled", true);   
                 }           
     }); 
    
     $("input[name='chk_expected_response']").click(function(){
               if ($(this).is(':checked')) {   
             
                    $('.expected-response').prop("disabled", false)           
                 }  
          
          else if ($(this).not(':checked')) {   
                $('.expected-response').attr("disabled", true);   
                 }           
     }); 


}

function loadJsPostPutPatch(uniqueIdFinal) {
    //javascript code                    
    // tooltip javascript
    $('[data-toggle="tooltip"]').tooltip({
        placement: 'bottom',
        container: 'body'
    });
    // tooltip javascript  ends  
    //add text box dynamically
    $(document).ready(function () {
        var max_fields = 10; //maximum input boxes allowed
        var wrapper1 = $("#tbl-" + uniqueIdFinal); //Fields wrapper
        var add_button = $(".add_field_button"); //Add button ID

        var y = 1; //initlal text box count
        $(add_button).click(function (e) { //on add input button click
            console.log("table id is" + $(this).closest('table').attr('id'));
            e.preventDefault();
            if (y < max_fields) { //max input box allowed
                y++; //text box increment
    $(wrapper1).append('<tr class="row-select"><td class="text-middle"><input type="checkbox" class="checkbox" data-type="query"></td><td><input type="text" class="form-control name"></td><td></td><td><select class="form-control"><option>integer</option><option>string</option><option>float</option><option>array</option><option>object</option></select></td><td><input type="text" class="form-control param_value"><a href="#" class="remove_field_post_put_patch pull-right">Remove</a></td></tr>'); //add input box
            }
        });
        $(wrapper1).on("click", ".remove_field_post_put_patch", function (e) { //user click on remove text
            e.preventDefault();
            $("#tbl-" + uniqueIdFinal + ' tr:last').remove();
            y--;
        })
    });
    //add text box dynamically 
    //enable expected response checkboxes


    $("input[name='chk_http_expected_code']").click(function(){
               if ($(this).is(':checked')) { 
                    $('.http_expected_response_code:text').attr("disabled", false);               
                 }  
          
          else if ($(this).not(':checked')) {   
                $('.http_expected_response_code:text').attr("disabled", true);   
                 }           
     }); 
    
     $("input[name='chk_expected_response']").click(function(){
               if ($(this).is(':checked')) {   
             
                    $('.expected-response').prop("disabled", false)           
                 }  
          
          else if ($(this).not(':checked')) {   
                $('.expected-response').attr("disabled", true);   
                 }           
     }); 


    //javascript code

}
