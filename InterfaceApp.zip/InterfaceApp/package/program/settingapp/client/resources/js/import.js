App.Import = (function (global, $, undefined) {
    var show = function (paths) {

        var fileArray = [];
        var fileContentArr = [];

        function openFile(evt) {

            var files = evt.target.files; // FileList object

            // use the 1st file from the list
            f = files[0];

            var reader = new FileReader();

            // Closure to capture the file information.
            reader.onload = (function (theFile) {
                return function (e) {
                    //jQuery('#ms_word_filtered_html').val(e.target.result);
                    console.log(e.target.result);
                    fileContents = e.target.result;
                    fileContentArr.push(fileContents);

                    // fileContentArr.push(e.target.result);
                    fileContentsObject = JSON.parse(fileContents);
                    console.log(fileContentsObject);


                };
            })(f);

            // Read in the image file as a data URL.
            reader.readAsText(f);

        }
        document.getElementById('upload').addEventListener('change', openFile, false);

        $(".addTestCase").on("click", function (responses) {
            var fileName = $('.uploadVal').val();
            if (fileName !== "") {
                $('#tbl-import_screen tbody').append('<tr data-filename=' + fileName + '><td class="number"></td><td>' + fileName + '</td><td class="resultIndication" data-jsonfile=' + fileName + '></td><td><a href="#"><span class="glyphicon glyphicon-remove remove-icon"></span></a></td></tr>');


                /*----------add nos to rows-------------------------------------*/

                $('#tbl-import_screen tbody tr').each(function (idx) {
                    $(this).children().first().html(idx + 1);
                });
                //------------------------------------------------------------------------------------

                /*--------Remove row from table--------------------------------------------------------------------------*/

                $('span.glyphicon-remove').on('click', function () {

                    var checkstr = confirm('are you sure you want to delete this?');
                    if (checkstr == true) {

                        var jsonFilename = $(this).closest('tr').data('filename');
                        // console.log("before deleting" + JSON.stringify(fileArray));
                        //console.log("==========================");


                        $.each(fileArray, function (k3, v3) {
                            $.each(v3, function (k4, v4) {

                                if (fileName == k4) {
                                    delete fileArray[k3][k4];
                                }


                            });
                        });



                        // console.log("after deleting" + JSON.stringify(fileArray));
                        // console.log("==========================");
                        $(this).closest('tr').remove();
                    } else {
                        return false;
                    }
                });
                //--------------------------------------------------------------------------------------- 



            }
            // var fileData = JSON.stringify(fileContentArr);
            // var fileDataObject = JSON.parse(fileData);
            // console.log(fileContentsObject);

            var fileArrayObj = {
              [fileName]: fileContentsObject

            };

            fileArray.push(fileArrayObj);
        });


        $("#executeTestCaseAtImport").on("click", function (responses) {


            console.log(fileArray);
            $.each(fileArray, function (k1, v1) {
                $.each(v1, function (k2, v2) {

                    var jsonMethod = fileArray[k1][k2].cases["0"].http_method;
                    var jsonUrl = fileArray[k1][k2].cases["0"].url;
                    var httpCode = fileArray[k1][k2].cases["0"].expect_code;
                    var httpResponse = fileArray[k1][k2].cases["0"].expect_response;
                    var httpActualCode = fileArray[k1][k2].cases["0"].actual_code;
                    var httpActualResponse = fileArray[k1][k2].cases["0"].actual_response;
                    var result1 = fileArray[k1][k2].cases["0"].result;
                    var codeValidation;
                    var responseValidation;
                    var schemaValidation = "";
                    var result;

                    var actualResponseCodeAtImport;
                    var actualResponseAtImport;

                    //console.log("url is" + jsonUrl + "method" + jsonMethod)



                    if ((jsonMethod == "get") || (jsonMethod == "delete")) {
                        var objAjaxGet = {
                            urlVal: jsonUrl,
                            methodVal: jsonMethod
                        };
                        $.ajax({
                            type: "POST",
                            url: "/aplpx/server/" + App.appId + "/makeAjaxCallGetDelete",
                            cache: false,
                            data: JSON.stringify(objAjaxGet),
                            contentType: 'application/json',
                            dataType: "json",
                            async: false,
                            headers: App.appToken,
                            success: function (json_data) {
                                console.log("Success : At Get/Delete web-api call" + JSON.stringify(json_data));
                                actualResponseCodeAtImport = JSON.stringify(json_data["responseCode"]);
                                actualResponseAtImport = json_data["responseJson"];

                                fileArray[k1][k2].cases["0"].actual_code = actualResponseCodeAtImport;
                                fileArray[k1][k2].cases["0"].actual_response = actualResponseAtImport;

                                var httpSchema = paths[jsonUrl][jsonMethod]["responses"][actualResponseCodeAtImport]["schema"];
                                console.log(httpSchema);


                                $('.responseCodeAtImport').html(actualResponseCodeAtImport);
                                $('.responseAtImport').html(JSON.stringify(actualResponseAtImport));

                                if (httpCode === actualResponseCodeAtImport) {
                                    codeValidation = "success";
                                    fileArray[k1][k2].cases["0"].httpCodeValidation = "success";

                                    $('.importCodeValidation').html('<span class="label label-success"><i class="glyphicon glyphicon-ok"></i> Passed</span>');
                                } else {
                                    codeValidation = "fail";
                                    fileArray[k1][k2].cases["0"].httpCodeValidation = "fail";
                                    $('.importCodeValidation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                                }

                                function checkActualResponse(actualResponseAtImport, httpResponse) {
                                    return _.isEqual(actualResponseAtImport, httpResponse);
                                }

                                if (checkActualResponse(actualResponseAtImport, httpResponse)) {
                                    responseValidation = "success";
                                    fileArray[k1][k2].cases["0"].httpResponseValidation = "success";
                                    $('.importResponseValidation').html('<span class="label label-success"><i class="glyphicon glyphicon-ok"></i> Passed</span>');
                                } else {
                                    responseValidation = "fail";
                                    fileArray[k1][k2].cases["0"].httpResponseValidation = "fail";
                                    $('.importResponseValidation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                                }

                                //schema validation
                                var objSchema = {
                                    actualResponse: actualResponseAtImport,
                                    responseSchema: httpSchema
                                };

                                $.ajax({
                                    type: "POST",
                                    url: "/aplpx/server/" + App.appId + "/responseSchema",
                                    cache: false,
                                    data: JSON.stringify(objSchema),
                                    contentType: 'application/json',
                                    dataType: "json",
                                    headers: App.appToken,
                                    success: function (json_data) {
                                        console.log("Success : Schema Validation " + json_data);
                                        if (json_data == null) {
                                            $('.importSchemaValidation').html('<span class="label label-success"><i class="glyphicon glyphicon-ok"></i> Passed</span>');
                                            schemaValidation = "success";
                                            fileArray[k1][k2].cases["0"].httpSchemaValidation = "success";
                                        } else {

                                            $('.importSchemaValidation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                                            schemaValidation = "fail";
                                            fileArray[k1][k2].cases["0"].httpSchemaValidation = "fail";
                                            $('#global-console-wrapper .panel-body').append(json_data);

                                        }


                                        if (codeValidation === "success") {
                                            if (responseValidation === "success") {
                                                if (schemaValidation === "success") {
                                                    //$('.resultIndication').html('<span class = "label label-success">Result</span>');
                                                    result = "success";

                                                } else {
                                                    result = "fail";
                                                    //$('.resultIndication').html('<span class = "label label-danger">Result</span>');
                                                }
                                            } else {
                                                result = "fail";
                                                // $('.resultIndication').html('<span class = "label label-danger">Result</span>>');
                                            }
                                        } else {
                                            result = "fail";
                                            //$('.resultIndication').html('<span class = "label label-danger">Result</span>');
                                        }

                                        if (result === "success") {

                                            fileArray[k1][k2].cases["0"].result = "success";
                                            if (fileArray[k1][k2].cases["0"].result === "success") {
                                                $('.resultIndication').html('<span class = "label label-success">Result</span>');
                                            }
                                        } else {

                                            fileArray[k1][k2].cases["0"].result = "fail";
                                            if (fileArray[k1][k2].cases["0"].result === "fail") {
                                                $('.resultIndication').html('<span class = "label label-danger">Result</span>');
                                            }
                                        }

                                    },
                                    error: function () {
                                        console.log("Server error : Schema Validation")
                                        $('.importSchemaValidation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                                        schemaValidation = "fail";
                                        fileArray[k1][k2].cases["0"].httpSchemaValidation = "fail";
                                    },
                                    complete: function () {}
                                });

                            },

                            error: function (json_data) {
                                console.log("Server error : At Get/Delete web-api call" + JSON.stringify(json_data));

                            },
                            complete: function () {}

                        });

                    } else if ((jsonMethod == "post") || (jsonMethod == "put") || (jsonMethod == "patch")) {
                        var jsonPayloadData = fileArray[k1][k2].cases["0"].requestbody;
                        var objAjaxPost = {
                            urlVal: jsonUrl,
                            methodVal: jsonMethod,
                            json_payload: jsonPayloadData
                        };

                        $.ajax({
                            type: "POST",
                            url: "/aplpx/server/" + App.appId + "/makeAjaxCallPostPutPatch",
                            cache: false,
                            data: JSON.stringify(objAjaxPost),
                            contentType: 'application/json',
                            dataType: "json",
                            async: false,
                            headers: App.appToken,
                            success: function (json_data) {
                                console.log("Success : At Post/Put/Patch web-api call : " + JSON.stringify(json_data));
                                actualResponseCodeAtImport = JSON.stringify(json_data["responseCode"]);
                                actualResponseAtImport = json_data["responseJson"];

                                fileArray[k1][k2].cases["0"].actual_code = actualResponseCodeAtImport;
                                fileArray[k1][k2].cases["0"].actual_response = actualResponseAtImport;


                                var httpSchema = paths[jsonUrl][jsonMethod]["responses"][actualResponseCodeAtImport]["schema"];
                                console.log(httpSchema);

                                $('.responseCodeAtImport').html(actualResponseCodeAtImport);
                                $('.responseAtImport').html(JSON.stringify(actualResponseAtImport));

                                if (httpCode === actualResponseCodeAtImport) {
                                    codeValidation = "success";
                                    $('.importCodeValidation').html('<span class="label label-success"><i class="glyphicon glyphicon-ok"></i> Passed</span>');
                                    fileArray[k1][k2].cases["0"].httpCodeValidation = "success";

                                } else {
                                    codeValidation = "fail";
                                    $('.importCodeValidation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                                    fileArray[k1][k2].cases["0"].httpCodeValidation = "fail";


                                }

                                function checkActualResponse(actualResponseAtImport, httpResponse) {
                                    return _.isEqual(actualResponseAtImport, httpResponse);
                                }

                                if (checkActualResponse(actualResponseAtImport, httpResponse)) {
                                    responseValidation = "success";
                                    fileArray[k1][k2].cases["0"].httpResponseValidation = "success";
                                    $('.importResponseValidation').html('<span class="label label-success"><i class="glyphicon glyphicon-ok"></i> Passed</span>');
                                } else {
                                    responseValidation = "fail";
                                    fileArray[k1][k2].cases["0"].httpResponseValidation = "fail";
                                    $('.importResponseValidation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                                }

                                // schema validation
                                var objSchema = {
                                    actualResponse: actualResponseAtImport,
                                    responseSchema: httpSchema
                                };

                                $.ajax({
                                    type: "POST",
                                    url: "/aplpx/server/" + App.appId + "/responseSchema",
                                    cache: false,
                                    data: JSON.stringify(objSchema),
                                    contentType: 'application/json',
                                    dataType: "json",
                                    headers: App.appToken,
                                    success: function (json_data) {
                                        console.log("Success : Schema Validation " + json_data);
                                        if (json_data == null) {
                                            $('.importSchemaValidation').html('<span class="label label-success"><i class="glyphicon glyphicon-ok"></i> Passed</span>');
                                            schemaValidation = "success";
                                            fileArray[k1][k2].cases["0"].httpSchemaValidation = "success";
                                        } else {
                                            $('.importSchemaValidation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                                            schemaValidation = "fail";
                                            fileArray[k1][k2].cases["0"].httpSchemaValidation = "fail";
                                            $('#global-console-wrapper .panel-body').append(json_data);

                                        }
                                        if (codeValidation === "success") {
                                            if (responseValidation === "success") {
                                                if (schemaValidation === "success") {
                                                    result = "success";
                                                    //  $('.resultIndication').html('<span class = "label label-success">Result</span>');
                                                } else {
                                                    result = "fail";
                                                    //$('.resultIndication').html('<span class = "label label-danger">Result</span>');
                                                }
                                            } else {
                                                result = "fail";
                                                // $('.resultIndication').html('<span class = "label label-danger">Result</span>');
                                            }
                                        } else {
                                            result = "fail";
                                            //$('.resultIndication').html('<span class = "label label-danger">Result</span>');
                                        }

                                        if (result === "success") {

                                            fileArray[k1][k2].cases["0"].result = "success";
                                            if (fileArray[k1][k2].cases["0"].result === "success") {
                                                $('.resultIndication').html('<span class = "label label-success">Result</span>');
                                            }
                                        } else {

                                            fileArray[k1][k2].cases["0"].result = "fail";
                                            if (fileArray[k1][k2].cases["0"].result === "fail") {
                                                $('.resultIndication').html('<span class = "label label-danger">Result</span>');
                                            }
                                        }

                                    },
                                    error: function () {
                                        console.log("Server error : Schema Validation")

                                        $('.importSchemaValidation').html('<span class="label label-danger"><i class="glyphicon glyphicon-remove"></i> Failed</span>');
                                        schemaValidation = "fail";
                                        fileArray[k1][k2].cases["0"].httpSchemaValidation = "fail";

                                    },
                                    complete: function () {}
                                });






                            },
                            error: function (json_data) {
                                console.log("Server error : At Post/Put/Patch web-api call" + JSON.stringify(json_data));
                            },
                            complete: function () {}
                        });

                    }

                });
            });

            var testcasesPassed = $('#tbl-import_screen tbody tr td span.label-success').length;
            var testcasesFailed = $('#tbl-import_screen tbody tr td span.label-danger').length;
            var totalTestcases = testcasesPassed + testcasesFailed;
            $('.total-testcases').text(totalTestcases);
            $('.testcases-passed').text(testcasesPassed);
            $('.testcases-failed').text(testcasesFailed);

            $('#tbl-import_screen tbody tr td').on('click', function () {
                var jsonFilename = $(this).data('jsonfile');
                $("#modal").modal("show");
                $('.modal-title').text(jsonFilename);

                $.each(fileArray, function (k5, v5) {
                    $.each(v5, function (k6, v6) {
                        if (jsonFilename === k6) {
                            //console.log(fileArray[k5][jsonFilename].cases["0"].actual_code);
                            //console.log(JSON.stringify(fileArray[k5][jsonFilename].cases["0"].actual_response));

                            $('.responseCodeAtImport').html(fileArray[k5][jsonFilename].cases["0"].actual_code);
                            $('.responseAtImport').html(JSON.stringify(fileArray[k5][jsonFilename].cases["0"].actual_response));


                        }

                    });

                });

            });

        });

        $("#clearTestCaseAtImport").on("click", function () {
            $('#tbl-import_screen tbody').empty();

        });

    }
    return {
        show: show

    };

})(window, jQuery);