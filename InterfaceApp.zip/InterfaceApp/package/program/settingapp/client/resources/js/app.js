/* Copyright(c) 2016-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
var App = (function (global, $, undefined) {

    var categoryPathMethodMap = {};

    var appId = '00cdefab-068b-11e6-9463-008091aec8b8';
    var access_Token;

    var homeTokenHeader;
    var bgTokenHeader;
    var settingTokenHeader;

    var setting_access_Token;
    var home_access_Token;
    var bg_access_Token;
    var appToken = {} ;

    var init = function () {
        console.log('Application initialized...');
        getAccesstoken();

        /* ------ get app data (category list, methods and url) ----------*/
        var parser = new SwaggerParser();
        parser.dereference("vendors/js/swagger.json")
            .then(function (api) {
                var paths = api.paths;
                for (var path in paths) {
                    for (var method in paths[path]) {
                        var category = paths[path][method]['tags'][0];
                        if (!categoryPathMethodMap.hasOwnProperty(category)) {
                            categoryPathMethodMap[category] = {};
                        }
                        if (!categoryPathMethodMap[category].hasOwnProperty(path)) {
                            categoryPathMethodMap[category][path] = [];
                        }
                        categoryPathMethodMap[category][path].push(method);
                    }
                }
                App.Home._populateCategories();
            })
            .catch(function (err) {
                console.error('The API is invalid. ' + err.message);
            });
    };


    var getAccesstoken = function () {
        defaultFunction();
        $('#selectAppType input').change(function () {
            var selectedOption = $('input[name=options]:checked').val();
            console.log(selectedOption);

            if (selectedOption == 'Setting App') {
                $(".setting").on("click", function () {
                    console.log("clicking home button");
                    defaultFunction();
                });
                App.appToken = settingTokenHeader;
                App.access_Token = setting_access_Token;
                console.log(App.appToken, App.access_Token);
            } else if (selectedOption == 'Home App') {

                console.log("clicking home button");
                $.ajax({
                    type: "GET",
                    url: "/aplpx/server/00cdefab-068b-11e6-9463-008091aec8b8/getConfigHome",
                    cache: false,
                    contentType: 'application/json',
                    dataType: "json",
                    header: settingTokenHeader,
                    success: function (json_data) {
                        console.log(json_data);
                        homeTokenHeader = {
                            'X-WebAPI-AccessToken': json_data.value
                        }
                        App.appToken = homeTokenHeader;
                        home_access_Token = json_data['value'];
                        App.access_Token = home_access_Token;
                        console.log(App.appToken, App.access_Token);
                    },
                    error: function () {
                        console.log("Unable to get Access Token @home app");
                    },
                    complete: function () {

                    }
                });
                

            } else if (selectedOption == 'Background App') {

                console.log("clicking bg button");

                $.ajax({
                    type: "GET",
                    url: "/aplpx/server/00cdefab-068b-11e6-9463-008091aec8b8/getConfigBackground",
                    cache: false,
                    contentType: 'application/json',
                    dataType: "json",
                    header: settingTokenHeader,
                    success: function (json_data) {
                        console.log(json_data);
                        bgTokenHeader = {
                            'X-WebAPI-AccessToken': json_data.value
                        };
                        App.appToken = bgTokenHeader;
                        bg_access_Token = json_data['value'];
                        App.access_Token = bg_access_Token;
                        console.log(App.appToken, App.access_Token);
                    },
                    error: function () {
                        console.log("Unable to get Access Token @background app");
                    },
                    complete: function () {

                    }
                });
               

            }

        });
        return appToken;
        return access_Token;

    };

    var defaultFunction = function () {

        // Server
        $.ajax({
            type: "GET",
            url: "/aplpx/server/00cdefab-068b-11e6-9463-008091aec8b8/getAccesstoken",
            dataType: "json", // JSON
            cache: false,
            success: function (json_data) {
                console.log(json_data);
                var data = JSON.parse(json_data);
                setting_access_Token = data["X-WebAPI-AccessToken"];
                App.access_Token = setting_access_Token;
                settingTokenHeader = json_data;
                App.appToken = settingTokenHeader;
                console.log(App.appToken, App.access_Token);
            },
            error: function () {
                console.log("Unable to get setting app access token")
            },
            complete: function () {

            }
        });
       
    };

    return {
        getAccesstoken: getAccesstoken,
        init: init,
        appId: appId,
        categoryPathMethodMap: categoryPathMethodMap,
        appToken: appToken,
        access_Token: access_Token

    };

}(window, jQuery));
