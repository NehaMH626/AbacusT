/* Copyright(c) 2015-2016 TOSHIBA TEC CORPORATION, All Rights Reserved. */

$(function () {

    /* -------------------------------------------------------------- */
    /* INITIALIZE APP MODULE FOLLOWED BY ANY OTHER REQUIRED MODULE */
    /* -------------------------------------------------------------- */
    App.init();
});
