/* Copyright(c) 2015-2016 TOSHIBA TEC CORPORATION, All Rights Reserved. */

App.EventReceiver = (function (global, $, undefined) {

    var eventReceiver = function (data) {
        console.log('Event Receiver');
        var eventDataResponse = JSON.stringify(data);
        console.log("Event_stream events : " + eventDataResponse);
        $('<p>' + now() + '  ' +'EventStreams :  '+ eventDataResponse + '</p>').appendTo('#eventPanel')
    };

    return {
        eventReceiver: eventReceiver
    };

})(window, jQuery);

function now() {
    var now = new Date();
    return ("0" + now.getHours()).slice(-2) + ":" + ("0" + now.getMinutes()).slice(-2) + ":" + ("0" + now.getSeconds()).slice(-2);
}