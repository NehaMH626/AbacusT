/* Copyright(c) 2015-2016 TOSHIBA TEC CORPORATION, All Rights Reserved. */

App.Util = (function (global, $, undefined) {

    /* ------------------------------------------------- */
    /* LOCALIZATION */
    /* ------------------------------------------------- */

    /* Get the message for a code in a particular language. */
    var getMessage = function (code) {
        return App.Locale['messages'][App.appLanguage][code];
    };

    /* Set the text of all elements in index.html having attribute data-message-id with the proper localized message. */
    var updateMessages = function () {
        console.log('Language: ' + App.appLanguage)
        $.each($('.js-localize'), function () {
            $(this).text(App.Locale['messages'][App.appLanguage][$(this).attr('data-message-id')]);
        });
    };

    /* ------------------------------------------------- */
    /* SSE SUBSCRIPTION */
    /* ------------------------------------------------- */


    var subscribeSSE = function () {
        /*console.log('Subscribing for SSE (APIEvents)');
        global.EventManager = new cAPIEventManager(App.appId, App.appToken['X-WebAPI-AccessToken']);
        global.EventManager.addEventListener(App.EventReceiver.eventReceiver);
        global.EventManager.startAPIEvents();
        console.log('Success: Subscribtion of SSE(APIEvents)!!')*/

        console.log('Subscribing for SSE (AppEvents)');
        global.EventManager2 = new cAppEventManager(App.appId, App.appToken['X-WebAPI-AccessToken']);
        global.EventManager2.addEventListener(App.EventReceiver2.eventReceiver2);
        global.EventManager2.startAppEvents();
        console.log('Success: Subscribtion of SSE(AppEvents)!!')

    };

    /* ------------------------------------------------- */
    /* AJAX REQUEST */
    /* ------------------------------------------------- */

    var serverRequest = function (URL, method, asyncStatus, callback, jsonData) {
        console.log('Request URL: ' + URL + ', Method: ' + method);
        if (jsonData) {
            jsonData = JSON.stringify(jsonData);
            console.log('POST Data : ' + jsonData);
        }

        $.ajax({
            url: URL,
            type: method,
            async: asyncStatus,
            headers: App.appToken,
            data: jsonData,
            contentType: 'application/json',
            dataType: 'json',
            /* Some web APIs doesn't handle the '_' appended in the query string, So making cache to true now, otherwise cache should be false. */
            cache: true,
            success: function (response, status, xhr) {
                console.log('Response Data: ' + JSON.stringify(response));
                console.log('Response Data: ' + JSON.stringify(status));
                console.log('Response Data: ' + JSON.stringify(xhr));
                callback(response);
            },
            error: function (xhr, status, error) {
                console.error(xhr.status + ', ' + status + ', ' + error);
                console.error(xhr.responseText);
                callback(null);
            }
        });
    };
    
    /* ------------------------------------------------- */
    /* MODULE APIs */
    /* ------------------------------------------------- */

    return {

        getMessage: getMessage,
        updateMessages: updateMessages,
        subscribeSSE: subscribeSSE,
        serverRequest: serverRequest

    };

})(window, jQuery);
