App.EventReceiver2 = (function (global, $, undefined) {
    var eventInfo;
    var eventReceiver2 = function (data) {
        console.log('Event Receiver');
        var eventDataResponse = JSON.stringify(data);
        console.log("webhooks events : " + eventDataResponse);
        $('<p>' + now() + '  ' + 'Webhooks :  ' + eventDataResponse + '</p>').appendTo('#eventPanel')
    };

    return {
        eventReceiver2: eventReceiver2
    };

})(window, jQuery);

function now() {
    var now = new Date();
    return ("0" + now.getHours()).slice(-2) + ":" + ("0" + now.getMinutes()).slice(-2) + ":" + ("0" + now.getSeconds()).slice(-2);
}