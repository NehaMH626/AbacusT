/* Copyright(c) 2015-2016 TOSHIBA TEC CORPORATION, All Rights Reserved. */

App.URL = (function (global, $, undefined) {

    /* ------------------------------------------------- */
    /* WEBAPI URLS */
    /* ------------------------------------------------- */

    var _webapiContextRoot = 'http://embapp-local.toshibatec.co.jp:50216/v1.0';

    /* Application specific webAPI URLs */
    var language = _webapiContextRoot + '/session/current/user/display_lang';
    var appDirectory = _webapiContextRoot + "/app/storage/directories";

    /* ------------------------------------------------- */
    /* SERVLET URLS */
    /* ------------------------------------------------- */

    var _servletContextRoot = '';
    /* Application specific servlet URLs */

    /* ------------------------------------------------- */
    /* SET THE SERVLET CONTEXT ROOT */
    /* ALSO INITIALIZE OTHER SERVLET URLS */
    /* ------------------------------------------------- */

    var setServletContextRoot = function (appId) {
        _servletContextRoot = '/server/' + appId;
    }

    /* ------------------------------------------------- */
    /* MODULE PUBLIC APIs */
    /* ------------------------------------------------- */

    return {
        setServletContextRoot: setServletContextRoot,
        webAPI: {
            language: language,
            appDirectory: appDirectory

        },
        servlet: {}
    }

})(window, jQuery);
