import React, { Component } from 'react';
import Accordion from './Accordion';
// import React, { Component } from "react";


// Display data in accordion 
class TableComponent extends React.Component {
    constructor(props, context) {
        super(props, context);
    }
    
    render() {
        return (
            <table className='accordionTable' style={{marginTop: this.props.visible == true ? '-16vh' : '0vh'}}>
                {/* <thead>
                    <tr>
                        <th>Description</th>
                        <th>Mode</th>
                        <th>Possible_Value</th>
                        <th>Code</th>
                        <th>Subcode</th>
                    </tr>
                </thead> */}
                <tbody>
                    {this.props.tableContent.map((item, index) => {
                        return <Accordion key={index} index={index} item={item} openAccordion={this.props.openAccordion} connected={this.props.connected}/>
                    })}
                </tbody>
            </table>
        );
    }
}

export default TableComponent;


  