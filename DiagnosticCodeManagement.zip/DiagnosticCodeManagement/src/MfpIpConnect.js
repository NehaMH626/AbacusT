import React from 'react';
import './MfpConnect.css';
import Axios from 'axios';

// Establish connection with MFP
class ConnectToMFP extends React.Component {
    state = {
        userIP : '',
        connected: false
    }

    // click of Connect Button
    onMFPConnect = () => {
        
        var ipAddress = this.state.userIP;
        //console.log("trying to connect", ipAddress);
        var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        if(ipAddress.match(ipformat))
        {
            //console.log('true');
            Axios.get('http://10.188.101.118:50666/opm_app/connect/mfp?ip=' + this.state.userIP)
            .then(
                (response) => {
                    //console.log("connected successfully to IP Address : ", this.state.userIP);
                    alert(response.data.message);
                    this.setState({connected : true})
                    //console.log("connected status : ", this.state.connected);
                }
            ).catch(error => {
                    alert("error connecting to IP address: " , this.state.userIP )
                    this.setState({connected : true})
                    //console.log("connected status : ", this.state.connected);
                })
        }
        else
        {
            alert('Please check the ip format');
        }

    }

    updateIP = (event) =>{

        this.setState({userIP : event.target.value})
    }


    render() {
        const {userIP} = this.state
        return (
            <div>
                <div className='wrap_connectDiv' style={{display: this.props.tableContent.length > 0 ? 'block': 'none'}}>
                    <div className="search">
                        <input type="text" className="searchTerm" ip='ipAddr_inputBox' placeholder="Enter MFP IP Addres" value={userIP} onChange={this.updateIP}/>
                        <button type="submit" className="connectButton searchButton" onClick={this.onMFPConnect}>
                        Connect
                        </button>
                    </div>
                </div>
                {/* <TableComponent ifConnected = {this.state.connected} /> */}
                {/* <Accordion ifConnected = {this.state.connected}/> */}
            </div>
        );
    }
}

export default ConnectToMFP;