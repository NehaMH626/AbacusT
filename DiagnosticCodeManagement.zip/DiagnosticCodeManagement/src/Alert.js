import React from 'react';
import Axios from 'axios';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import './alert.css';

class Alert extends React.Component {

    render() {
        return(
            <div>
               <div className={`alert ${this.props.visible ? 'fadeIn' : 'fadeOut'}`}>
                <ErrorOutlineIcon/> <div>{this.props.alertMessage}</div>
                </div>
            </div>
        )
    }

}

export default Alert;