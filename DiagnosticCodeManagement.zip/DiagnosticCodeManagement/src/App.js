import React from 'react';
// import logo from './logo.svg';
import './App.css';
import AppHeader from './AppHeader.js'
import SearchBar from './SearchCode.js'

class Main extends React.Component {
  
  render() {
    return (
      <div>
        
        <AppHeader />
        <SearchBar />
        
      </div>

    );
  }
}

export default Main;
