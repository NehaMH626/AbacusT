import React from 'react';
import './SearchBar.css';
import './alert.css';
import Axios from 'axios';
import SearchField from 'react-search-field';
// import IconButton from "@material-ui/core/IconButton";
// import InputAdornment from "@material-ui/core/InputAdornment";
import SearchIcon from "@material-ui/icons/Search";
import TableComponent from "./TableComponent";
import Ripples from 'react-ripples';
import $ from 'jquery';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import Alert from './Alert';



class SearchBar extends React.Component {
    
        state = {
            userSearchData: '',
            tableContent: [],
            searchCall: false,
            userIP : '',
            connected: false,
            alertDialog: false,
            alertMessage: '',
            visible:false,
            connectedIP: ''
          };
    
    
      
      // ------------- search button click -----------------------------------------------------
      onSearchClick = () => {
        //console.log("searhed text" , document.getElementById('searchInputBox').value, '...', this.state.userSearchData)
            if(document.getElementById('searchInputBox').value != '') {
                //console.log("searhing text", this.state.userSearchData)
                Axios.get('http://10.188.101.118:50666/opm_app/08_code/list?code=' + this.state.userSearchData)
                .then(response => {
                   // console.log("response" , JSON.stringify(response))
                    this.state.searchCall = true
                    //console.log("response" , JSON.stringify(response.data))
                    response = response.data
                    // response = [{
                    //     "Description": "vnc access",
                    //     "Mode": '08',
                    //     "Possible_Value": "8 \\n 9 \\n 0",
                    //     "Code": 8794,
                    //     "Subcode": 1
                    // }, {
                    //     "Description": null,
                    //     "Mode": '08',
                    //     "Possible_Value": '1:3',
                    //     "Code": 9870,
                    //     "Subcode": 'NA'
                    // }, {
                    //     "Description": " print disable print disable print disable print disable print disable",
                    //     "Mode": '08',
                    //     "Possible_Value": "4 \\n 7",
                    //     "Code": 9871,
                    //     "Subcode": 7
                    // }]
                    this.setState({tableContent: response});
                    this.setState({alertDialog : false});
                    //console.log("response.......", this.state.tableContent);
                },response => {
                    //console.log("response" , JSON.stringify(response))
                    this.state.searchCall = true
                    //console.log("response call done" , JSON.stringify(this.state.searchCall))
                    
                    response = response.data
                    // response = [{
                    //     "Description": "vnc access",
                    //     "Mode": '08',
                    //     "Possible_Value": "8 \\n 9 \\n 0",
                    //     "Code": 8794,
                    //     "Subcode": 1
                    // }, {
                    //     "Description": null,
                    //     "Mode": '08',
                    //     "Possible_Value": '1:3',
                    //     "Code": 9870,
                    //     "Subcode": 'NA'                
                    // }, 
                    //     {
                    //     "Description": " print disable print disable print disable print disable print disable",
                    //     "Mode": '08',
                    //     "Possible_Value": "4 \\n 7",
                    //     "Code": 9871,
                    //     "Subcode": 7
                    // }]
                    this.setState({tableContent: response});
                    this.setState({alertDialog : false});
                   
                    //console.log("response.......", this.state.tableContent);
                })
            } else {
                alert('Please enter data to be searched !')
                // this.setState({alertDialog : true});
                // console.log('alert status ', this.state.alertDialog)
                // this.setState({alertMessage:'Please enter data to be searched !'})
                // this.setState({visible : true});
                // setTimeout(() => {
                //     this.setState({
                //         visible: false
                //     });
                //   }, 2000)
            }
      };

    updateInput = (event) => {
        this.setState({userSearchData: event.target.value})
    }

    openAccordion = (index) => {
        var item = this.state.tableContent, isOpen = item[index].openAccordion;
        for (var i=0; i < item.length; i++) {
            item[i].openAccordion = false;
        }
        item[index].openAccordion = !isOpen;
        this.setState({tableContent: item});
    }
    // ---------------------MFP Connect ---------------------------------------
    onMFPConnect = () => {
        var ipAddress = this.state.userIP;
        //console.log("ip address" , ipAddress)
        if(ipAddress != '') {
            
            //console.log("trying to connect", ipAddress);
            var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
            if(ipAddress.match(ipformat))
            {
                //console.log('true');
                Axios.get('http://10.188.101.118:50666/opm_app/connect/mfp?ip=' + this.state.userIP)
                .then(
                    (response) => {
                        //console.log("connected successfully to IP Address : ", this.state.userIP);
                        alert(response.data.message);
                        this.setState({connected: true})
                        this.setState({connectedIP : response.data.message})
                        //this.state.connected = true;
                        //console.log("connected status : ", this.state.connected);
                    }
                ).catch(error => {
                        //console.log("error connecting to IP address: " , this.state.userIP);
                        alert("Error connecting to MFP: " , this.state.userIP);
                        this.setState({connected: false})
                        //console.log("connected status : ", this.state.connected);
                    })
            }
            else
            {
                // this.setState({alertDialog : true});
                // console.log('alert status ', this.state.alertDialog)
                // this.setState({alertMessage:'Please check the ip format !'})
                // this.setState({visible : true});
                // setTimeout(() => {
                //     this.setState({
                //         visible: false
                //     });
                //   }, 2000)
                  alert('Please check the ip format !');

            }
        } else {
            alert('Enter IP address !');
            // this.setState({alertDialog : true});
            // console.log('alert status ', this.state.alertDialog)
            // this.setState({alertMessage:'Enter IP address !'})
            // this.setState({visible : true});
            // setTimeout(() => {
            //     this.setState({
            //         visible: false
            //     });
            //   }, 2000)
            
        }

    }

    updateIP = (event) =>{
        this.setState({userIP : event.target.value})
    }

    // --------------------------Mfp connect end --------------------------------------

    render() {

        const { userSearchData } = this.state;
        const {userIP} = this.state;
        
        return(
            <div>
                <div className='logoDiv' style={{display: this.state.tableContent.length > 0 ? 'none': 'block'}} >
                <div><img className='logo' src={require('./bg6.jpg')} alt="logo">
                    </img></div>
                <div className='note'>Diagnostic code at your finger tips...</div>
                </div>
                <div className='connectedAlert' style={{display: this.state.connected ? 'block' : 'none'}}>
                    {this.state.connectedIP}
                </div>
                <div className='searchPanel' style={this.state.tableContent.length > 0 ? {overflowY: 'scroll', boxShadow: '0 2px 5px 0 rgba(0,0,0,.16), 0 2px 10px 0 rgba(0,0,0,.12)', marginTop: this.state.connected ? '1vh' : '19vh'}: {overflowY: 'hidden', boxShadow: '0px 0px #ffffff'}}>
                {/* {this.state.alertDialog == true ? (<Alert visible={this.state.visible} alertMessage={this.state.alertMessage}/>) : ''} */}
                <div className="wrap" style={{top: this.state.tableContent.length > 0 ? '20%': '59%'}}>
                    <div className="search" style={{width: this.state.tableContent.length > 0 ? '50%': '100%'}}>
                        <input type="text" id="searchInputBox" className="searchTerm" placeholder="Search 08 Code/functionality" required="required" value = {userSearchData} onChange={this.updateInput}/>
                        <Ripples color="#2f71a9" during={400}>
                            <button type="submit" className="searchButton" onClick={this.onSearchClick}>
                            <SearchIcon />
                            </button>
                        </Ripples>
                    </div>
                </div>
                
                {/* {this.state.tableContent.length = 0 ? <div><p>No Results</p></div> : ''} */}
                {this.state.searchCall == true ? <div className ='noSearchResult' style={{display: this.state.tableContent.length == 0 ? 'block' : 'none' }}><p>No search results!!</p></div> : ''}
                
                <div className='wrap_connectDiv' style={{display: this.state.tableContent.length > 0 ? 'block': 'none'}}>
                    <div className="search">
                        <input type="text" className="searchTerm" ip='ipAddr_inputBox' required="required" placeholder="Enter MFP IP Address" value={userIP} onChange={this.updateIP}/>
                        <Ripples color="#2f71a9" during={400}>
                        <button type="submit" className="connectButton searchButton" onClick={this.onMFPConnect}>
                        Connect
                        </button>
                        </Ripples>
                    </div>
                </div>
               
                 {this.state.tableContent.length > 0 ? (
                <TableComponent visible={this.state.visible} tableContent={this.state.tableContent} openAccordion={this.openAccordion} connected={this.state.connected}/>): ''}
                
                 {/* <ConnectToMFP tableContent = {this.state.tableContent}/> */}
            </div>
            </div>
        );
    }

}

export default SearchBar;
