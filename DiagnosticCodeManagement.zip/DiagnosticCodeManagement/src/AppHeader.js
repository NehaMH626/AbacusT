import React from 'react';
import './App.css';
// import icon from './appicon.png'

class AppHeader extends React.Component{
    render(){
        return (
            <div>
                <div className='App-header'>
                    <img src={require('./icon.png')} alt="logo" className="App-icon">
                    </img>
                   <div><h2>Diagnostic Code Management</h2></div>
                   {/* <div className='sub-title'><h4>... get and set developer modes here !!</h4></div> */}
                </div>
            </div>
        );
    }
}

export default AppHeader;