import React from 'react';
import Axios from 'axios';
import './SearchBar.css';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import './alert.css';
import Alert from './Alert';

// Accordion Close and open features with details of each server code, default val, setting default val
class Accordion extends React.Component {
	constructor(props) {
        super(props);
        this.state = {
            showInput: false,
            disabledButtonColor : 'rgb(176, 180, 180)',
            alertDialog: false,
            alertMessage: '',
            visible:false,
            reset: ''
        }
    }
    
    // Get Value button click 
    fetch_DefaultCode_Details = () => {
        if(this.props.connected == true) {
            this.setState({showInput: true})

            Axios.get('http://10.188.101.118:50666/opm_apps/get_code/default?code=' +this.props.item.Code+ '&mode='+ this.props.item.Mode)
            .then(response => {
                document.getElementById('getDefaultVal' +this.props.item.Code).innerHTML = '';
                document.getElementById('getDefaultVal' +this.props.item.Code).innerHTML = response.data.value;
            }, response => {
                //response = 'hello fetch_DefaultCode_Details'
                //console.log(response)
            })
        } else {
            alert('connect to MFP');
        }   
    }
    
    // On Set Value button click
    onSetButtonClick = () => {
        //console.log("this connected", this.props.connected);
        if(this.props.connected == true) { 
            var setCodeValue ;
            setCodeValue = document.getElementById('setInputBox'+this.props.item.Code).value;
            if(setCodeValue != '') {
               // console.log("Clicking set button" + this.props.item.Mode + " " +this.props.item.Code + ' '+ setCodeValue );
                Axios.get('http://10.188.101.118:50666/opm_app/setCode?code=' +this.props.item.Code+ '&mode='+ this.props.item.Mode + '&setvalue='+ setCodeValue)
                .then(response => {
                    alert('Value is set successfully !!');
                    //console.log(response)
                }, response => {
                    //console.log(response)
                })
            } else {
                    alert('Please enter the value to be set !!');
               
            }
        } else {
            alert('connect to MFP');
        }
        
    }
	render() {

        var select_div = document.getElementsByClassName('selectDiv');
        var possible_val = this.props.item.Possible_Value;
        if(possible_val.includes("\\n") == true) {
            var options = possible_val.split("\\n");
            options = options.map(opt_val => {return{value : opt_val , display : opt_val}});
            //console.log("options are ", options);
        } else {
            var options = [];   
            options.push(possible_val);
            options = options.map(opt_val => {return{value : opt_val , display : opt_val}});
            //console.log(" else options are ", options);
        }
        
        if(this.props.item.openAccordion == true) {
            //console.log("opne", 'getDefaultVal' + this.props.item.Code)
            if(document.getElementById('setInputBox' + this.props.item.Code).value !== '') {
                document.getElementById('setInputBox' + this.props.item.Code).value = this.state.reset;
            }
            let getDefaultVal= document.getElementById('getDefaultVal' + this.props.item.Code)
            if (typeof(getDefaultVal) != 'undefined' && getDefaultVal != null)
            {
                if(  document.getElementById('getDefaultVal' + this.props.item.Code).innerHTML !== '') {
                    document.getElementById('getDefaultVal' + this.props.item.Code).innerHTML = this.state.reset;
                }
            }
        }
        
		return (
            <div>
            {/* {this.state.alertDialog == true ? (<Alert visible={this.state.visible} alertMessage={this.state.alertMessage}/>) : ''} */}
			<div className='accordion' role='tablist' style={{marginTop: this.state.visible == true ? '-16vh' : '0vh'}}>
				<div className='panel' role='tabpanel' id = {this.props.item.Identifier} aria-expanded={this.props.item.openAccordion}>
                    <button className='panel__label' 
                        role='tab' style={{borderRadius: this.props.item.openAccordion ? '5px 5px 0 0': '5px'}}
                        onClick={ () => {this.props.openAccordion(this.props.index)} }>
                        { this.props.item.Mode + " Code : " + this.props.item.Code} <p>{this.props.item.Description}</p>
                        {/* <i className='expandIcon rotateIcon'>
                        <ExpandMoreIcon />
                        </i> */}
                        
                    </button>
                    <div className='panel__inner' aria-hidden={ !this.props.item.openAccordion } style={{display: this.props.item.openAccordion ? 'block': 'none'}}>
                        <div className='panel__content'>

                        <div className='card cardBg'>

                        <div className='button_panel'>
                        <div className='search fixingHeight' style={{marginBottom : '5%'}}>
                            {this.state.showInput ? 
                            (<div className='panel_get_default ' id = {'getDefaultVal' +this.props.item.Code}>
                            </div>) : ''
                            }
                            <button className='get_set_button get_button' onClick={() => this.fetch_DefaultCode_Details(this.props.item)} style={{background : this.props.connected == false ? '#9a9a9a' : '#28719e', width: this.props.item ? '100%': 'auto', borderRadius: this.props.item ? '5px' : '0 5px 5px 0'}}><span>Get Value</span></button>
                            
                            {/* <button className='get_set_button' >{'Set ' + this.props.item.Mode + ' Code'}</button> */}
                        </div>
                            <div className='search fixingHeight'>
                                <input type="number" required="required" className='set_inputbox' placeholder="value to be set" id={'setInputBox' + this.props.item.Code}/>
                                <button type="submit" className='get_set_button set_button' style = {{background : this.props.connected == false ? '#9a9a9a' : '#28719e'}} onClick={this.onSetButtonClick} >Set Value
                                </button>
                            </div>
                        </div>

                        </div>
                            
                        <div className='card dataCard' style={{height: this.props.item.Subcode == 'NA' ? '30%' : 'auto' }}>
                            
                            <div className ='displayData'><div className='label'>Description : </div><span className='spanData'>{this.props.item.Description}</span></div>
                            <div className ='displayData'><div className='label'>Possible Value : </div><select className='spanData selectDiv '>{options.map((team) => <option key={team.value} value={team.value}>{team.display}</option>)}</select></div>
                            <div className ='displayData' style={{display: this.props.item.Subcode == 'NA' ? 'none' : 'flex' }}><div className='label'>SubCode : </div><span className='spanData'>{this.props.item.Subcode}</span></div>
            
                        </div>
                        </div>
                    </div>
                </div>
			</div>
            </div>
		);
	}
}

export default Accordion;