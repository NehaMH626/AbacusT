"""Main entry point
"""
from pyramid.config import Configurator
from cornice import service
import sys
import inspect
from pyramid.response import Response

# import ctypes
# import ctypes.util
# import os
# from webapiserver.constants import *

def includeme(config):
    pass
    #onfig.add_route('/', 'start_app', xhr=True)

def hello_world(request):
    return Response('Hello World!')

def main(global_config, **settings):
    # libmycap = ctypes.cdll.LoadLibrary(CAPABILITY_LIB_PATH)


    #change to apache but keep caps
    # os.setgid(2000)
    # libmycap.changeUserKeepCap(ctypes.c_int(1000) )
    #drop non required cap
    # libmycap.dropNonReqCap()

    config = Configurator(settings=settings)
    config.include("cornice")
    # config.route_prefix = 'v1.0'
    # config.add_tween('webapiserver.tweens.web_api_tween_factory')

    # config.add_route('hello', '/')
    # config.add_view(hello_world, route_name='hello')
    config.scan()
    config.add_static_view(name='client', path='/home/SYSROM_SRC/mfpmanagement/client/', cache_max_age=3600)
    return config.make_wsgi_app()

