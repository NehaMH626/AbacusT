base = "10.188."
mfp_username = vmfp_username = "root"
mfp_password = "toshibatec1048"
vmfp_password = "rootroot"
buildno_file = "/home/ebxversion.txt"
setenv_file = "/home/SYSROM_SRC/setenv"
license_dom = "/work/al/etc/dom/License"
mfp_dom = "/work/al/etc/dom/MFP"
temp_path = "temp/"
mfp_command = "/home/SYSROM_SRC;"
setenv_command = "cd /home/SYSROM_SRC;source setenv > /dev/null;"
softwareupgradepath = "/work/al/filestorage/softwareupgrade/"

oidManufacturer = "1.3.6.1.2.1.43.8.2.1.14.1.1"
oidModel = "1.3.6.1.2.1.1.5.0"
oidLocation = "1.3.6.1.4.1.1129.2.3.50.1.2.4.1.4.1.1"
oidLocation = "1.3.6.1.2.1.1.6.0"
oidFirmware = "1.3.6.1.4.1.1129.2.3.50.1.2.3.1.4.1.1"
oidMFPName = "1.3.6.1.2.1.43.5.1.1.16.1"
oidMFPStatus = "1.3.6.1.2.1.25.3.2.1.5.1"
SystemSoftwareID = "1.3.6.1.4.1.1129.2.3.50.1.2.4.1.8.1.1"
oidStage2port = "1.3.6.1.4.1.1129.2.3.50.1.6.1.34.1.1.3.1.1"
oidMfpDrawersInstalled = "1.3.6.1.4.1.1129.2.3.50.1.2.3.1.15.1.1"
oidPrinterColorType = "1.3.6.1.2.1.43.10.2.1.6.1.1"
oidSerialNumber = "1.3.6.1.2.1.43.5.1.1.17.1"

subnet_list = ['101', '102', '103', '104']  # subnet groups
ignoreSubProduct = ["MOSEL", "ST_HELENS", "ECO_LOIRE", "ECO_LOIRE2", "EX_SERIES_2"]

OIDMapper = {
            "1.3.6.1.2.1.43.8.2.1.14.1.1": "mfp_manufacturer",
            "1.3.6.1.2.1.1.5.0": "mfp_model",
            "1.3.6.1.2.1.1.6.0": "mfp_location",
            "1.3.6.1.4.1.1129.2.3.50.1.2.3.1.4.1.1": "mfp_firmware",
            "1.3.6.1.2.1.43.5.1.1.16.1": "mfp_name",
            "1.3.6.1.2.1.25.3.2.1.5.1": "mfp_status",
            "1.3.6.1.4.1.1129.2.3.50.1.2.4.1.8.1.1": "system_software_id",
            "1.3.6.1.4.1.1129.2.3.50.1.6.1.34.1.1.3.1.1": "stage2_port",
            "1.3.6.1.4.1.1129.2.3.50.1.2.3.1.15.1.1": "mfp_drawers_installed",
            "1.3.6.1.2.1.43.10.2.1.6.1.1": "printer_color_type",
            "1.3.6.1.2.1.43.5.1.1.17.1": "mfp_serial_number",
}
mfp_refresh_path = {
                "mfp_manufacturer": "Controller/Information/manufacturer",
                "mfp_model" : "MFP/ModelName",
                "mfp_location" : "Controller/Information/physicalLocation",
                "mfp_firmware" : "/Controller",
                "system_software_id" : "/Controller",
                "mfp_drawers_installed" : "/Controller",
                "mfp_name" : "Network/Protocols/TCP-IP/hostName",
                "mfp_status" : "MFP/DeviceState",
                "stage2_port" : "Network/Services/Stage2/HTTPPortNumber",
                "printer_color_type" : "MFP/Printer/Toner/ProcessColorant",
                "mfp_serial_number" : "Controller/Information/MFPSerialNumber"
}
set_mfp_path = {
                "mfp_destination": "Controller/Information/destinationSelection", 
                "finisher_attached": "MFP/Printer/Finisher/Installation", 
                "faxline1_installed": "MFP/Fax/Line1/Installation", 
                "faxline2_installed": "MFP/Fax/Line2/Installation"
}
modelType = {
            "H_MODEL": "-H",
            "L_MODEL": "-L",
            "ECO_HYBRID": "Caspian",
            "H_A4_MODEL": "Matterhorn"
}
seriesType = {
            "EBN_SERIES_1": "1",
            "EBN_SERIES_2": "2",
            "EBN_SERIES_3": "3",
}
weissSeriesType = {
                "EBN_SERIES_1": "2",
                "EBN_SERIES_2": "3",
                "EBN_SERIES_3": "4",
                "WEISS_L_HDD": "Weiss-L-HDD",
                "WEISS_L_SSD": "Weiss-L-SSD",
                "WEISS_LL": "Weiss-LL",
                "WEISS_H": "Weiss-H",
}