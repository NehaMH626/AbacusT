import paramiko
import logging
import os
import time
import xml.etree.ElementTree as xml_parser
from pysnmp.hlapi import *
from zipfile import ZipFile
from .constants import *
from .db_connect import DbOperator, SqlModel
LOG = logging.getLogger("LOG_NAME")
sync_enable = False

def connectToMFP(ip_address, username, password):
    try:
        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname=ip_address, username=username, password=password, compress=True, look_for_keys=False, allow_agent=False, timeout=5)
        return ssh
    except Exception as err:
        LOG.exception(str(err))

def softwareupdate(filename):
    status = False
    try:
        command_1 = setenv_command
        command_1 += 'albotest SET Authentication/UserCredential/userName Admin;'
        command_1 += 'albotest SET Authentication/UserCredential/passwd 123456;'
        command_1 += 'albotest SENDCOMMAND Login Authentication/UserCredential;'
        command_1 += 'albotest SENDCOMMAND2 GetAvailableUpdates SoftwareUpgrade "<domNodeAddress contentType="Xpath">SoftwareUpgrade</domNodeAddress><filestoragePath contentType="Value">SoftwareUpgrade</filestoragePath><basePath contentType="Value">" + filename + "</basePath>"'
        stdin, stdout, stderr = clientMFP.exec_command(command_1)
        err_1 = stderr.read().decode("utf-8")

        command_2 = setenv_command
        command_2 += "albotest SET SoftwareUpgrade/PackageList/Package/Software/Component[2]/@selected true;"
        stdin, stdout, stderr = clientMFP.exec_command(command_2)
        err_2 = stderr.read().decode("utf-8")
        
        if not err_2:
            command_3 = setenv_command
            command_3 += "albotest SENDCOMMAND Install SoftwareUpgrade '<domNodeAddress contentType='Xpath'>SoftwareUpgrade</domNodeAddress>'"
            stdin, stdout, stderr = clientMFP.exec_command(command_3)
            err_3 = stderr.read().decode("utf-8")
            if not err_3:
                LOG.warning("success")
                return True
    except Exception as exc:
        LOG.exception(str(err))
    finally:
        return status

def copy_file_to_server(sftp_client, local_path, remote_path, file_name):
    status = False
    try:
        if "sing20":
            LOG.warning("copying the package")
            with ZipFile(local_path + file_name, 'r') as zip: 
                zip.extractall(local_path)  # extracting all the files
                os.remove(local_path + file_name)  # deleting .zip file
                file_name = file_name.replace('.zip', '.tar')
              
        file_local = local_path + file_name
        file_remote = remote_path + file_name
        sftp_client.put(file_local, file_remote)
        status = softwareupdate(file_local)
        os.remove(file_local)
    except Exception as err:
        LOG.exception(err + filename)
    finally:
        return status

def read_file_from_server(sftp_client, filename, search_data=[]):
    file_data = []
    search_data_len = len(search_data)
    try:
        remote_file = sftp_client.open(filename)
        for line in remote_file:
            if search_data_len > 0:
                for each in search_data:
                    if each in line:
                        file_data.append(line.strip("\n"))
            else:
                file_data.append(line.strip("\n"))
        remote_file.close()
    except Exception as err:
        LOG.exception(err + filename)
    finally:
        return file_data

def read_file_from_server_xml(sftp_client, filename, tag):
    entrylist = []
    try: 
        with sftp_client.open(filename) as f:
            xml_root = xml_parser.parse(f)

            for child in xml_root.iter(tag):
                entrydict = {}
                for elem in child:
                    entrydict[str(elem.tag)] = str(elem.text)
                entrylist.append(entrydict)

            return entrylist
    except Exception as err:
        LOG.exception(err)
    finally:
        return entrylist

def setMFPData(clientMFP, mfp_details, mfp_ip):
    """
    all the MFP Product details from ebxversion and setenv file are collected here
    """
    res = False
    try:
        build_number = []
        product_info = []
        mfp_details["faxline1_installed"] = ""
        mfp_details["faxline2_installed"] = ""
        mfp_details["finisher_attached"] = ""
        mfp_details["mfp_destination"] = ""

        if clientMFP is not None:
            sftp_client = clientMFP.open_sftp()
            build_number = read_file_from_server(sftp_client, buildno_file)
            product_info = read_file_from_server(sftp_client, setenv_file,
                                                 search_data=["export PRODUCT=", "export SUB_PRODUCT=",
                                                              "export SUB_PRODUCT_MODEL="])
            for path in set_mfp_path:
                command_1 = setenv_command
                command_1 += "albotest GET {}".format(set_mfp_path[path])
                stdin, stdout, stderr = clientMFP.exec_command(command_1)
                err_1 = stderr.read().decode("utf-8")
                mfp_details[path] = stdout.read().decode("utf-8").split("\n")[0] if not err_1 else ""

        mfp_details["build_number"] = build_number[0] if len(build_number) > 0 else mfp_details["mfp_firmware"]
        # Build details from "ebxversion.txt" is collected above

        product = product_info[0].split('=')[1].split('#')[0].strip() if len(product_info) > 0 else ""
        sub_product = product_info[1].split('=')[1].strip() if len(product_info) > 1 else ""
        sub_product_model = product_info[2].split('=')[1].strip() if len(product_info) > 2 else ""

        if sub_product in ignoreSubProduct:
            LOG.warning("Ignoring MFP " + mfp_ip + " " + sub_product)
            return
        if product == "WEISS":
            if sub_product_model != "":
                if sub_product_model in ("ECO_HYBRID", "H_A4_MODEL"):
                    mfp_details["mfp_type"] = modelType[sub_product_model]
                else:
                    mfp_details["mfp_type"] = "Weiss" + weissSeriesType[sub_product] + modelType[sub_product_model]
            else:
                mfp_details["mfp_type"] = weissSeriesType[sub_product]
        elif product == "BP":
            mfp_details["mfp_type"] = "Shasta" + seriesType[sub_product]
        elif product == "ALABAMA":
            mfp_details["mfp_type"] = "Shastina" + seriesType[sub_product]
        elif product == "LOIRE":
            mfp_details["mfp_type"] = "Reuss" + seriesType[sub_product]
        else:
            mfp_details["mfp_type"] = ""

        mfp_details["product"] = product
        mfp_details["sub_product"] = sub_product
        mfp_details["sub_product_model"] = sub_product_model

        res = True
    except Exception as exc:
        LOG.exception(exc)
    finally:
        return res

def setLicenseData(clientMFP, mfp_ip):
    """
    License info of a MFP from Dom is collected here
    """
    license_data = []
    try:
        if clientMFP is not None:
            command_1 = setenv_command + "cd /home;"
            command_1 += "aldocread xml " + license_dom + " > license.xml;"
            stdin, stdout, stderr = clientMFP.exec_command(command_1)
            err_1 = stderr.read().decode("utf-8")

            if not err_1:
                sftp_client = clientMFP.open_sftp()
                license_list = read_file_from_server_xml(sftp_client, "/home/license.xml", "Entry")

                for license in license_list:
                    if license["Status"] == "ENABLE":
                        license_db_data = {}
                        license_db_data["mfp_ip"] = mfp_ip
                        license_db_data["license_id"] = license["ElkLicenseID"]
                        license_db_data["license_name"] = license["LicenseName"]
                        license_db_data["is_enabled"] = license["Status"]
                        license_db_data["license_serial_number"] = license["DongleSerialNumber"]
                        license_data.append(license_db_data)

    except Exception as exc:
        LOG.exception(exc)
    finally:
        return license_data

def setDrawerInfo(clientMFP, mfp_ip):
    drawerlist = []
    try:
        if clientMFP is not None:
            command_1 = setenv_command + "cd /home;"
            command_1 += "aldocread xml " + mfp_dom + " > mfp.xml;"
            stdin, stdout, stderr = clientMFP.exec_command(command_1)
            err_1 = stderr.read().decode("utf-8")
            feeder_list = ['Drawer1', 'Drawer2', 'Drawer3', 'Drawer4', 'LCF']

            """
            if not err_1:
                sftp_client = clientMFP.open_sftp()
                with sftp_client.open("/home/mfp.xml") as f:
                    xml_root = xml_parser.parse(f)
                    for child in xml_root.iter('PaperFeeder'):
                        for elem in child:
                            if elem.tag in feeder_list:
                                data = {}
                                data["drawer_name"] = elem.tag
                                data["mfp_ip"] = mfp_ip
                                for i in elem:
                                    data[i.tag] = i.text
                                drawerlist.append(data)
            """
            details = ['Installation', 'PaperSize', 'Capacity', 'RemainingQuantity']
            for drawer in feeder_list:
                data = {}
                data["drawer_name"] = drawer
                data["mfp_ip"] = mfp_ip
                for each in details:
                    command_1 = setenv_command
                    command_1 += "albotest GET MFP/Printer/PaperFeeder/{}/{}".format(drawer, each)
                    stdin, stdout, stderr = clientMFP.exec_command(command_1)
                    err_1 = stderr.read().decode("utf-8")
                    data[each] = stdout.read().decode("utf-8").split("\n")[0] if not err_1 else ""
                drawerlist.append(data)

    except Exception as exc:
        LOG.exception(exc)
    finally:
        return drawerlist

def setTonerInfo(clientMFP, mfp_ip):
    tonerlist = []
    try:
        if clientMFP is not None:
            '''
            sftp_client = clientMFP.open_sftp()
            with sftp_client.open("/home/mfp.xml") as f:
                xml_root = xml_parser.parse(f)
                for child in xml_root.iter('Toner'):
                    for elem in child:
                        if elem.tag in feeder_list:
                            data = {}
                            data["toner_name"] = elem.tag
                            data["mfp_ip"] = mfp_ip
                            for i in elem:
                                data[i.tag] = i.text
                            tonerlist.append(data)
            '''
            feeder_list = ['Y', 'M', 'C', 'K']
            details = ['Installation', 'RemainingQuantity']
            for toner in feeder_list:
                data = {}
                data["toner_name"] = toner
                data["mfp_ip"] = mfp_ip
                for each in details:
                    command_1 = setenv_command
                    command_1 += "albotest GET MFP/Printer/Toner/{}/{}".format(toner, each)
                    stdin, stdout, stderr = clientMFP.exec_command(command_1)
                    err_1 = stderr.read().decode("utf-8")
                    data[each] = stdout.read().decode("utf-8").split("\n")[0] if not err_1 else ""
                tonerlist.append(data)
            
    except Exception as exc:
        LOG.exception(exc)
    finally:
        return tonerlist

def setJamData(clientMFP, mfp_ip):
    """
    Jam info of a MFP from Dom is collected here
    """
    jam_data = []
    try:
        if clientMFP is not None:
            sftp_client = clientMFP.open_sftp()
            jam_list = read_file_from_server_xml(sftp_client, "/home/mfp.xml", "Details")

            for jam in jam_list:
                jam_db_data = {}
                jam_db_data["mfp_ip"] = mfp_ip
                jam_db_data["jam_name"] = jam["Name"]
                jam_db_data["jam_code"] = jam["Code"]
                jam_db_data["error_level"] = jam["ErrorLevel"]
                jam_data.append(jam_db_data)

    except Exception as exc:
        LOG.exception(exc)
    finally:
        return jam_data


def query_ip_thread(mfp_ip, mfp_ips):
    try:
        errorIndication, errorStatus, errorIndex, varBinds = next(
            getCmd(SnmpEngine(),
                   CommunityData('public', mpModel=0),
                   UdpTransportTarget((mfp_ip, 161)),
                   ContextData(),
                   ObjectType(ObjectIdentity(oidManufacturer)),
                   ObjectType(ObjectIdentity(oidModel)))
        )

        if errorIndication:
            pass
        elif errorStatus:
            pass
        else:
            
            mfp_manufacturer = varBinds[0][1]
            mfp_model = varBinds[1][1]
            if "TOSHIBA" in str(mfp_manufacturer):
                if "TOSHIBA" in str(mfp_model) or "e-STUDIO" in str(mfp_model):
                    errorIndication, errorStatus, errorIndex, varBinds = next(
                        getCmd(SnmpEngine(),
                               CommunityData('public', mpModel=0),
                               UdpTransportTarget((mfp_ip, 161)),
                               ContextData(),
                               ObjectType(ObjectIdentity(oidManufacturer)),
                               ObjectType(ObjectIdentity(oidModel)),
                               ObjectType(ObjectIdentity(oidLocation)),
                               ObjectType(ObjectIdentity(oidMFPName)),
                               ObjectType(ObjectIdentity(oidFirmware)),
                               ObjectType(ObjectIdentity(oidMFPStatus)),
                               ObjectType(ObjectIdentity(SystemSoftwareID)),
                               ObjectType(ObjectIdentity(oidStage2port)),
                               ObjectType(ObjectIdentity(oidMfpDrawersInstalled)),
                               ObjectType(ObjectIdentity(oidPrinterColorType)),
                               ObjectType(ObjectIdentity(oidSerialNumber)))
                    )
                    if errorIndication:
                        LOG.warning(str(mfp_ip) + str(errorStatus))
                        pass
                    elif errorStatus:
                        LOG.warning(str(mfp_ip) + str(errorStatus))
                        pass
                    else:
                        mfp_details = {}

                        for i in varBinds:
                            mfp = [str(x) for x in i]
                            mfp_details[OIDMapper[mfp[0]]] = mfp[1]
                        # all the MFP details from OID search is collected above

                        clientMFP = connectToMFP(mfp_ip, mfp_username, mfp_password)
                        mfp_details['connected'] = "yes" if clientMFP is not None else "no"
                        mfp_details['is_booked'] = "available"
                        mfp_details['username'] = ""

                        if clientMFP is None:
                            clientMFP = connectToMFP(mfp_ip, vmfp_username, vmfp_password)
                            if clientMFP is not None:
                                LOG.warning("Ignoring VMFP " + str(mfp_ip))
                                return

                        mfp_details["mfp_ip"] = mfp_ip
                        status = setMFPData(clientMFP, mfp_details, mfp_ip)
                        license_list = setLicenseData(clientMFP, mfp_ip)
                        drawer_list = setDrawerInfo(clientMFP, mfp_ip)
                        toner_list = setTonerInfo(clientMFP, mfp_ip)
                        jam_list = setJamData(clientMFP, mfp_ip)

                        if status:
                            with DbOperator() as cur:
                                sql = SqlModel(cur)
                                if mfp_ip in mfp_ips:
                                    mfp_ips.remove(mfp_ip)
                                sql.create_mfp_table(mfp_details)
                                for license in license_list:
                                    sql.create_license_table(license)
                                for drawer in drawer_list:
                                    sql.create_drawer_table(drawer)
                                for toner in toner_list:
                                    sql.create_toner_table(toner)
                                for jam in jam_list:
                                    sql.create_jam_table(jam)

                        LOG.warning("---------------")
    except Exception as exc:
        LOG.exception(str(exc))