from cornice.resource import resource, view
from .db_connect import DbOperator, SqlModel
from pyramid.view import view_config
from pyramid.httpexceptions import HTTPFound
from cornice import Service
from pyramid.httpexceptions import exception_response
from pyramid.response import Response
from .mfpsetdata import *
from .constants import *
import threading
import logging
import json
import time
import shutil
import os


logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s Pid= %(process)d Tid= %(thread)d %(filename)s  %(lineno)d %(module)s %(levelname)s %(message)s",
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='/work/log/al/OPM/db_log.0.log',
                    filemode='a')

LOG = logging.getLogger("LOG_NAME")


def check_thread_alive(threads, mfp_ips):
    for t in threads:
        while t.is_alive():
            time.sleep(1)
    sql = SqlModel()
    sql.delete_row(mfp_ips)
    global sync_enable
    sync_enable = False


@resource(path="/sync_mfp_db", accept=("application/json"))
class syncMFPDB():
    def __init__(self, request, context=None):
        self.request = request
        self.threads = []

    @view(renderer='json')
    def get(self):
        global sync_enable
        response = {"status": "failed", "sync_enable": sync_enable}
        try:
            LOG.warning("syncMFPDB:get:enter")
            LOG.warning(sync_enable)
            if sync_enable is False:
                sync_enable = True
                sql = SqlModel()
                #sql.drop_row()
                mfp_ips = sql.get_all_ips()
                for subnet in subnet_list:
                    subnet = base + subnet
                    for i in range(2, 254):
                        query_ip = subnet + '.' + str(i)
                        x = threading.Thread(target=query_ip_thread, args=(query_ip, mfp_ips,))
                        self.threads.append(x)
                        x.start()
                x = threading.Thread(target=check_thread_alive, args=(self.threads, mfp_ips,))
                x.start()
                response["status"] = "success"
                response["sync_enable"] = sync_enable
                LOG.warning("syncMFPDB:get:exit")
        except Exception as exc:
            LOG.exception(str(exc))
        finally:
            return response

@resource(path="/refresh_mfp_data", accept=("application/json"))
class refreshMFPData():

    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        response = {"status": "failed", "data": {}}
        try:
            request = self.request
            mfp_ip = request.params.get("ip")
            clientMFP = connectToMFP(mfp_ip, mfp_username, mfp_password)

            if clientMFP is None:
                LOG.warning("Trying for vmfp " + str(mfp_ip))
                clientMFP = connectToMFP(mfp_ip, vmfp_username, vmfp_password)
                if clientMFP is not None:
                    return

            if clientMFP is not None:
                mfp_details = {}
                mfp_details["mfp_ip"] = mfp_ip
                mfp_details['connected'] = "yes"

                for key in mfp_refresh_path:
                    command_1 = setenv_command
                    command_1 += "albotest get {}".format(mfp_refresh_path[key])
                    stdin, stdout, stderr = clientMFP.exec_command(command_1)
                    err_1 = stderr.read().decode("utf-8")
                    mfp_details[key] = stdout.read().decode("utf-8").split("\n")[0] if not err_1 else ""

                status = setMFPData(clientMFP, mfp_details, mfp_ip)
                license_list = setLicenseData(clientMFP, mfp_ip)
                drawer_list = setDrawerInfo(clientMFP, mfp_ip)
                toner_list = setTonerInfo(clientMFP, mfp_ip)
                jam_list = setJamData(clientMFP, mfp_ip)

                if status:
                    with DbOperator() as cur:
                        sql = SqlModel(cur)
                        sql.create_mfp_table(mfp_details)
                        for license in license_list:
                            sql.create_license_table(license)
                        for drawer in drawer_list:
                            sql.create_drawer_table(drawer)
                        for toner in toner_list:
                            sql.create_toner_table(toner)
                        for jam in jam_list:
                            sql.create_jam_table(jam)
                    response = {"status" : "success", "data": mfp_details}

        except Exception as exc:
            LOG.exception(str(exc))
        finally:
            return response

@resource(path="/get_mfp_data", accept=("application/json"))
class getMFPData():

    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        try:
            sql = SqlModel()
            mfp_data = sql.get_mfp_date()
            mfp_details = {"mfp_data": mfp_data, "sync_enable": sync_enable}
            return mfp_details
        except Exceptionas as exc:
            LOG.exception(str(exc))

@resource(path="/get_search_data", accept=("application/json"))
class getSearchData():

    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        try:
            request = self.request
            search_text = request.params.get("search_text")
            sql = SqlModel()
            mfp_list = sql.search_data(search_text)
            mfp_data = sql.get_mfp_date(mfp_list)
            mfp_details = {"mfp_data": mfp_data, "sync_enable": sync_enable}
            return mfp_details
        except Exception as exc:
            LOG.exception(str(exc))

@resource(path="/get_product_data", accept=("application/json"))
class getProductData():

    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        try:
            request = self.request
            ip = request.params.get("ip")
            sql = SqlModel()
            product_data = sql.get_mfp_date([ip])
            return product_data
        except Exception as exc:
            LOG.exception(str(exc))


@resource(path="/run_test_script/{ip}", accept=("application/json"))
class runTestScript():

    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def post(self):
        status = {"status": "failed"}
        try:
            request = self.request
            input_file = request.POST['file'].file
            filename = request.POST['file'].filename
            ip = request.matchdict.get('ip', None)
            file_local = 'temp/' + filename

            try:
                with open(file_local, 'wb') as output_file:
                    shutil.copyfileobj(input_file, output_file)
            except Exception as exc:
                LOG.exception(str(exc))
                return
            clientMFP = connectToMFP(ip, mfp_username, mfp_password)
            if clientMFP:
                sftp_client = clientMFP.open_sftp()
                file_remote = "/work/al/tmp/" + filename
                sftp_client.put(file_local, file_remote)

                command_1 = setenv_command
                command_1 += "cd /work/al/tmp;"
                file = "result_" + time.strftime("%Y%m%d-%H%M%S") + '.txt'
                command_1 += "python3 " + filename + " > " + file
                stdin, stdout, stderr = clientMFP.exec_command(command_1)
                err_1 = stderr.read().decode("utf-8")
                if not err_1:
                    status["status"] = "success"
                    status["path"] = "client/result/" + file
                    remote = "/work/al/tmp/" + file
                    sftp_client.get(remote, status["path"])

            if os.path.isfile(file_local):
                os.remove(file_local)
        except Exception as exc:
            LOG.exception(str(exc))
        finally:
            return status


@resource(path="/book_mfp", accept=("application/json"))
class bookMFP():

    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def post(self):
        status = {"status": "failed", "is_booked": ""}
        try:
            request = self.request
            ip = request.json_body.get("ip")
            command = request.json_body.get("command")
            username = request.json_body.get("username")
            sql = SqlModel()
            mfp_data = sql.get_mfp_date([ip])

            if mfp_data:
                status["is_booked"] = mfp_data[0]["is_booked"]
                status["username"] = mfp_data[0]["username"]

            if command:
                with DbOperator() as cur:
                    sql = SqlModel(cur)
                    query = '''UPDATE mfp_info SET '''
                    if command == "available":
                        username = ""
                    sql.update_table_row(query, {"is_booked": command, "username": username}, "mfp_ip", ip)
                status = {"status": "success", "is_booked": command, "username": username}
        except Exception as exc:
            LOG.exception(str(exc))
        finally:
            return status

@resource(path="/get_license_data", accept=("application/json"))
class getLicenseData():

    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        drawer_data = []
        try:
            request = self.request
            ip = request.params.get("ip", "")
            sql = SqlModel()
            license_data = sql.get_table_data(ip, "license_info")
        except Exceptionas as exc:
            LOG.exception(str(exc))
        finally:
            return license_data

@resource(path="/get_health_report", accept=("application/json"))
class getHealthReport():

    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        heath_data = {"drawer_data": [], "toner_data": [], "jam_data": []}
        try:
            request = self.request
            ip = request.params.get("ip", "")
            sql = SqlModel()
            heath_data["drawer_data"] = sql.get_table_data(ip, "drawer_info")
            heath_data["toner_data"] = sql.get_table_data(ip, "toner_info")
            heath_data["jam_data"] = sql.get_table_data(ip, "jam_info")
        except Exceptionas as exc:
            LOG.exception(str(exc))
        finally:
            return heath_data

@resource(path="/software_upgrade/{ip}", accept=("application/json"))
class softwareUpgrade():

    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def post(self):
        status = {"status": "failed"}
        try:
            LOG.warning("softwareUpgrade:enter")
            request = self.request
            input_file = request.POST['file'].file
            filename = request.POST['file'].filename
            ip = request.matchdict.get('ip', None)
            try:
                file_path = 'temp/' + filename
                with open(file_path, 'wb') as output_file:
                    shutil.copyfileobj(input_file, output_file)
            except Exception as exc:
                LOG.exception(str(exc))
                return status

            clientMFP = connectToMFP(ip, mfp_username, mfp_password)

            if clientMFP is not None:
                sftp_client = clientMFP.open_sftp()
                install_status = copy_file_to_server(sftp_client, temp_path, softwareupgradepath, filename)
                if install_status:
                    status = {"status": "success"}

        except Exceptionas as exc:
            LOG.exception(str(exc))
        finally:
            LOG.warning("softwareUpgrade:exit")
            return status

@resource(path="/", accept=("application/json"))
class start_app():
    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        LOG.warning("start_app:enter")
        return HTTPFound(location="/client/index.html")
