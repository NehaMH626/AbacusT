import logging
import sqlite3

logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s Pid= %(process)d Tid= %(thread)d %(filename)s  %(lineno)d %(module)s %(levelname)s %(message)s",
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='/work/log/al/OPM/db_log.0.log',
                    filemode='a')

LOG = logging.getLogger("LOG_NAME")


class DbOperator:
    """ create a db connection to the SQLite db
        specified by database
    :param database: database file"""

    def __init__(self):

        self.db_path = '/home/SYSROM_SRC/mfpmanagement/mfpmanagement.db'
        self.conn = None
        self.curr = None

    def __enter__(self):
        try:
            #LOG.warning("Enter:DbOperator.__enter__")
            #LOG.warning("db path:{}".format(self.db_path))
            self.conn = sqlite3.connect(self.db_path, timeout=12)  # , isolation_level='DEFERRED')
            self.conn.row_factory = sqlite3.Row
            #self.conn.set_trace_callback(LOG.warning)  # log the executed query
            self.curr = self.conn.cursor()

            #self.curr.execute("PRAGMA foreign_keys = ON")
            #LOG.warning("returning cursor obj")
            #self.curr.execute("BEGIN TRANSACTION;")
            return self.curr
        except Exception as exc:
            raise exc

    def __exit__(self, type, value, traceback):

        if traceback is None:
            # No exception, so commit
            if self.conn:
                #LOG.warning("Exit:DbOperator:commiting changes")
                self.conn.commit()
                self.conn.close()
        else:
            # Exception occurred, so rollback.
            if self.conn:
                LOG.warning("Exit:DbOperator:Exception occurred, so rollback")
                self.conn.rollback()
                self.conn.close()
            else:
                LOG.warning("Exit:DbOperator.No Cursor")


class SqlModel:

    def __init__(self, cur=None):
        self.cur = cur

    def create_mfp_table(self, db_data):
        #LOG.warning("sqlmodel.create_mfp_table.enter")
        """
        Check if the table mfp_info exists or not
        if  not create a mfp_info table
        """
        try:
            rows = {}
            cur = self.cur
            columns = ', '.join(db_data.keys())
            placeholders = ':' + ', :'.join(db_data.keys())
            create_query = '''CREATE TABLE IF NOT EXISTS mfp_info
                        (mfp_ip text PRIMARY KEY, mfp_manufacturer text, mfp_model text, mfp_name text, 
                        mfp_status text, stage2_port text, printer_color_type text, mfp_drawers_installed text,
                        mfp_location text, mfp_firmware text, system_software_id text, mfp_serial_number text,
                        build_number text, product text, sub_product text, sub_product_model text, mfp_type text, 
                        faxline1_installed text, faxline2_installed text, finisher_attached text, mfp_destination text, connected text, is_booked text, username text)'''
            insert_query = '''INSERT INTO mfp_info (%s) VALUES (%s)''' % (columns, placeholders)
            select_query = '''SELECT mfp_ip FROM mfp_info WHERE mfp_ip = "{ip}";'''.format(ip=db_data["mfp_ip"])
            cur.execute(create_query)
            cur.execute(select_query)
            exists = cur.fetchall()

            if not exists:
                cur.execute(insert_query, db_data)
            else:
                update_query = '''UPDATE mfp_info SET '''
                [db_data.pop(key) for key in ["is_booked", "username"]] 
                self.update_table_row(update_query, db_data, 'mfp_ip', exists[0][0])

            LOG.warning("sqlmodel.create_mfp_table.exit")
        except Exception as err:
            LOG.exception("sqlmodel.create_mfp_table.error: " + str(err))

    def create_license_table(self, db_data):
        #LOG.warning("sqlmodel.create_license_table.enter")
        """
        Check if the table license_info exists or not
        if  not create a license_info table
        """
        try:
            cur = self.cur
            query = '''CREATE TABLE IF NOT EXISTS license_info
                            (id INTEGER PRIMARY KEY AUTOINCREMENT, license_id text, mfp_ip text, 
                            license_name text, is_enabled text, license_serial_number text, 
                            FOREIGN KEY(mfp_ip) REFERENCES mfp_info(mfp_ip))'''
            columns = ', '.join(db_data.keys())
            placeholders = ':' + ', :'.join(db_data.keys())
            insert_query = 'INSERT INTO license_info (%s) VALUES (%s)' % (columns, placeholders)
            select_query = 'SELECT id FROM license_info WHERE license_name=? and mfp_ip=?'
            cur.execute(query)
            cur.execute(select_query, (db_data['license_name'], db_data['mfp_ip']))
            exists = cur.fetchall()
            if not exists:
                cur.execute(insert_query, db_data)
            else:
                update_query = '''UPDATE license_info SET '''
                self.update_table_row(update_query, db_data, 'id', exists[0][0])

            LOG.warning("sqlmodel.create_license_table.exit")
        except Exception as err:
            LOG.exception("sqlmodel.create_license_table.error: " + str(err))

    def create_drawer_table(self, db_data):
        #LOG.warning("sqlmodel.create_drawer_table.enter")
        """
        Check if the table drawer_info exists or not
        if  not create a drawer_info table
        """
        try:
            cur = self.cur
            query = '''CREATE TABLE IF NOT EXISTS drawer_info
                            (id INTEGER PRIMARY KEY AUTOINCREMENT, drawer_name text, mfp_ip text, 
                            Installation text, Capacity text, RemainingQuantity text, PaperSize text, 
                            FOREIGN KEY(mfp_ip) REFERENCES mfp_info(mfp_ip))'''
            columns = ', '.join(db_data.keys())
            placeholders = ':' + ', :'.join(db_data.keys())
            insert_query = 'INSERT INTO drawer_info (%s) VALUES (%s)' % (columns, placeholders)
            select_query = 'SELECT id FROM drawer_info WHERE drawer_name=? and mfp_ip=?'
            cur.execute(query)
            cur.execute(select_query, (db_data['drawer_name'],db_data["mfp_ip"]))
            exists = cur.fetchall()
            if not exists:
                cur.execute(insert_query, db_data)
            else:
                update_query = '''UPDATE drawer_info SET '''
                self.update_table_row(update_query, db_data, 'id', exists[0][0])

            LOG.warning("sqlmodel.create_drawer_table.exit")
        except Exception as err:
            LOG.exception("sqlmodel.create_drawer_table.error: " + str(err))

    def create_toner_table(self, db_data):
        #LOG.warning("sqlmodel.create_toner_table.enter")
        """
        Check if the table toner_info exists or not
        if  not create a toner_info table
        """
        try:
            cur = self.cur
            query = '''CREATE TABLE IF NOT EXISTS toner_info
                            (id INTEGER PRIMARY KEY AUTOINCREMENT, toner_name text, mfp_ip text, 
                            Installation text, RemainingQuantity text, 
                            FOREIGN KEY(mfp_ip) REFERENCES mfp_info(mfp_ip))'''
            columns = ', '.join(db_data.keys())
            placeholders = ':' + ', :'.join(db_data.keys())
            insert_query = 'INSERT INTO toner_info (%s) VALUES (%s)' % (columns, placeholders)
            select_query = 'SELECT id FROM toner_info WHERE toner_name=? and mfp_ip=?'
            cur.execute(query)
            cur.execute(select_query, (db_data['toner_name'],db_data["mfp_ip"]))
            exists = cur.fetchall()
            if not exists:
                cur.execute(insert_query, db_data)
            else:
                update_query = '''UPDATE toner_info SET '''
                self.update_table_row(update_query, db_data, 'id', exists[0][0])

            LOG.warning("sqlmodel.create_toner_table.exit")
        except Exception as err:
            LOG.exception("sqlmodel.create_toner_table.error: " + str(err))

    def create_jam_table(self, db_data):
        #LOG.warning("sqlmodel.create_jam_table.enter")
        """
        Check if the table jam_info exists or not
        if  not create a jam_info table
        """
        try:
            cur = self.cur
            query = '''CREATE TABLE IF NOT EXISTS jam_info
                            (id INTEGER PRIMARY KEY AUTOINCREMENT, jam_name text, 
                            mfp_ip text, jam_code text, error_level text,
                            FOREIGN KEY(mfp_ip) REFERENCES mfp_info(mfp_ip))'''
            columns = ', '.join(db_data.keys())
            placeholders = ':' + ', :'.join(db_data.keys())
            insert_query = 'INSERT INTO jam_info (%s) VALUES (%s)' % (columns, placeholders)
            select_query = 'SELECT id FROM jam_info WHERE jam_name=? and mfp_ip=?'
            cur.execute(query)
            cur.execute(select_query, (db_data['jam_name'],db_data["mfp_ip"]))
            exists = cur.fetchall()
            if not exists:
                cur.execute(insert_query, db_data)
            else:
                update_query = '''UPDATE jam_info SET '''
                self.update_table_row(update_query, db_data, 'id', exists[0][0])

            LOG.warning("sqlmodel.create_jam_table.exit")
        except Exception as err:
            LOG.exception("sqlmodel.create_jam_table.error: " + str(err))

    def update_table_row(self, query, update_data, id, id_value):
        try:
            placeholders = []
            cur = self.cur
            for col, value in update_data.items():
                query += str(col) + ''' = ?, '''
                placeholders.append(value)

            query = query[0: -2] + ''' WHERE {col} = "{value}"'''.format(col=id, value=id_value)
            cur.execute(query, tuple(placeholders))
        except Exception as exc:
            LOG.exception("sqlmodel.update_table_row.error: " + str(exc))
            raise exc

    def search_data(self, search_text):
        """
        generic search
        """
        try:
            ip_list = []
            LOG.warning("sqlmodel.search_data.enter")
            try:
                with sqlite3.connect("mfpmanagement.db") as conn:
                    conn.row_factory = sqlite3.Row
                    cursor = conn.cursor()
                    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                    for tablerow in cursor.fetchall():
                        table = tablerow[0]
                        cursor.execute("SELECT * FROM {t}".format(t = table))
                        for row in cursor:
                            for field in row.keys():
                                if field not in ["id", "license_serial_number"]:
                                    if search_text.lower() in str(row[field]).lower():
                                        if row["mfp_ip"] not in ip_list:
                                            ip_list.append(row["mfp_ip"])
            except Exception as exc:
                LOG.exception(str(exc))
            return ip_list
        except Exception as err:
            LOG.exception("sqlmodel.search_data.error: " + str(err))

    def drop_row(self):
        """
        Drop the table 
        """
        try:
            #LOG.warning("sqlmodel.drop_row.enter")
            d_mfp_info_query = '''DROP TABLE mfp_info'''
            d_license_info_query = '''DROP TABLE license_info'''
            with DbOperator() as cur:
                cur.execute(d_mfp_info_query)
                cur.execute(d_license_info_query)
            LOG.warning("sqlmodel.drop_row.exit")
        except Exception as err:
            LOG.exception("sqlmodel.drop_row.error" + str(err))

    def delete_row(self, mfp_ips):
        """
        Delete the table 
        """
        try:
            #LOG.warning("sqlmodel.delete_row.enter")
            d_query =  "DELETE FROM mfp_info WHERE mfp_ip IN (" + str(mfp_ips).strip('[]') + ")"
            with DbOperator() as cur:
                cur.execute(d_query)
            LOG.warning("sqlmodel.delete_row.exit")
        except Exception as err:
            LOG.exception("sqlmodel.delete_row.error" + str(err))

    def get_mfp_date(self, ip_list=None):
        """
        Get all the table data
        """
        try:
            #LOG.warning("sqlmodel.get_mfp_date:enter")
            mfp_data = []
            rows = {}
            try:
                if ip_list is not None:
                    query = "SELECT * FROM mfp_info WHERE mfp_ip IN (" + str(ip_list).strip('[]') + ")"
                else:
                    query = '''SELECT * FROM mfp_info'''

                with DbOperator() as cur:
                    cur.execute(query)
                    rows = cur.fetchall()
                for row in rows:
                    mfp_data.append(dict(row))
            except Exception as err:
                LOG.exception("sqlmodel.get_mfp_date.no_table: " + str(err))

            LOG.warning("sqlmodel.get_mfp_date:exit")
            return mfp_data
        except Exception as err:
            LOG.exception("sqlmodel.get_mfp_date.error: " + str(err))
    
    def get_table_data(self, ip, table_name):
        """
        Get all the table data
        """
        try:
            #LOG.warning("sqlmodel.get_table_data:enter")
            table_data = []
            rows = {}
            try:
                query = '''SELECT * FROM {tablename} WHERE mfp_ip = "{ip}";'''.format(tablename=table_name, ip=ip)

                with DbOperator() as cur:
                    cur.execute(query)
                    rows = cur.fetchall()
                for row in rows:
                    table_data.append(dict(row))
            except Exception as err:
                LOG.exception(str(table_name) + " sqlmodel.get_table_data.no_table: " + str(err))

            #LOG.warning(str(table_name) + " sqlmodel.get_table_data:exit")
            return table_data
        except Exception as err:
            LOG.exception(str(table_name) + " sqlmodel.get_table_data.error: " + str(err))

    def get_all_ips(self):
        """
        Get all the ips 
        """
        try:
            ips = []
            rows = []
            try:
                query = '''SELECT mfp_ip FROM mfp_info'''
                with DbOperator() as cur:
                    cur.execute(query)
                    rows = cur.fetchall()
                for ip in rows:
                    ips.append(dict(ip)["mfp_ip"])
            except Exception as err:
                LOG.exception("sqlmodel.get_all_ips.no_table: " + str(err))

            LOG.warning("sqlmodel.get_all_ips:exit")
            return ips
        except Exception as err:
            LOG.exception("sqlmodel.get_all_ips.error: " + str(err))