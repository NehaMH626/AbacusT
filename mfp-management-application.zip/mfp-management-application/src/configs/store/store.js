import {createStore, applyMiddleware, compose} from 'redux';
import thunk from 'redux-thunk';
import {combineReducers} from 'redux';
import {handleActions} from 'redux-actions';
import literals from '../../constants/stringLiterals';
import API_Constants from '../../constants/apiConstants';

//------------------------------
import apiCallReducer from '../../container/Home/Home_Reducer';
import mfpDetailsReducer from "../../container/MFP_Details/MFP_Details_Reducer"

const middleware = [thunk];

var combinedReducers = combineReducers({
    apiCallReducer: apiCallReducer,
    mfpDetailsReducer: mfpDetailsReducer,
    ...{stringLiterals : handleActions({}, literals)},
    ...{apiConstants : handleActions({}, API_Constants)}

})

const initailState = {};
const store = createStore(combinedReducers, initailState, compose(applyMiddleware(...middleware)));

export default store;