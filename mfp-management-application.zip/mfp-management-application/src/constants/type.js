export const SAMPLE_API_CALL_1 = "SAMPLE_API_CALL_1"
export const GET_ERROR = "GET_ERROR"

//----Synchonize Component-----
export const _SyncDatabase_API_Response = "_SyncDatabase_API_Response" 
export const _GetMFPInfo_API_Response = "_GetMFPInfo_API_Response"
export const _Loader = "_Loader"
export const _RefreshIP_API_Response = "_RefreshIP_API_Response"
export const _search_API_Response = "_search_API_Response"

//----MFP Details-----
export const _ProductDetails_API_Response = "_ProductDetails_API_Response"
export const _LicenceInformation_API_Response = "_LicenceInformation_API_Response"
export const _HealthReport_API_Response = "_HealthReport_API_Response"
export const _SoftwareUpgrade_API_Response = "_SoftwareUpgrade_API_Response"
export const _BookMFP_API_Response = '_BookMFP_API_Response'