export default {
    Synchronize :{
        __Synchronize_SynchronizeButton:"Synchronize",
        __Synchronize_SearchPlaceholder:"Search Any(IP, Build, Licence...) details",
        __Synchronize_FetchAll_Button : "Clear Search",
        __Synchronize_DiagnosticCode: "Diagnostic Code",
        __Synchronize_diagnosticCode_address : "http://10.188.101.118:50666/client/index.html"
    },
    SearchBar : {

    },
    DiagnosticTable: {
        __DiagnosticTable_Columns : ["MFP IP","MFP Model", "MFP Serial Number", "Build Number","Product", "MFP Booking", "Location","Refresh"]
    },
    LicenceInformation: {
        __LicenceInfoTable_Columns : ['#','Licence Name','Status']
    },
    HealthReport:{
        __DrawerTableColumns : ['Drawer Name', 'Paper Size', 'Installed'],
        __TonerTableColumns : ['Toner Name', 'Installed'],
        __JamDataTableColumns: ['Jam Name', 'Jam Code', 'Error Level']
    },
    BuildInstallation : {
        __BuildInstall_inputPlaceholder: 'Choose file'
    }
    
};

