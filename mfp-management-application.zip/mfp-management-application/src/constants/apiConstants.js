const API_Constants = {
    apiConfig : {
        __api_route : 'http://10.188.101.118:50777'
    },
    apiPath :  {
        __api_syncDatabase : '/sync_mfp_db',
        __api_getMfpData : '/get_mfp_data',
        __api_searchData : '/get_search_data?search_text=',
        __api_refreshIP: '/refresh_mfp_data?ip=',
        __api_productDetails : '/get_product_data?ip=',
        __api_licenceInformation : '/get_license_data?ip=',
        __api_healthReport: '/get_health_report?ip=',
        __api_softwareUpgarde: '/software_upgrade/',
        __api_bookMFP : '/book_mfp',
        __api_runScripts: '/run_test_script '
    }
}

export default API_Constants;