import React from "react";
import SynchronizeComponent from '../../components/SynchronizeComponent';
import DiagnosticTableComponent from '../../components/DiagnosticTableComponent';
import AppHeader from '../../components/AppHeader';
import '../Home/Home.css';

//---------------------------------


class HomeComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {}
    }
    render(){
        return (<div>
            <AppHeader/>
            {/* <h1>Home</h1> */}
            <div className='component-space'>
            <SynchronizeComponent/>
            <DiagnosticTableComponent history={this.props.history}/>
            </div>
        </div>)
    }
    
}

export default HomeComponent;