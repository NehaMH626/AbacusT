import Axios from 'axios';
import {SAMPLE_API_CALL_1, GET_ERROR} from '../../constants/type';
import {_SyncDatabase_API_Response, _GetMFPInfo_API_Response, _Loader, _RefreshIP_API_Response,_search_API_Response} from '../../constants/type';
import API_Constants from '../../constants/apiConstants'


export const sampleAPI_Call = () => (dispatch) => {

    Axios.get('https://jsonplaceholder.typicode.com/todos/1').then( res => {
        if(res.data) {
            //console.log("response------------------------------------", res.data)
            dispatch({
                type : SAMPLE_API_CALL_1,
                payload: res.data
            });
        }
    }).catch(err => {
        dispatch({
            type: GET_ERROR,
            payload: err
        });
    });
};

export const _SyncDatabase_API = () => (dispatch) => {
    Axios.get(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_syncDatabase}`)
    .then( res => {
        if(res.status === 200) {
            dispatch({
                type : _SyncDatabase_API_Response,
                payload: res.data
            });
        }
    }).catch( err => {
        dispatch({
            type: GET_ERROR,
            payload: err
        })
    })
}

export const _GetMfpData_API = () => (dispatch)=> {
    dispatch({
        type: _Loader,
        payload: true
    });
    Axios.get(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_getMfpData}`)
    .then(res => {
        if(res.status === 200) {
            //console.log(res)
            dispatch({
                type: _GetMFPInfo_API_Response,
                payload: res.data
            });
            dispatch({
                type: _Loader,
                payload: false
            });
            dispatch({
                type:_SyncDatabase_API_Response,
                payload: []
            })
        }
    })
    .catch(err => {
        dispatch({
            type: GET_ERROR,
            payload: err
        })
    })
}

export const _SearchData_API = (text) => (dispatch) => {
    Axios.get(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_searchData+text}`)
    .then(res => {
        if(res.status === 200) {
            dispatch({
                type : _search_API_Response,
                payload: res.data
            })
        }
    })
    .catch(err => {
        dispatch({
            type: GET_ERROR,
            payload: err
        })
    })
}
export const _RefreshIP_API = (mfp_ip) => async dispatch => {
    const response = await Axios.get(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_refreshIP+mfp_ip}`)
    return response.data;
}

// export const _RefreshIP_API = (mfp_ip) => async dispatch => {

//     try {
//         const response = await Axios.get(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_refreshIP+mfp_ip}`)

//     }
//     catch (err) {

//     }

//     Axios.get(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_refreshIP+mfp_ip}`)
//     .then(res => {
//         console.log("Refresh API response ", res);
//         if(res.status === 200) {
//             dispatch({
//                 type: _RefreshIP_API_Response,
//                 payload: res.data
//             });
//         }
//     })
//     .catch(err => {
//         dispatch({
//            type: GET_ERROR,
//            payload: err 
//         });
//     })

// }