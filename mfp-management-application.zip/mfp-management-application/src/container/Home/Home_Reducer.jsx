
import {SAMPLE_API_CALL_1, GET_ERROR} from '../../constants/type';
import {_SyncDatabase_API_Response, _GetMFPInfo_API_Response, _Loader, _RefreshIP_API_Response,_search_API_Response} from '../../constants/type';

const initailState = {
    api_call1_response : [],
    api_err_response : null,
    _sync_database_response: [],
    _getMFP_info_response: [],
    _loading : false,
    _refreshIP_response: [],
    _searchData_response: []
}
export default function(state = initailState, action){
    switch (action.type) {

        case SAMPLE_API_CALL_1:
            return {
                ...state,
                api_call1_response : action.payload
            }

        case GET_ERROR:
            return {
                ...state,
                api_err_response: action.payload

            }

        //--------------------------------------------
        case _SyncDatabase_API_Response:
           
            return{
                ...state,
                _sync_database_response : action.payload
            }
        
        // case _SyncDatabase_API_ERR:
        //     return{
        //         ...state,
        //         _sync_database_error :  action.payload
        //     }
        //-----------------------------------------------
        case _GetMFPInfo_API_Response:
           //console.log(action.payload)
            return{
                ...state,
                _getMFP_info_response: action.payload
            }

        case _Loader:
            return {
                ...state,
                _loading : action.payload
            }
        case _RefreshIP_API_Response:
            
            return {
                ...state,
                _refreshIP_response: action.payload
            }
        case _search_API_Response:
            return{
                ...state,
                _searchData_response : action.payload
            }

        default:
            return state
    }
};
