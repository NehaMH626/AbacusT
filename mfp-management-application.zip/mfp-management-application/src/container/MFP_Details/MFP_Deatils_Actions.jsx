import Axios from 'axios';
import API_Constants from '../../constants/apiConstants'
import {_BookMFP_API_Response,_Loader,_ProductDetails_API_Response,_LicenceInformation_API_Response,GET_ERROR,_HealthReport_API_Response,_SoftwareUpgrade_API_Response} from  '../../constants/type'

export const _ProductDetails_API = (ipAddr) => (dispatch) => {
    Axios.get(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_productDetails+ipAddr}`)
    .then(res =>{
        if(res.status === 200){
            dispatch({
                type: _ProductDetails_API_Response,
                payload: res.data
            })
        }
    }
    )
    .catch(err => {
        dispatch({
            type: GET_ERROR,
            payload: err
        })
    })
}

export const _LicenceInformation_API = (ipAddr) => (dispatch) => {
    Axios.get(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_licenceInformation+ipAddr}`)
    .then(res => {
        if(res.status === 200) {
            dispatch({
                type: _LicenceInformation_API_Response,
                payload: res.data
            })
        }
    })
    .catch(err => {
        dispatch({
            type: GET_ERROR,
            payload: err
        })
    })
}

export const _HealthReport_API = (ipAddr) => (dispatch) => {
    Axios.get(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_healthReport+ipAddr}`)
    .then(res => {
        if(res.status === 200){
            dispatch({
                type : _HealthReport_API_Response,
                payload: res.data
            })
        }
    })
    .catch(err => {
        dispatch({
            type: GET_ERROR,
            payload: err
        })
    })
}

// export const _SoftwareUpgrade_API = (postBody) => (dispatch) => {
//     dispatch({
//         type: _Loader,
//         payload: true
//     });
//     console.log("Software upgrade API", postBody);
//     Axios.post(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_softwareUpgarde}`,postBody)
//     .then(res => {
//         console.log("Software upgrade API", res);
//         if(res.status === 200){
//             dispatch({
//                 type : _SoftwareUpgrade_API_Response,
//                 payload: res.data
//             })
//             dispatch({
//                 type: _Loader,
//                 payload: false
//             });
//         }
//     })
//     .catch( err => {
//         dispatch({
//             type : GET_ERROR,
//             payload: err
//         })
//     }
//     )
// }

export const _SoftwareUpgrade_API = (postBody,mfpIP) => async dispatch => {
    const softwareUpgradeResponse = await Axios.post(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_softwareUpgarde+mfpIP}`,postBody)
    //console.log('software upgrade..', softwareUpgradeResponse.data);
    return softwareUpgradeResponse.data;
}

export const _BookMFP_API = (postBody) => async(dispatch) => {
    const bookMfpResponse = await Axios.post(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_bookMFP}`,postBody)
    //console.log('book MFP...', bookMfpResponse.data);
    return bookMfpResponse.data;
}
// export const _BookMFP_API = (postBody) => (dispatch) => {
//     console.log("Book MFP API");
//     Axios.post(`${API_Constants.apiConfig.__api_route+API_Constants.apiPath.__api_bookMFP}`,postBody)
//     .then(res => {
//         console.log("Book MFP API", res);
//         if(res.status === 200){
//             dispatch({
//                 type : _BookMFP_API_Response,
//                 payload: res.data
//             })
//         }
//     })
//     .catch(err => {
//         dispatch({
//             type: GET_ERROR,
//             payload: err
//         })
//     })
// }
