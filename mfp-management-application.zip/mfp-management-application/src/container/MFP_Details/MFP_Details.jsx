import React from 'react';
import AppHeader from '../../components/AppHeader';
import SubComponent from "../../components/DetailsSubComponent";
import '../Home/Home.css';
import '../MFP_Details/MFP_Details.css'
class MFP_Details extends React.Component{

    render(){
      
        return(<div>
            <AppHeader/> 
            <SubComponent/>
        </div>)
        // return(<div>
        //     <AppHeader/> 
        //     <h1>MFP Details</h1>
        //     <IpDetails/>
            
        // </div>)
    }
}

export default MFP_Details;