import {
  _ProductDetails_API_Response,
  _LicenceInformation_API_Response,
  GET_ERROR,
  _HealthReport_API_Response,
  _SoftwareUpgrade_API_Response,_Loader,_BookMFP_API_Response
} from "../../constants/type";

const initailState = {
  _productDetails_api_response: [],
  _healthReport_api_response: [],
  _licenceInformation_Api_response: [],
  _err_response: [],
  _loading: false,
};

export default function (state = initailState, action) {
  switch (action.type) {
    case _ProductDetails_API_Response:
      return {
        ...state,
        _productDetails_api_response: action.payload,
      };

    case _LicenceInformation_API_Response:
      return {
        ...state,
        _licenceInformation_Api_response: action.payload,
      };
    case _HealthReport_API_Response:
      return {
        ...state,
        _healthReport_api_response: action.payload,
      };
    case _SoftwareUpgrade_API_Response:

      return {
        ...state,
        _softwareUpgarde_api_response: action.payload,
      };
    case _Loader:
      return {
        ...state,
        _loading: action.payload,
      };
    case _BookMFP_API_Response:
      
      return{
        ...state,
        _bookMFP_api_response: action.payload
      }
    case GET_ERROR:
      return {
        ...state,
        _err_response: action.payload,
      };
    default:
      return state;
  }
}
