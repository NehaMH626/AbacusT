import React,{Component} from 'react';
//import logo from './logo.svg';
import './App.css';
import {Provider} from 'react-redux'
import store from '../src/configs/store/store';
import {BrowserRouter as Router, Route, Switch} from "react-router-dom";
import HomeComponent from '../src/container/Home/Home';
import MFP_Details from "../src/container/MFP_Details/MFP_Details"
// import AppHeader from '../src/components/AppHeader';
// import ProductDetails from './components/ProductDetails';
// import LicenceInformation from './components/LicenceInformation';
// import HealthReport from './components/HealthReport';
// import BuildInstallation from './components/BuildInstallation';
// import BookMFP from './components/BookMFP';
// import RunTestScripts from "./components/RunTestScripts"

class App extends Component{
 
  render(){
   
    return(
    
      <Provider store={store}> 
        <Router history={this.props.history}> 
          <Switch>
            <Route path="/client/index.html" component={HomeComponent}></Route>
            <Route path="/MFP_Details" component={MFP_Details}></Route>
           
            {/* <Route exact path="/" component={HomeComponent}></Route>
            <Route path="/MFP_Details" component={MFP_Details}></Route> */}
            
          </Switch>
        </Router>
      </Provider>
      
    )
  }
}

export default App;