import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { Card, InputGroup, FormControl } from "react-bootstrap";
import SearchIcon from "@material-ui/icons/Search";
import * as Notify from "../components/Notification";
import { ToastContainer, toast } from "react-toastify";
import diagnosticCodeImage from '../../src/images/diagnosticCode.png'
import Button from '@material-ui/core/Button';

// ------------------------------------------
import {
  sampleAPI_Call,
  _SyncDatabase_API,
  _GetMfpData_API,
  _SearchData_API,
} from "../container/Home/Home_Actions";

class SynchronizeComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      _synced_res: this.props._sync_database_response,
      _syncronizing: false,
      _search_Input_Text: "",
      _sync_disable: false
    };
  }

  componentDidMount(){
    this.setState({_sync_disable: this.props._getMFP_info_response['sync_enable']})
  }
  componentDidUpdate(prevProps) {
    if (
      prevProps._sync_database_response !== this.props._sync_database_response
    ) {
      if (this.props._sync_database_response["status"] === "success") {
        var syncData = setInterval(() => {
          this.props._GetMfpData_API();
        }, 60000);

        setTimeout(() => {
          this.setState({ _syncronizing: false });
          clearInterval(syncData);
        }, 480000);
      }
    }

    if(prevProps._getMFP_info_response['sync_enable'] !== this.props._getMFP_info_response['sync_enable']){
      this.setState({_sync_disable : this.props._getMFP_info_response['sync_enable']})
      
    }
    if(prevProps._searchData_response['sync_enable'] !== this.props._searchData_response['sync_enable']){
      this.setState({_sync_disable : this.props._searchData_response['sync_enable']})
    }
  }

  // sync data with database on click of sync button
  _Sync_MFPData_To_Database = () => {
    this.props._SyncDatabase_API();

    this.setState({ _syncronizing: true });
    Notify.success("Syncing data...!!!");
  };

  //SearchData on click of serach button
  _SearchData = () => {
    if (this.state._search_Input_Text !== "") {
      this.props._SearchData_API(this.state._search_Input_Text);
    } else {
      Notify.error("Please enter the text !!!");
    }
  };

  _getInputVal = (e) => {
    this.setState({ _search_Input_Text: e.target.value });
  };

  // get diagnostic codes
  _Get_DiagnosticCodes = () => {
    window.open("http://10.188.101.118:50666/client/index.html", "_blank");
  };

  //_FetchAll_MFP_Data on click of clear search button
  _FetchAll_MFP_Data = () => {
    this.setState({ _search_Input_Text: "" });
    Notify.success("Updating...");
    this.props._GetMfpData_API();
  };

  render() {
    return (
      <div>
      <div className="row row-marginTop">
        <div style={{ display: "inline-block" }} className="col-md-3">
          <Card Body>
            <div className="CardBody">
              <div className="padding-space">
                <div style={{ display: "inline-block" }}>
                  <Button
                    className="btn btn-display syncView-Button action-btn"
                    onClick={this._Sync_MFPData_To_Database}
                    variant='contained'
                    disabled={this.state._sync_disable}
                  >
                    {this.state._syncronizing ? (
                      <i className="fa fa-spinner fa-pulse icon-padding"></i>
                    ) : (
                      <i className="fa fa-play icon-padding"></i>
                    )}
                  </Button>
                  <p>
                    {
                      this.props.StringLiterals.Synchronize
                        .__Synchronize_SynchronizeButton
                    }
                  </p>
                </div>
                <div style={{ display: "inline-block" }}>
                  <Button
                    className="btn btn-display syncView-Button action-btn"
                    onClick={this._FetchAll_MFP_Data}
                    variant='contained'
                  >
                    <i class="fa fa-refresh icon-padding"></i>
                  </Button>
                  <p>
                    {
                      this.props.StringLiterals.Synchronize
                        .__Synchronize_FetchAll_Button
                    }
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </div>
        <div style={{ display: "inline-block" }} className="col-md-9">
        <Card Body >
          <div className="CardBody">
            <div className="input-paddingSpace full-width">
              <div>
                <InputGroup>
                  <FormControl
                    className="input"
                    placeholder={
                      this.props.StringLiterals.Synchronize
                        .__Synchronize_SearchPlaceholder
                    }
                    aria-label="Search..."
                    aria-describedby="basic-addon2"
                    onChange={this._getInputVal}
                    value={this.state._search_Input_Text}
                    autoComplete="on"
                    name ="SearchText"
                  />
                  <InputGroup.Append className="inputGroupButton-zIndex"> 
                    <Button onClick={this._SearchData} className="searchBtn action-btn borderRadius">
                      <SearchIcon />
                    </Button>
                  </InputGroup.Append>
                </InputGroup>
                {/* <p style={{ paddingLeft: "0px" }}>
                  <a
                    href={
                      this.props.StringLiterals.Synchronize
                        .__Synchronize_diagnosticCode_address
                    }
                    target="blank"
                    className="diagnostic-link"
                  >
                    Diagnostic Codes >>{" "}
                  </a>
                </p> */}
              </div>
            </div>
          </div>
        </Card>
        </div>
        {/* <h1>{this.props.StringLiterals.Synchronize.name}</h1> */}
        <ToastContainer />
      </div>
        <div className="row row-marginTop">
        <div className="col-md-12">
          <Card className="flexDirection-Row">
           <Card.Img className ="diagnosticCodeImg" src={diagnosticCodeImage}></Card.Img>
            <Card.Text className="cardText-marginTop-0 diagnosticCardText"><a
                    href={
                      this.props.StringLiterals.Synchronize
                        .__Synchronize_diagnosticCode_address
                    }
                    target="blank"
                   
                  >
                    Diagnostic Codes >>{" "}
                  </a></Card.Text>
           
          </Card>
          </div>
        </div>
      </div>

    );
  }
}
const mapStateToProps = (store) => {
  return {
    StringLiterals: store.stringLiterals,
    sample_api_response: store.apiCallReducer.api_call1_response,
    api_err_response: store.apiCallReducer.api_err_response,
    _sync_database_response: store.apiCallReducer._sync_database_response,
    _searchData_response: store.apiCallReducer._searchData_response,
    _getMFP_info_response: store.apiCallReducer._getMFP_info_response,
  };
};

const mapDispatchToProps = (dispatch) => ({
  sampleAPI_Call: (payload) => dispatch(sampleAPI_Call(payload)),
  _SyncDatabase_API: (payload) => dispatch(_SyncDatabase_API(payload)),
  _GetMfpData_API: (payload) => dispatch(_GetMfpData_API(payload)),
  _SearchData_API: (payload) => dispatch(_SearchData_API(payload)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(SynchronizeComponent));
