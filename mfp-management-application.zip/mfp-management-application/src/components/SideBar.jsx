import React, { useState, useEffect } from "react";
import "../container/MFP_Details/MFP_Details.css";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import {
  _ProductDetails_API,
  _LicenceInformation_API,
  _HealthReport_API
} from "../container/MFP_Details/MFP_Deatils_Actions";
import {_GetMfpData_API} from '../container/Home/Home_Actions'
import { BrowserRouter as Link } from "react-router-dom";

// Side Nav bar user options
class SideBarNav extends React.Component{
  constructor(props){
    super(props);
    this.state ={
      selectedOption: "Product"
    }
  }
  
  // choose product deatils options
  getProductDetails = (currentIP) => {
    this.setState({selectedOption:"Product"})
    //setSelectedOption("Product")
    this.props.content("Product");
    this.props._ProductDetails_API(currentIP);
    //console.log("selected",this.state.selectedOption);
   
  };

  // choose licence deatils options
  getLicenceDetails = (currentIP) => {
    this.setState({selectedOption:"Licence"})
    this.props.content("Licence");
    this.props._LicenceInformation_API(currentIP);
    //console.log("selected",this.state.selectedOption); 
  };

  // go back to home page
  backToHomePage = () => {
    this.props.history.push("/client/index.html");
    localStorage.removeItem('isBooked');
    localStorage.removeItem('currentIP');
    localStorage.removeItem('userName');
    this.props._GetMfpData_API();
  };

  // choose health report details
  getHealthReport = (currentIP) => {
    this.setState({selectedOption:"Health"})
    this.props.content("Health");
    this.props._HealthReport_API(currentIP);
  };

  // choose build installation option
  getBuildInstalled = () => {
    this.setState({selectedOption:"BuildInstall"})
    this.props.content("BuildInstall");
  };

  // choose book MFP option
  getBookMFP = () => {
    this.setState({selectedOption:"BookMFP"})
    this.props.content("BookMFP");
  };

  // choose run test scripts option
  getTestScrips = () => {
    this.setState({selectedOption:"TestScrips"})
    this.props.content("TestScrips");
  };
render(){
  let currentIP = localStorage.getItem("currentIP");
  return (
    <div className="sidenav">
      {/* <ul>
        
          <Link
            to="MFP_Details/ProductDetails"
            
          >
              <li onClick={getProductDetails(currentIP)}><i className="fa fa-list-alt sidenav-icons"></i>Product Details</li>


            
          </Link>
        
        <li>
          <Link
            to="MFP_Details/LicenceInformation"
            onClick={getLicenceDetails(currentIP)}
          >
            <i className="fa fa-info-circle sidenav-icons"></i>Licence
            Information
          </Link>
        </li>
        <li>
          <Link
            to="MFP_Details/HealthReport"
            onClick={getHealthReport(currentIP)}
          >
            <i className="fa fa-line-chart sidenav-icons"></i>Health Report
          </Link>
        </li>
        <li>
          <Link
            to="MFP_Details/BuildInstallation"
            onClick={getBuildInstalled(currentIP)}
          >
            <i className="fa fa-print sidenav-icons"></i>Build Installation
          </Link>
        </li>
        <li>
          <Link to="MFP_Details/BookMFP" onClick={getBookMFP(currentIP)}>
            <i className="fa fa-calendar sidenav-icons"></i>Book MFP
          </Link>
        </li>
        <li>
          <Link
            to="MFP_Details/TestScripts"
            onClick={getTestScrips(currentIP)}
          >
            <i className="fa fa-file-code-o sidenav-icons"></i>Run Test Scripts
          </Link>
        </li>
        <li>
          <Link to="/" onClick={backToHomePage()}>
            <i
              className="fa fa-home sidenav-icons"
              
            ></i>
            Home
          </Link>
        </li>
      </ul>
       */}
      
      
      <a href="#Product_Details"  className ={this.state.selectedOption === "Product" && "activeOption"} onClick={() => this.getProductDetails(currentIP)}>
        <i className="fa fa-list-alt sidenav-icons"></i>Product Details
      </a>
      <a href="#Licence Details"  className ={this.state.selectedOption === "Licence" && "activeOption"}  onClick={() => this.getLicenceDetails(currentIP)}>
        <i className="fa fa-info-circle sidenav-icons"></i>Licence Information
      </a>
      
      <a href="#Health Report" className ={this.state.selectedOption === "Health" && "activeOption"} onClick={() =>this.getHealthReport(currentIP)}>
        <i className="fa fa-line-chart sidenav-icons"></i>Health Report
      </a>
      <a
       className ={this.state.selectedOption === "BuildInstall" && "activeOption"} 
        href="#Build Installation"
        onClick={() => this.getBuildInstalled(currentIP)}
      >
        <i className="fa fa-print sidenav-icons"></i>Build Installation
      </a>
      <a  className ={this.state.selectedOption === "BookMFP" && "activeOption"} href="#Book MFP" onClick={() => this.getBookMFP(currentIP)}>
        <i className="fa fa-calendar sidenav-icons"></i>Book MFP
      </a>
      <a className ={this.state.selectedOption === "TestScrips" && "activeOption"} href="#Test Scrips" onClick={() => this.getTestScrips(currentIP)}>
        <i className="fa fa-file-code-o sidenav-icons"></i>Run Test Scripts
      </a>
      <a href="javascript:void(0)" onClick={() => this.backToHomePage()}>
        {" "}
        <i className="fa fa-home sidenav-icons"></i>Home
      </a>
      
    </div>
  );

}

}

// const SideBarNav = (props) => {
//   const[selectedOption, setSelectedOption] = useState(null);
//   useEffect(()=>{
    
//   },[selectedOption])
//   let currentIP = localStorage.getItem("currentIP");
//   const getProductDetails = (currentIP) => {
//     setSelectedOption("Product")
//     props.content("Product");
//     props._ProductDetails_API(currentIP);
//     console.log("selected",selectedOption);
   
//   };
//   const getLicenceDetails = (currentIP) => {
//     setSelectedOption("Licence")
//     props.content("Licence");
//     props._LicenceInformation_API(currentIP);
//     console.log("selected",selectedOption); 
//   };
//   const backToHomePage = () => {
//     props.history.push("/client/index.html");
//     props._GetMfpData_API();
//   };

//   const getHealthReport = (currentIP) => {
//     props.content("Health");
//     props._HealthReport_API(currentIP);
//   };

//   const getBuildInstalled = () => {
//     props.content("BuildInstall");
//   };
//   const getBookMFP = () => {
//     props.content("BookMFP");
//   };
//   const getTestScrips = () => {
//     props.content("TestScrips");
//   };
//   return (
//     <div className="sidenav">
//       {/* <ul>
        
//           <Link
//             to="MFP_Details/ProductDetails"
            
//           >
//               <li onClick={getProductDetails(currentIP)}><i className="fa fa-list-alt sidenav-icons"></i>Product Details</li>


            
//           </Link>
        
//         <li>
//           <Link
//             to="MFP_Details/LicenceInformation"
//             onClick={getLicenceDetails(currentIP)}
//           >
//             <i className="fa fa-info-circle sidenav-icons"></i>Licence
//             Information
//           </Link>
//         </li>
//         <li>
//           <Link
//             to="MFP_Details/HealthReport"
//             onClick={getHealthReport(currentIP)}
//           >
//             <i className="fa fa-line-chart sidenav-icons"></i>Health Report
//           </Link>
//         </li>
//         <li>
//           <Link
//             to="MFP_Details/BuildInstallation"
//             onClick={getBuildInstalled(currentIP)}
//           >
//             <i className="fa fa-print sidenav-icons"></i>Build Installation
//           </Link>
//         </li>
//         <li>
//           <Link to="MFP_Details/BookMFP" onClick={getBookMFP(currentIP)}>
//             <i className="fa fa-calendar sidenav-icons"></i>Book MFP
//           </Link>
//         </li>
//         <li>
//           <Link
//             to="MFP_Details/TestScripts"
//             onClick={getTestScrips(currentIP)}
//           >
//             <i className="fa fa-file-code-o sidenav-icons"></i>Run Test Scripts
//           </Link>
//         </li>
//         <li>
//           <Link to="/" onClick={backToHomePage()}>
//             <i
//               className="fa fa-home sidenav-icons"
              
//             ></i>
//             Home
//           </Link>
//         </li>
//       </ul>
//        */}
//        <ul>
//       <li className ={props.selectedOption === "Product" && "activeOption"}>
//       <a href="#Product_Details"  onClick={() => getProductDetails(currentIP)}>
//         <i className="fa fa-list-alt sidenav-icons"></i>Product Details
//       </a></li>
//       <li className ={props.selectedOption === "Licence" && "activeOption"}>
//       <a href="#Licence Details"  onClick={() => getLicenceDetails(currentIP)}>
//         <i className="fa fa-info-circle sidenav-icons"></i>Licence Information
//       </a>
//       </li>
//       <a href="#Health Report" onClick={() => getHealthReport(currentIP)}>
//         <i className="fa fa-line-chart sidenav-icons"></i>Health Report
//       </a>
//       <a
//         href="#Build Installation"
//         onClick={() => getBuildInstalled(currentIP)}
//       >
//         <i className="fa fa-print sidenav-icons"></i>Build Installation
//       </a>
//       <a href="#Book MFP" onClick={() => getBookMFP(currentIP)}>
//         <i className="fa fa-calendar sidenav-icons"></i>Book MFP
//       </a>
//       <a href="#Test Scrips" onClick={() => getTestScrips(currentIP)}>
//         <i className="fa fa-file-code-o sidenav-icons"></i>Run Test Scripts
//       </a>
//       <a href="javascript:void(0)" onClick={() => backToHomePage()}>
//         {" "}
//         <i className="fa fa-home sidenav-icons"></i>Home
//       </a>
//       </ul>
//     </div>
//   );
// };

const mapStateToProps = (store) => {
  return {
    StringLiterals: store.StringLiterals,
    _productDetails_api_response: store._productDetails_api_response,
    _healthReport_api_response: store._healthReport_api_response,
    _licenceInformation_Api_response: store._licenceInformation_Api_response,
    _err_response: store._err_response,
  };
};

const mapDispatchToProps = (dispatch) => ({
  _ProductDetails_API: (payload) => dispatch(_ProductDetails_API(payload)),
  _LicenceInformation_API: (payload) =>
    dispatch(_LicenceInformation_API(payload)),
  _HealthReport_API: (payload) => dispatch(_HealthReport_API(payload)),
  _GetMfpData_API: (payload) => dispatch(_GetMfpData_API(payload)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(SideBarNav));
//export default SideBarNav;
