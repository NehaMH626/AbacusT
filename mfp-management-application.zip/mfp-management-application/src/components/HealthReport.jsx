import React from "react";
//import {Bar} from 'react-chartjs-2';
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { _HealthReport_API } from "../../src/container/MFP_Details/MFP_Deatils_Actions";
import { Container, Card, Table, CardDeck, Row, Col } from "react-bootstrap";
import "../container/MFP_Details/MFP_Details.css";
// import BarChart from "../components/BarChart";
import { Bar } from "react-chartjs-2";

// const healthData = {
//   drawer_data: [
//     {
//       id: 226,
//       drawer_name: "Drawer1",
//       mfp_ip: "10.188.102.141",
//       Installation: "Installed",
//       Capacity: "550",
//       RemainingQuantity: "100%",
//       PaperSize: "LEGAL-R",
//     },
//     {
//       id: 227,
//       drawer_name: "Drawer2",
//       mfp_ip: "10.188.102.141",
//       Installation: "Installed",
//       Capacity: "550",
//       RemainingQuantity: "0%",
//       PaperSize: "LETTER-R",
//     },
//     {
//       id: 228,
//       drawer_name: "Drawer3",
//       mfp_ip: "10.188.102.141",
//       Installation: "Installed",
//       Capacity: "550",
//       RemainingQuantity: "0%",
//       PaperSize: "LETTER-R",
//     },
//     {
//       id: 229,
//       drawer_name: "Drawer4",
//       mfp_ip: "10.188.102.141",
//       Installation: "Installed",
//       Capacity: "550",
//       RemainingQuantity: "0%",
//       PaperSize: "LETTER-R",
//     },
//     {
//       id: 230,
//       drawer_name: "LCF",
//       mfp_ip: "10.188.102.141",
//       Installation: "NotInstalled",
//       Capacity: "0",
//       RemainingQuantity: "0",
//       PaperSize: "A4",
//     },
//   ],
//   toner_data: [
//     {
//       id: 181,
//       toner_name: "Y",
//       mfp_ip: "10.188.102.141",
//       Installation: "Installed",
//       RemainingQuantity: "100%",
//     },
//     {
//       id: 182,
//       toner_name: "M",
//       mfp_ip: "10.188.102.141",
//       Installation: "Installed",
//       RemainingQuantity: "100%",
//     },
//     {
//       id: 183,
//       toner_name: "C",
//       mfp_ip: "10.188.102.141",
//       Installation: "Installed",
//       RemainingQuantity: "100%",
//     },
//     {
//       id: 184,
//       toner_name: "K",
//       mfp_ip: "10.188.102.141",
//       Installation: "Installed",
//       RemainingQuantity: "100%",
//     },
//   ],
//   jam_data: [
//     {
//       id: 124,
//       jam_name: "YellowTonerNearEmpty",
//       mfp_ip: "10.188.102.141",
//       jam_code: "D324",
//       error_level: "Warning",
//     },
//     {
//       id: 125,
//       jam_name: "SFBPaperEmpty",
//       mfp_ip: "10.188.102.141",
//       jam_code: "D102",
//       error_level: "Warning",
//     },
//     {
//       id: 126,
//       jam_name: "Drawer2PaperEmpty",
//       mfp_ip: "10.188.102.141",
//       jam_code: "D104",
//       error_level: "Warning",
//     },
//     {
//       id: 127,
//       jam_name: "Drawer3PaperEmpty",
//       mfp_ip: "10.188.102.141",
//       jam_code: "D105",
//       error_level: "Warning",
//     },
//     {
//       id: 128,
//       jam_name: "Drawer4PaperEmpty",
//       mfp_ip: "10.188.102.141",
//       jam_code: "D106",
//       error_level: "Warning",
//     },
//   ],
// };
// Display drawer, toner and jam details
class HealthReport extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      healthData: {},
      options: { scales: { yAxes: [{ ticks: { beginAtZero: true, suggestedMax: 100 } }] } },
    };
  }

  componentDidUpdate(prevProps) {
    if (
      prevProps.healthReport_api_response !==
      this.props.healthReport_api_response
    ) {
      this.setState({ healthData: this.props.healthReport_api_response });
    }
  }

  render() {
    let TonerChartData;
    let drawerChartData;
    if(Object.keys(this.state.healthData).length) {
      drawerChartData = {
        labels: this.state.healthData?.drawer_data
          .filter((drawerName) => drawerName.Installation !== "NotInstalled")
          .map((drawerName) => drawerName.drawer_name),
        datasets: [
          {
            label: "Drawer Remaining Quantity(%)",
            backgroundColor: "#236f73",
            borderColor: "rgba(0,0,0,1)",
            borderWidth: 2,
            data: this.state.healthData?.drawer_data
              .filter((drawerName) => drawerName.Installation !== "NotInstalled")
              .map((drawerName) =>
                drawerName.RemainingQuantity.replace(/%/g, "")
              ),
          },
        ],
      };
  
      TonerChartData = {
        labels: this.state.healthData?.toner_data
          .filter((tonerName) => tonerName.Installation !== "NotInstalled")
          .map((tonerName) => tonerName.toner_name),
        datasets: [
          {
            label: "Toner Remaining Quantity(%)",
            backgroundColor: "#236f73",
            borderColor: "rgba(0,0,0,1)",
            borderWidth: 2,
            data: this.state.healthData?.toner_data
              .filter((tonerName) => tonerName.Installation !== "NotInstalled")
              .map((tonerName) => tonerName.RemainingQuantity.replace(/%/g, "")),
          },
        ],
      };
  
    }
    
    return (
      <div>
        <Container className="mfpDetails-container">
          <h5>Health Report</h5>
          <Card>
            <Card.Header className="details-header">Drawer Details</Card.Header>
            <div className="row">
              <div className="col-md-6 col-sm-12 col-lg-6">
                <Card.Body>
                  <Table bordered className="productData-Table tableHeader-color">
                    <thead>
                      <tr>
                        {this.props.stringLiterals.HealthReport.__DrawerTableColumns.map(
                          (colNames) => (
                            <th>{colNames}</th>
                          )
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      { Object.keys(this.state.healthData).length ? this.state.healthData?.drawer_data.map(
                        (drawerData, index) => {
                          return (
                            <tr>
                              <td>{drawerData.drawer_name}</td>
                              <td>{drawerData.PaperSize}</td>
                              <td>{drawerData.Installation}</td>
                            </tr>
                          );
                        }
                      ): null}
                    </tbody>
                  </Table>
                </Card.Body>
              </div>
              <div className="col-md-6 col-sm-12 col-lg-6">
                <Card.Body>
                  <Bar data={drawerChartData} width={100} height={70} options={this.state.options}/>
                </Card.Body>
              </div>
            </div>
          </Card>
          <Card>
            <Card.Header className="details-header">Toner Details</Card.Header>
            <div className="row">
              <div className="col-md-6 col-sm-12 col-lg-6">
                <Card.Body>
                  <Table bordered className="productData-Table tableHeader-color">
                    <thead>
                      <tr>
                        {this.props.stringLiterals.HealthReport.__TonerTableColumns.map(
                          (colNames) => (
                            <th>{colNames}</th>
                          )
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {Object.keys(this.state.healthData).length ? this.state.healthData?.toner_data.map(
                        (tonerData, index) => {
                          return (
                            <tr>
                              <td>{tonerData.toner_name}</td>
                              <td>{tonerData.Installation}</td>
                            </tr>
                          );
                        }
                      ):null}
                    </tbody>
                  </Table>
                </Card.Body>
              </div>
              <div className="col-md-6 col-sm-12 col-lg-6">
                <Card.Body>
                  <Bar
                    options={this.state.options}
                    data={TonerChartData}
                    width={100}
                    height={70}
                  />
                </Card.Body>
              </div>
            </div>
          </Card>
          <Card>
            <Card.Header className="details-header">Jam Details</Card.Header>
            <div className="row">
              <div className="col-md-12 col-sm-12 col-lg-12">
                <Table className="productData-Table tableHeader-color">
                  <thead>
                    <tr>
                      {this.props.stringLiterals.HealthReport.__JamDataTableColumns.map(
                        (colNames) => (
                          <th>{colNames}</th>
                        )
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {Object.keys(this.state.healthData).length ? this.state.healthData?.jam_data.map((jamData, index) => {
                      return (
                        <tr>
                          <td>{jamData.jam_name}</td>
                          <td>{jamData.jam_code}</td>
                          <td>{jamData.error_level}</td>
                        </tr>
                      );
                    }):null}
                  </tbody>
                </Table>
              </div>
            </div>
          </Card>
        </Container>
      </div>
    );
  }
}

const mapStateToProps = (store) => {
  return {
    stringLiterals: store.stringLiterals,
    healthReport_api_response: store.mfpDetailsReducer._healthReport_api_response,
  };
};

const mapDispatchToProps = (dispatch) => ({
  //     _HealthReport_API: (payload) => dispatch(_HealthReport_API(payload))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(HealthReport));
//export default HealthReport;
