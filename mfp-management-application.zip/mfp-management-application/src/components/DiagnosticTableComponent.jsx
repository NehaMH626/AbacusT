import React, { Component } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Table from "react-bootstrap/Table";
import "../container/Home/Home.css";
import { Card } from "react-bootstrap";
import {
  _GetMfpData_API,
  _RefreshIP_API,
} from "../container/Home/Home_Actions";
import { _ProductDetails_API } from "../container/MFP_Details/MFP_Deatils_Actions";
import PageLoader from "../components/Loader";
import RefreshIcon from "@material-ui/icons/Refresh";
import * as Notify from "../components/Notification";

// Table to display initial set of data from DB when browser loads 
class DiagnosticTableComponent extends Component {
  componentDidMount() {
    this.props._GetMfpData_API();
  }

  componentDidUpdate(prevProps) {
    if (prevProps._getMFP_info_response !== this.props._getMFP_info_response) {
      this.setState({ _synced_MFP_details: this.props._getMFP_info_response });
    }

    if (prevProps._searchData_response !== this.props._searchData_response) {
      this.setState({ _synced_MFP_details: this.props._searchData_response });
    }
  }

  // refresh IP details
  _RefreshIP_Details = async (mfp_ip) => {
    const refreshedIP_response = await this.props._RefreshIP_API(mfp_ip);

    this.setState({ refreshedIP_response: refreshedIP_response });
    this.setState({ _refreshedIP_Info: refreshedIP_response.data });
    if (refreshedIP_response.status === "failed") {
      Notify.error("Failed to update !!!");
     
    } else {
      let allMFP_data = this.state._synced_MFP_details;
      let refreshIP_index = allMFP_data.findIndex(
        (data) => data.mfp_ip === mfp_ip
      );
      allMFP_data[refreshIP_index] = refreshedIP_response.data;
      this.setState({ _synced_MFP_details: allMFP_data });
      Notify.success(`Updated ${mfp_ip} !!!`);
    }
  };

  //get each IP details on click of ip link
  getIP_Details = (mfp_ip, connected, isBooked) => {
    localStorage.setItem("currentIP", mfp_ip);
    //localStorage.setItem("isBooked", isBooked);
    //this.props._ProductDetails_API(mfp_ip);
    //this.props.history.push("/MFP_Details", { mfp_ip: mfp_ip });
    connected === "yes"
      ? this.props.history.push("/MFP_Details")
      : Notify.error("Connection Failed");
  };

  constructor(props) {
    super(props);
    this.state = {
      _synced_MFP_details: this.props._getMFP_info_response,
      _synced_status: this.props._sync_database_response,
      _refreshedIP_Info: "",
      _refreshedIP_response: "",
    };
  }
  render() {
    //console.log(this.state._synced_MFP_details)
    return (
      <div>
        <Card Body className="tableView">
          <PageLoader loader={this.props._loading}>
            <Table striped bordered hover responsive>
              <thead>
                <tr>
                  {this.props._stringLiterals.DiagnosticTable.__DiagnosticTable_Columns.map(
                    (colNames) => (
                      <th>{colNames}</th>
                    )
                  )}
                </tr>
              </thead>

              <tbody>
                {this.state._synced_MFP_details['mfp_data']?.length ? this.state._synced_MFP_details['mfp_data']?.map((data, index) => {
                  return (
                    <tr key={index}>
                      <td>
                        <a
                          href="javascript:void(0)"
                          onClick={() =>
                            this.getIP_Details(
                              data.mfp_ip,
                              data.connected,
                              data.is_booked
                            )
                          }
                        >
                          {data.mfp_ip}
                        </a>
                      </td>
                      <td>{data.mfp_model}</td>
                      <td>{data.mfp_serial_number}</td>
                      <td>{data.build_number}</td>
                      <td>{data.mfp_type}</td>
                      <td style={{color:data.is_booked === "booked" ? 'red' : 'green'}}>{data.is_booked==='booked'?`Booked by: ${data.username}`:'Available'}</td>
                      <td>{data.mfp_location}</td>
                      <td>
                        <RefreshIcon
                          className="refresh-icon-spin"
                          onClick={() => this._RefreshIP_Details(data.mfp_ip)}
                        />
                      </td>
                    </tr>
                  );
                }) : null}
                {/* <tr>
                <td><a href='javascript:void(0)' onClick={() => this.getIP_Details("10.188.101.111",'yes',"booked")}>10.188.101.111</a></td>
                <td>Wiess3</td>
                <td>10000_XYZ</td>
                <td>B.V1.L6.5</td>
                <td>XYZ_SubProduct</td>
                <td>Booked</td>
                <td>XYZ_Model</td>
                <td><RefreshIcon className="refresh-icon-spin" onClick={() => this._RefreshIP_Details()} /></td>
              </tr> */}
              </tbody>
            </Table>
          </PageLoader>
        </Card>
      </div>
    );
  }
}
const mapStateToProps = (store) => {
  return {
    _stringLiterals: store.stringLiterals,
    _getMFP_info_response: store.apiCallReducer._getMFP_info_response,
    _sync_database_response: store.apiCallReducer._sync_database_response,
    _loading: store.apiCallReducer._loading,
    _refreshIP_response: store.apiCallReducer._refreshIP_response,
    _searchData_response: store.apiCallReducer._searchData_response,
    _productDetails_api_response:
      store.mfpDetailsReducer._productDetails_api_response,
  };
};

const mapDispatchToProps = (dispatch) => ({
  _GetMfpData_API: (payload) => dispatch(_GetMfpData_API(payload)),
  _RefreshIP_API: (payload) => dispatch(_RefreshIP_API(payload)),
  _ProductDetails_API: (payload) => dispatch(_ProductDetails_API(payload)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(DiagnosticTableComponent));
