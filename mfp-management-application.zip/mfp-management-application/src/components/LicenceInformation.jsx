import React from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { useState, useEffect } from "react";
import { Container, Card, Table, CardDeck } from "react-bootstrap";
import "../container/MFP_Details/MFP_Details.css";
import Button from '@material-ui/core/Button';

// All installed licence information in table
const LicenceInformation = (props) => {
  const [licenceInfo, setLicenceInfo] = useState([]);

  // useEffect(() => {
  //   setLicenceInfo([
  //     {
  //       id: 1,
  //       license_id: "-",
  //       mfp_ip: "10.188.104.249",
  //       license_name: "Printer",
  //       is_enabled: "ENABLE",
  //       license_serial_number: "-",
  //     },
  //     {
  //       id: 2,
  //       license_id: "-",
  //       mfp_ip: "10.188.104.249",
  //       license_name: "Scanner",
  //       is_enabled: "ENABLE",
  //       license_serial_number: "-",
  //     },
  //     {
  //       id: 5,
  //       license_id: "-",
  //       mfp_ip: "10.188.104.249",
  //       license_name: "External interface",
  //       is_enabled: "ENABLE",
  //       license_serial_number: "-",
  //     },
  //     {
  //       id: 6,
  //       license_id: "00000001394A",
  //       mfp_ip: "10.188.104.249",
  //       license_name: "Data overwrite",
  //       is_enabled: "ENABLE",
  //       license_serial_number: "3654810508032411",
  //     },
  //   ]);
  // }, []);

  useEffect(() =>{
    if(props.licenceInformation_api_response?.length){
      setLicenceInfo(props.licenceInformation_api_response)
    }
  },[props.licenceInformation_api_response]);


  return (
    <div>
      <Container className="mfpDetails-container">
        <h5>Licence Information</h5>
        <CardDeck>
        <Card>
          <Card.Header className="details-header">
            MFP Licence
          </Card.Header>
          <Table className="productData-Table tableHeader-color">
            <thead>
              <tr>
                {props.StringLiterals.LicenceInformation.__LicenceInfoTable_Columns.map(
                  (ColNames) => (
                    <th>{ColNames}</th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {licenceInfo.length
                ? licenceInfo.map((data, index) => {
                    return(
                      <tr key={index}>
                        <td>{index+1}</td>
                        <td>{data.license_name}</td>
                        <td>{data.is_enabled}</td>
                      </tr>
                    )
                  })
                : null}
            </tbody>
          </Table>
        </Card>
      </CardDeck>
      {/* <div><Button variant="contained" className="disabled-btn floatRight-btn" disabled>Install Licence</Button></div> */}
      
      </Container>
      
    </div>
  );
};

const mapStateToProps = (store) => {
  return {
    StringLiterals: store.stringLiterals,
    licenceInformation_api_response: store.mfpDetailsReducer._licenceInformation_Api_response,
  };
};

const mapDispatchToProps = (dispatch) => ({});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(LicenceInformation));
//export default LicenceInformation;
