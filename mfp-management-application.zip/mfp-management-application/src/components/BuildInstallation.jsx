import React from "react";
import {
  Card,
  InputGroup,
  FormControl,
  Container,
  Form,
} from "react-bootstrap";
import { useState, useEffect } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { _SoftwareUpgrade_API } from "../container/MFP_Details/MFP_Deatils_Actions";
import * as Notify from "../components/Notification";
import { ToastContainer, toast } from "react-toastify";
import "../container/MFP_Details/MFP_Details.css"
import PageLoader from "../components/Loader";
import Axios from "axios";
import Button from '@material-ui/core/Button';

// Build installation/software upgarde to install build
const BuildInstallation = (props) => {
  const [file, setfile] = useState('');
  const [postBody, setPostBody] = useState({});
  const [mfpIP, setMfpIp] = useState(localStorage.getItem("currentIP"));
  const [uploadStatus, setUploadStatus] = useState({});
  const[fileExtension, setFileExtension] = useState('');

// choose a file from desktop
  const getFile = (e) => {
    setfile(e.target.files[0]);
    let fname = e.target.files[0].name;
    setFileExtension(fname.slice((fname.lastIndexOf(".") - 1 >>> 0) + 2))
  };

  useEffect(() => {
    if (file && mfpIP) {
      setPostBody({
        ip: mfpIP,
        file: file,
      });
    }
  }, [file]);

  // upload the selected file
  const uploadFile = async () => {
    if (file !== '') {
      const data = new FormData() 
      data.append('file', file)
      let uploadResponse = await Axios.post(`http://10.188.101.118:50777/software_upgrade/${mfpIP}`,data,{maxContentLength: Infinity,
      maxBodyLength: Infinity})
      setUploadStatus(uploadResponse);
    } else {
      Notify.error("Please choose a file to upload !!!");
    }
  };

  return (
    <div>
      <Container className="mfpDetails-container">
        <h5>Build Installation</h5>
        <Card>
          <Card.Body>
            <InputGroup>
              <FormControl
                className='fileUploadInput'
                placeholder={
                  props.StringLiterals.BuildInstallation
                    .__BuildInstall_inputPlaceholder
                }
                aria-label="Choose File..."
                aria-describedby="basic-addon2"
                onChange={getFile}
                type="file"
                name = "file"
              />
              <InputGroup.Append className='uploadInputGroup'>
                <Button onClick={uploadFile} className="action-btn" variant="contained">
                <i className="fa fa-upload icon-padding icon-fontSize"></i> Install</Button>
              </InputGroup.Append>
            </InputGroup>
            {/* <PageLoader loader={props._loading}> */}
            {/* {Object.keys(uploadStatus)?.length ? uploadStatus.status === "success" ? <Card.Text className="statusSuccess-CardText"><i className="fa fa-spinner fa-pulse icon-padding"></i>Uploading...</Card.Text> : <Card.Text className="statusFailed-CardText"><i class="fa fa-exclamation-triangle icon-padding"></i>Failed to upload</Card.Text>:null} */}
            
            {/* </PageLoader> */}
          </Card.Body>
        </Card>
        {Object.keys(uploadStatus)?.length ? uploadStatus.data.status === "success" ? <Card className="statusCard-marginTop"><Card.Text className="statusSuccess-CardText"><i className="fa fa-spinner fa-pulse icon-padding"></i>Installing Build ...</Card.Text></Card> : <Card className="statusCard-marginTop"><Card.Text className="statusFailed-CardText"><i class="fa fa-exclamation-triangle icon-padding"></i>Failed to upload</Card.Text></Card>:null}
        <ToastContainer />
      </Container>
    </div>
  );
};

const mapStateToProps = (store) => {
  return {
    StringLiterals: store.stringLiterals,
    //_softwareUpgarde_api_response: store.mfpDetailsReducer._softwareUpgarde_api_response,
    _loading : store.mfpDetailsReducer._loading,
  };
};

const mapDispatchToProps = (dispatch) => ({
  _SoftwareUpgrade_API: (payload) => dispatch(_SoftwareUpgrade_API(payload)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(BuildInstallation));
// export default BuildInstallation;
