import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { Container, Row, Col, Card, CardDeck, Table } from "react-bootstrap";
import { _ProductDetails_API } from "../container/MFP_Details/MFP_Deatils_Actions";


// Detailed product info about each IP 
const ProductDetails = (props) => {
   const [productData, setProductData] = useState([]);
   const[username, setUsername] = useState('');
   const[isBooked, setIsBooked] = useState('');
   const[mfpIP, setMfpIP] = useState(localStorage.getItem('currentIP'))

  useEffect(() => {
    props._ProductDetails_API(mfpIP);
  },[])

 
//   useEffect(() => {
//     setProductData([
//       {
//         mfp_ip: "10.188.102.124",
//         mfp_manufacturer: "TOSHIBA",
//         mfp_model: "TOSHIBA e-STUDIO4618A",
//         mfp_name: "MFP12100001",
//         mfp_status: "Initializing",
//         stage2_port: "49629",
//         printer_color_type: "1",
//         mfp_drawers_installed: "0",
//         mfp_location: "",
//         mfp_firmware: "0",
//         system_software_id: "0",
//         mfp_serial_number: "CZ",
//         build_number: "V22.3.0.651.06",
//         product: "LOIRE",
//         sub_product: "EBN_SERIES_2",
//         sub_product_model: "",
//         mfp_type: "Reuss2",
//         faxline1_installed: "Installed",
//         faxline2_installed: "NotInstalled",
//         finisher_attached: "NotInstalled",
//         mfp_destination: "MJD",
//         connected: "yes",
//       },
//     ]);
//   },[]);

  useEffect(() => {
    if (props.productDetails_api_response?.length) {
    setProductData(props.productDetails_api_response);
    //console.log(props.productDetails_api_response);
    props.productDetails_api_response.forEach((data) =>{
      localStorage.setItem("isBooked", data.is_booked);
      localStorage.setItem("userName", data.username);
    })
    
    setUsername(localStorage.getItem('isBooked'));
    setIsBooked(localStorage.getItem('userName'));
    }
  }, [props.productDetails_api_response]);

  return (
    <div>
      {/* <h1>Product</h1> */}
      {productData.length
        ? productData.map((data, index) => {
            return (
              <Container className="mfpDetails-container">
                <h5>Product Details</h5>
                <Card>
                  <Card.Header as="h6" className="card-header-container">
                    <Row className="mfpdetails-header-row">
                      <Col
                        xs
                        md={2}
                        className="details-header mfpIP-panel-header"
                      >
                        MFP_IP:
                      </Col>
                      <Col xs md lg={7} className="mfpIP-panel-header">
                        {data.mfp_ip}
                      </Col>
                      <Col style={{ padding: "0px" }}>
                        <Table className="productData-Table ">
                          <tr>
                            <th>LOCATION</th>
                            <td>{data.mfp_location}</td>
                          </tr>
                          <tr>
                            <th>DESTINATION</th>
                            <td>{data.mfp_destination}</td>
                          </tr>
                        </Table>
                      </Col>
                    </Row>
                  </Card.Header>
                </Card>
                <CardDeck className="cardDeck-margin-top">
                  <Card>
                    <Card.Header className="details-header">
                      MFP SPECIFICATIONS
                    </Card.Header>
                    <Table className="productData-Table">
                      <tbody>
                        <tr>
                          <th>MFP MODEL</th>
                          <td>{data.mfp_model}</td>
                        </tr>
                        <tr>
                          <th>BUILD NUMBER</th>
                          <td>{data.build_number}</td>
                        </tr>
                        <tr>
                          <th>MFP TYPE</th>
                          <td>{data.mfp_type}</td>
                        </tr>
                        <tr>
                          <th>MFP NAME</th>
                          <td>{data.mfp_name}</td>
                        </tr>
                        <tr>
                          <th>SERIAL NUMBER</th>
                          <td>{data.mfp_serial_number}</td>
                        </tr>
                      </tbody>
                    </Table>
                  </Card>
                  <Card>
                    <Card.Header className="details-header">
                      PRODUCT SPECIFICATION
                    </Card.Header>
                    <Table className="productData-Table">
                      <tbody>
                        <tr>
                          <th>PRODUCT</th>
                          <td>{data.product}</td>
                        </tr>
                        <tr>
                          <th>SUB-PRODUCT</th>
                          <td>{data.sub_product}</td>
                        </tr>
                        <tr>
                          <th>SUB-PRODUCT MODEL</th>
                          <td>{data.sub_product_model}</td>
                        </tr>
                        <tr>
                          <th>SYSTEM SOFTWARE ID</th>
                          <td>{data.system_software_id}</td>
                        </tr>
                        <tr>
                          <th>FIRMWARE</th>
                          <td>{data.mfp_firmware}</td>
                        </tr>
                      </tbody>
                    </Table>
                  </Card>
                </CardDeck>
                <Card className="cardDeck-margin-top">
                  <Card.Header className="details-header">
                    MFP COMPONENTS
                  </Card.Header>
                  <Table className="productData-Table">
                    <tbody>
                      <tr>
                        <th>DRAWERS INSTALLED</th>
                        <td>{data.mfp_drawers_installed}</td>
                        <th>FAXLINE-1</th>
                        <td>{data.faxline1_installed}</td>
                      </tr>
                      <tr>
                        <th>FINISHER ATTACHED</th>
                        <td>{data.finisher_attached}</td>
                        <th>FAXLINE-2</th>
                        <td>{data.faxline2_installed}</td>
                      </tr>
                    </tbody>
                  </Table>
                </Card>
              </Container>
            );
          })
        : null}
    </div>
  );
};

const mapStateToProps = (store) => {
  return {
    StringLiterals: store.StringLiterals,
    productDetails_api_response:
      store.mfpDetailsReducer._productDetails_api_response,
  };
};

const mapDispatchToProps = (dispatch) => ({
  _ProductDetails_API: (payload) => dispatch(_ProductDetails_API(payload)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(ProductDetails));
//export default ProductDetails;
