import React, { Component }  from 'react';
import SideBarNav from './SideBar'
import "../container/MFP_Details/MFP_Details.css"
import ProductDetails from "./ProductDetails"
import LicenceInformation from "./LicenceInformation"
import HealthReport from './HealthReport';
import BuildInstallation from './BuildInstallation'
import BookMFP from './BookMFP'
import RunTestScripts from './RunTestScripts';

//component to show the details when user selects options on side nav bar
class SubComponent extends Component{
    constructor(props) {
        super(props)
        this.state = {
            content_type : "Product"
        }
    }

    getContent = (type) => {
        this.setState({content_type: type})
    }
    render(){
        return(
            <div className="row details-panel">
                <div className="col-md-3 col-lg-3">
                    <SideBarNav history={this.props.history} content ={this.getContent}/>
                </div>
                {/* <div className="col-md-9 col-lg-9">
                {this.state.content_type === 'Product' ? <ProductDetails/> : null
                }
                
                </div> */}
                
                <div className="col-md-9 col-lg-9">
                {this.state.content_type === 'Product' ? <ProductDetails/> : this.state.content_type === 'Licence' ? <LicenceInformation/>: this.state.content_type === 'Health' ?<HealthReport/>: this.state.content_type === 'BuildInstall' ?<BuildInstallation/> :this.state.content_type === 'BookMFP'? <BookMFP/>: this.state.content_type === 'TestScrips' ? <RunTestScripts /> : null
                }
                
                </div>
            </div>
            
        )
    }
}

export default SubComponent;