import React, { useState, useEffect } from 'react';
import {
    Card,
    InputGroup,
    FormControl,
    Container,
    Form,
  } from "react-bootstrap";
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import Button from '@material-ui/core/Button';
import Axios from "axios";
import * as Notify from "../components/Notification";
import { ToastContainer, toast } from "react-toastify";

const RunTestScripts = (props) => {
  const [script, setScript] = useState('');
  const [postBody, setPostBody] = useState({});
  const [mfpIP, setMfpIp] = useState(localStorage.getItem("currentIP"));
  const[scriptExecutionStatus, setScriptExecutionStatus] = useState('');
  const[fileExtension, setFileExtension] = useState('');
  
  useEffect(() => {
    if (script && mfpIP) {
      setPostBody({
        ip: mfpIP,
        script: script,
      });
    }
  }, [script]);

    // run the test scripts on click of Run scripts button
    const runScripts = async () => {
      if (script !== '') {

        if(fileExtension === 'py'){
          const data = new FormData() 
          data.append('file', script)
          let runScriptResponse = await Axios.post(`http://10.188.101.118:50777/run_test_script/${mfpIP}`,data)
          setScriptExecutionStatus(runScriptResponse);
         
        } else {
          Notify.error("Please choose python script to run...!!")
        }
        
      } else {
        
        Notify.error("Please choose a script to run !!!");
      }
    };

    // choose file and get the file
    const getScripts = (e) => {
      setScript(e.target.files[0]);
      let fname = e.target.files[0].name;
      setFileExtension(fname.slice((fname.lastIndexOf(".") - 1 >>> 0) + 2))
    }

    return( <Container className="mfpDetails-container">
    <h5>Run Test Scripts</h5>
    <Card>
          <Card.Body>
            <InputGroup>
              <FormControl
                className='fileUploadInput'
                placeholder={
                  props.StringLiterals.BuildInstallation
                    .__BuildInstall_inputPlaceholder
                }
                aria-label="Choose File..."
                aria-describedby="basic-addon2"
                onChange={getScripts}
                type="file"
                name = "file"
              />
              <InputGroup.Append className='uploadInputGroup'>
                <Button onClick={runScripts} className="action-btn" variant="contained">Run Script
                <i className="fa fa-paper-plane icon-padding"></i></Button>
              </InputGroup.Append>
            </InputGroup>
            
          </Card.Body>
        </Card>
        {Object.keys(scriptExecutionStatus)?.length ? scriptExecutionStatus.data.status === "success" ? <Card className="statusCard-marginTop"><Card.Text className="statusSuccess-CardText"><i className="fa fa-check-circle icon-padding"></i>Execution Success !!<br/> Results: <a href={scriptExecutionStatus.data.path} download>Download</a></Card.Text></Card> : <Card className="statusCard-marginTop"><Card.Text className="statusFailed-CardText"><i class="fa fa-exclamation-triangle icon-padding"></i>Execution Failed</Card.Text></Card>:null}
       
        <ToastContainer />
    </Container>)
};

const mapStateToProps = (store) => {
    return {
        StringLiterals: store.stringLiterals
    }
}

const mapDispatchToProps = (dispatch) => ({

});

export default connect(mapStateToProps,mapDispatchToProps)(withRouter(RunTestScripts))
