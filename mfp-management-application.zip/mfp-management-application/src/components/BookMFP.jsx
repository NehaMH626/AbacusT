import React from "react";
import {
  Card,
  InputGroup,
  FormControl,
  Container,
  Form,
  Row,
  Col,
} from "react-bootstrap";
import Button from "@material-ui/core/Button";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useState, useEffect } from "react";
import TimeRangePicker from "@wojtekmaj/react-timerange-picker";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { _BookMFP_API } from "../container/MFP_Details/MFP_Deatils_Actions";
import * as Notify from "../components/Notification";
import { ToastContainer, toast } from "react-toastify";

// Component to book and unbook MFP
const BookMFP = (props) => {
  const [startDate, setStartDate] = useState(new Date());
  let today = new Date();
  var time = today.getHours() + ":" + today.getMinutes();
  const [value, onChange] = useState([time, time]);
  const [bookingMFP, setbookingMFP] = useState(
    localStorage.getItem("isBooked")
  );
  const [postBody, setPostBody] = useState({});
  const [mfpIP, setMfpIp] = useState(localStorage.getItem("currentIP"));
  const [bookedStatus, setBookedStatus] = useState({});
  const [userName, setUserName] = useState("");
  const [bookedUserName, setBookedUserName] = useState(localStorage.getItem('userName'))

  var payload = { ip: mfpIP, command: bookingMFP, username: userName };
  useEffect(() => {
    payload = { ip: mfpIP, command: bookingMFP, username: userName };
  }, [bookingMFP, userName]);

  const handlebookingMFP = async () => {
    //console.log(userName);
    
    if (payload.username === "" && bookingMFP === 'available') {
      Notify.error("Enter username !!");
    } else {
      bookingMFP === "available"
      ? (payload.command = "booked")
      : (payload.command = "available");
      // console.log(payload);
      let bookingResponse = await props._BookMFP_API(payload);
      if(payload.command === 'available'){
        localStorage.setItem('userName', '')
      }
      setBookedUserName(localStorage.getItem('userName'))
      setBookedStatus(bookingResponse);
      bookingResponse.is_booked === "booked"
        ? setbookingMFP("booked")
        : setbookingMFP("available");
      bookingResponse.status === "success"
        ? bookingResponse.is_booked === "booked"
          ? Notify.success("Booked !!!")
          : Notify.success("Unbooked !!")
        : Notify.error("Failed");

      //console.log("response: ", bookedStatus);
      
    }
  };

  return (
    <div>
      <Container className="mfpDetails-container">
        <h5>Book MFP</h5>
        <Card>
          <Card.Body>
            <Row>
              <Col xs md={12}>
                <Card.Text className="cardText-fontSize">Enter Username</Card.Text>
                <InputGroup className="mb-3">
                  <InputGroup.Prepend>
                    <InputGroup.Text id="basic-addon1">@</InputGroup.Text>
                  </InputGroup.Prepend>
                  <FormControl
                    placeholder="Username"
                    aria-label="Username"
                    aria-describedby="basic-addon1"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    required
                  />
                </InputGroup>
              </Col>
              {/* <Col xs md={6}> */}
                {/* <Card.Text className="cardText-fontSize">Select Date to book MFP:</Card.Text>
                <DatePicker
                  selected={startDate}
                  onChange={(date) => setStartDate(date)}
                  className="datepicker-input"
                /> */}
                {/* <Card.Text>Select Time Slot to book MFP:</Card.Text>
                <TimeRangePicker onChange={onChange} value={value} /> */}
              {/* </Col> */}
            </Row>
            <InputGroup>
              <InputGroup.Append className="uploadInputGroup">
                <Button
                  onClick={handlebookingMFP}
                  className="action-btn"
                  variant="contained"
                >
                  <i className="fa fa-calendar icon-padding"></i>{" "}
                  {bookingMFP === "booked" ? "Unbook" : "Book"}
                </Button>
              </InputGroup.Append>
            </InputGroup>
            <ToastContainer />
          </Card.Body>
        </Card>
        {bookedStatus?.status === "success"
        ? bookedStatus?.is_booked === "booked"
              ? <Card className="statusCard-marginTop"><Card.Text className="statusSuccess-CardText">Booked by : {userName}</Card.Text></Card>
          : <Card className="statusCard-marginTop"><Card.Text className="statusSuccess-CardText">Unbooked !!!</Card.Text></Card>
        : null}
        {bookedUserName !== '' ? <Card className="statusCard-marginTop"><Card.Text className="statusSuccess-CardText">Booked by : {localStorage.getItem('userName')}</Card.Text></Card> : null}
      </Container>
    </div>
  );
};

const mapStateToProps = (store) => {
  return {
    StringLiterals: store.stringLiterals,
    _bookMFP_api_response: store.mfpDetailsReducer._bookMFP_api_response,
  };
};

const mapDispatchToProps = (dispatch) => ({
  _BookMFP_API: (payload) => dispatch(_BookMFP_API(payload)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(BookMFP));
//export default BookMFP;
