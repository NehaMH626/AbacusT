self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "97a59c8de6452e36f0f918efac16a097",
    "url": "/client/index.html"
  },
  {
    "revision": "75f3515a3de5344904d7",
    "url": "/client/static/css/main.1a332795.chunk.css"
  },
  {
    "revision": "b6f84094e5fcaa3454d5",
    "url": "/client/static/js/2.c9c59eec.chunk.js"
  },
  {
    "revision": "7f375ebad84935b1e3a17278a1feb582",
    "url": "/client/static/js/2.c9c59eec.chunk.js.LICENSE.txt"
  },
  {
    "revision": "75f3515a3de5344904d7",
    "url": "/client/static/js/main.bd990a46.chunk.js"
  },
  {
    "revision": "6cd281672190d5fd254c",
    "url": "/client/static/js/runtime-main.33e3a412.js"
  },
  {
    "revision": "273becb3ff24f9eb01f782d1b78bf4ab",
    "url": "/client/static/media/bg6.273becb3.jpg"
  },
  {
    "revision": "d0aca2a5a912b100b5d803f1dcb18642",
    "url": "/client/static/media/icon.d0aca2a5.png"
  }
]);