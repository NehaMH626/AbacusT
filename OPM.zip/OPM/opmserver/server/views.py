import logging
import paramiko
import time
import sys
import json

from cornice.resource import resource, view
from .db_connect import DbOperator
import subprocess
from pyramid.view import view_config
from pyramid.httpexceptions import HTTPFound
from cornice import Service
from pyramid.httpexceptions import exception_response
from pyramid.response import Response

logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s Pid= %(process)d Tid= %(thread)d %(filename)s  %(lineno)d %(module)s %(levelname)s %(message)s",
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='/work/log/al/OPM/db_log.0.log',
                    filemode='a')
LOG = logging.getLogger("LOG_NAME")
clientMFP = None
searchDB_Count = None
searchDB_data = None

""" Get list of all 08 codes"""
@resource(path="/opm_app/08_code/list", accept=("application/json"))
class OpmApp_Config_View():
    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        request = self.request
        # url_params_key = request.params.keys()
        url_params = request.params["code"]

        query = ''
        result = {}
        response = []
        global searchDB_Count
        global searchDB_data
        if url_params.isdigit():
            query = "select * from Sample_08_Code where Code LIKE '%{}%'".format(url_params)
            LOG.warning("ITS INT")
        else:
            query = "select * from Sample_08_Code where Description LIKE '%{}%'".format(url_params)
            LOG.warning("ITS STR")
        with DbOperator() as cursor:
            cursor.execute(query)
            result = cursor.fetchall()  # create
        for res in result:
            response.append(dict(res))

        """ Get function call
        retrieves query string sdata
        """
        searchDB_Count = len(response)
        searchDB_data = response
        LOG.warning("get: search Count and search data " + str(searchDB_Count) + " " + str(searchDB_data))

        return response


def handle_error_cases(exc, msg):
    response = exception_response(400)
    response.text = json.dumps(msg)
    response.content_type = 'application/json'
    LOG.warning("webapi_bad_request: " + str(response.text))
    return response

""" Pagination in case of large data """
@resource(path="/opm_app/pagination/list", accept=("application/json"))
class OpmApp_Pagination_View():
    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        request = self.request
        LOG.warning("pagination")
        global searchDB_data
        global searchDB_Count
        perPage = request.params.get("perPage")
        LOG.warning("perPage : " + str(perPage))
        LOG.warning("searchDB_Count : " + str(searchDB_Count))
        LOG.warning("type of : " + str(type(searchDB_Count)) + str(type(perPage)))
        pageCount = int(searchDB_Count) / int(perPage)
        LOG.warning( "pageCount : " + str(pageCount))

        if pageCount > int(pageCount):
            pageCount = int(pageCount) + 1
            LOG.warning(str(pageCount))
        else:
            pageCount = int(pageCount)
            LOG.warning(str(pageCount))
        page = request.params.get("page")
        startIndex = (int(perPage) * (int(page) - 1))
        LOG.warning("StartIndex = " + str(startIndex))
        if (searchDB_Count > ((startIndex + int(perPage)) - 1)):
            lastIndex = (startIndex + int(perPage)) - 1
            LOG.warning("lastIndex = " + str(lastIndex))
        else:
            lastIndex = searchDB_Count - 1
            LOG.warning("lastIndex = " + str(lastIndex))
        LOG.warning("page = "+  str(page) + "index =" + str(startIndex) + "-" + str(lastIndex))
        response = searchDB_data[startIndex : lastIndex+1]

        return response





""" Connect to MFP IP"""
@resource(path="/opm_app/connect/mfp", accept=("application/json"))
class OpmApp_ConnectToMFp():
    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        try:
            global clientMFP
            request = self.request
            LOG.warning("Enter Connect MFP")
            url_params = request.params.get("ip")

            ip_address = url_params
            user = 'root'
            password = 'toshibatec1048'
            LOG.warning("Connecting to: " + ip_address)

            self.ssh = paramiko.SSHClient()
            self.ssh.load_system_host_keys()
            self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh.connect(hostname=ip_address, username=user, password=password, compress=True, look_for_keys=False,
                             allow_agent=False, timeout=5)
            clientMFP = self.ssh
            return {"status": "OK", "message": "Connected Successfully to MFP: " + ip_address}
        except Exception as exc:
            LOG.exception(str(exc))
            return handle_error_cases(exc, {"error": str(exc), "message": "could not connect to MFP"})


 
 
""" Get default 08 code values """
@resource(path="/opm_apps/get_code/default", accept=("application/json"))
class OpmApp_MFP_GetDefaultCode():
    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        try:
            request = self.request
            LOG.warning("Enter OpmApp_MFP_GetDefaultCode")
            para = request.params
            LOG.warning(str(para))
            request_code = request.params.get("code")
            LOG.warning(str(request_code))
            request_mode = request.params.get("mode")
            LOG.warning(str(request_code))
            LOG.warning(str(request_mode))
            response = {}
            global clientMFP

            command_1 = "cd /home/SYSROM_SRC; source setenv > /dev/null;"
            command_1 += "albotest SETTOKEN;"
            command_1 += "albotest SET DiagnosticMode/Category/Mode {}".format(request_mode) + ";"
            command_1 += "albotest SET DiagnosticMode/Category/MainCode/Code {}".format(request_code) + ";"
            command_1 += "albotest SENDCOMMAND GetDiagnosticMode DiagnosticMode"

            stdin, stdout, stderr = clientMFP.exec_command(command_1)
            err_1 = stderr.read().decode("utf-8")

            if not err_1:
                command_2 = "cd /home/SYSROM_SRC; source setenv > /dev/null;"
                command_2 += "albotest GET DiagnosticMode/Category/MainCode/ValueList/Value[@index=1]/Value"
                stdin, stdout, stderr = clientMFP.exec_command(command_2)
                err_2 = stderr.read().decode("utf-8")
                if not err_2:
                    value = stdout.read().decode("utf-8").split("\n")[0]
                    LOG.warning("code value = %s", value)
                    response = {"value": value}
                else:
                    LOG.warning("command_2: stdout: %s, stderr: %s", stdout.read(), err_2)
                    raise Exception("failed to fetch GET-diagnositc value")
            else:
                LOG.warning("command_1: stdout: %s, stderr: %s", stdout.read(), err_1)
                raise Exception("problem occured while querying GET_DefaultCode in the MFP")

            return response
        except Exception as exc:
            LOG.exception(str(exc))
            return handle_error_cases(exc, {"error": str(exc), "message": "Failed to get code"})

""" Set specified 08 code value """
@resource(path="/opm_app/setCode", accept=("application/json"))
class OpmApp_MFP_SetCode():
    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        try:
            request = self.request
            LOG.warning("Enter OpmApp_setCode")
            request_code = request.params.get("code")
            request_mode = request.params.get("mode")
            request_usercode = request.params.get("setvalue")
            para = request.params
            LOG.warning(str(para))
            response = {}
            global clientMFP

            command_1 = "cd /home/SYSROM_SRC; source setenv > /dev/null;"
            LOG.warning('1')
            command_1 += "albotest SETTOKEN;"
            LOG.warning('2')
            command_1 += "albotest SET DiagnosticMode/Category/Mode {}".format(request_mode) + ";"
            LOG.warning('3')
            command_1 += "albotest SET DiagnosticMode/Category/MainCode/Code {}".format(request_code) + ";"
            LOG.warning('4')
            command_1 += "albotest SENDCOMMAND GetDiagnosticMode DiagnosticMode" + ";"
            LOG.warning('5')
            command_1 += "albotest SET DiagnosticMode/Category/MainCode/Operation Read_Write" + ";"
            LOG.warning('6')
            command_1 += "albotest SET DiagnosticMode/Category/MainCode/ValueList/Value[@index=1]/Value {}".format(request_usercode) + ";"
            LOG.warning('7')
            command_1 += "albotest SENDCOMMAND SetDiagnosticMode DiagnosticMode"
            LOG.warning('8')
            LOG.warning('Done setCode')
            LOG.warning("command_1: %s", command_1)
            stdin, stdout, stderr = clientMFP.exec_command(command_1)
            err_1 = stderr.read().decode("utf-8")

            if not err_1:
                command_2 = "cd /home/SYSROM_SRC; source setenv > /dev/null;"
                LOG.warning('9')
                command_2 += "albotest GET DiagnosticMode/Category/MainCode/ValueList/Value[@index=1]/Value"
                LOG.warning('10')
                LOG.warning("command_2: %s", command_2)
                stdin, stdout, stderr = clientMFP.exec_command(command_2)
                err_2 = stderr.read().decode("utf-8")
                LOG.warning('Done setCode GET')
                if not err_2:
                    value = stdout.read().decode("utf-8").split("\n")[0]
                    LOG.warning("code value = %s", value)
                    response = {"value": value}
                else:
                    LOG.warning("command_2: stdout: %s, stderr: %s", stdout.read(), err_2)
                    raise Exception("failed to fetch SET-diagnositc value")
            else:
                LOG.warning("command_1: stdout: %s, stderr: %s", stdout.read(), err_1)
                raise Exception("problem occured while querying SET_CODE in the MFP")

            return response
        except Exception as exc:
            LOG.exception(str(exc))
            return handle_error_cases(exc, {"error": str(exc), "message": "Failed to get code"})




@resource(path="/", accept=("application/json"))
class start_app():
    def __init__(self, request, context=None):
        self.request = request

    @view(renderer='json')
    def get(self):
        LOG.warning("start_app:enter")
        return HTTPFound(location="/client/index.html")