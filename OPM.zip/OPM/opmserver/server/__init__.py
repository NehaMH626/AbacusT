from pyramid.config import Configurator

def includeme(config):
    #config.add_route('start_app', 'start_app', xhr=True)
    pass

