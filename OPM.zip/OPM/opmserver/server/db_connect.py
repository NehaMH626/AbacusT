
import logging
import sqlite3
import os
logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s Pid= %(process)d Tid= %(thread)d %(filename)s  %(lineno)d %(module)s %(levelname)s %(message)s",
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='/work/log/al/OPM/db_log.0.log',
                    filemode='a')

LOG = logging.getLogger("LOG_NAME")


class DbOperator():
    """ create a db connection to the SQLite db
        specified by database
    :param database: database file"""

    def __init__(self):

        self.db_path = '/home/SYSROM_SRC/OPM/opm.db'
        self.conn = None
        self.curr = None

    def __enter__(self):
        try:
            LOG.warning("Enter:DbOperator.__enter__")
            LOG.warning("db path:{}".format(self.db_path))
            self.conn = sqlite3.connect(self.db_path)  # , isolation_level='DEFERRED')
            self.conn.row_factory = sqlite3.Row
            self.conn.set_trace_callback(LOG.warning)  # log the executed query
            self.curr = self.conn.cursor()

            self.curr.execute("PRAGMA foreign_keys = ON")
            LOG.warning("returning cursor obj")
            return self.curr
        except Exception as exc:
            raise exc

    def __exit__(self, type, value, traceback):

        if traceback is None:
            # No exception, so commit
            if self.conn:
                LOG.warning("Exit:DbOperator:commiting changes")
                self.conn.commit()
                self.conn.close()
        else:
            # Exception occurred, so rollback.
            if self.conn:
                LOG.warning("Exit:DbOperator:Exception occurred, so rollback")
                self.conn.rollback()
                self.conn.close()
        LOG.warning("Exit:DbOperator.__exit__")


# class DbCreator():
#     def __init__(self, db_name, storagetype="clonable"):
#         try:
#             #self.storagetype = storagetype
#             self.db_name = db_name
#             self.__isExistDB(self.db_name)
#
#         except Exception as exc:
#             raise exc
#
#     def __isExistDB(self, db_name):
#         '''
#             check the existence of the db file.
#             if the db does not exist, create the new db and tables.
#             @ param
#                 db_path: dbname from app root path.
#
#             @ return
#                 None
#         '''
#
#         try:
#             LOG.warning("Enter: __isExistDB")
#             # check the db exist or not
#             storage_path = ''
#             db_path = storage_path + "/" + db_name
#             LOG.warning("db path:{}".format(db_path))
#             if os.path.isfile(db_path):
#                 LOG.warning("db file already exists")
#             else:
#                 self.__createNewDB(storage_path)
#                 LOG.warning("create new db and tables")
#                 LOG.warning("Exit: __isExistDB")
#         except Exception as exc:
#             raise exc
#
#     def __createNewDB(self, storage_path):
#
#         try:
#             LOG.warning("Enter: __createNewDB")
#             schema_file_path = storage_path + '/db_schema/attendance_schemafile'
#             with DbOperator(self.db_name) as cursor:
#                 with open(schema_file_path) as fp:
#                     cursor.executescript(fp.read())  # create tables from schemafile
#         except Exception as exc:
#             raise exc
#             LOG.warning("Exit: __createNewDB")

