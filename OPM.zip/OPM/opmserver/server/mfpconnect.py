import paramiko
import time
import sys

""" Establish connection with MFP"""
def mfpconnect(self):
    ip_address = '10.188.101.237'
    user = 'root'
    password = 'toshibatec1048'
    LOG.warning("Connecting to: " + ip_address)

    self.ssh = paramiko.SSHClient()
    self.ssh.load_system_host_keys()
    self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    self.ssh.connect(hostname=ip_address, username=user, password=password, compress=True, look_for_keys=False, allow_agent=False, timeout=5)
    LOG.warning("##########################  CONNECTED TO: " + ip_address + "  ##########################")