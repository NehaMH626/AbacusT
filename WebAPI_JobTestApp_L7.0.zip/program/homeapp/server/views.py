#!/usr/bin/env python
#-*- coding: utf-8 -*-

import json
import requests
import os
import re
from hmserver.apps.common.logger import logger_obj
from pyramid.view import view_config
from pyramid.response import Response




