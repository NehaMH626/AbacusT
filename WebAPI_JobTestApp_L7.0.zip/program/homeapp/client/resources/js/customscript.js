function openNav() {
    document.getElementById("myNav").style.display = "block";
}

function closeNav() {
    $('#accordion').empty();
    $('#divOutPanel').empty();
    $('#collapse_accordionDefault > .panel-body > .row').empty();
    document.getElementById("myNav").style.display = "none";

    App.Scan.DefaultParams = [];
    App.Scan.keyValMapObj = {};
    App.Scan.postObjUI = {};
    App.Scan.postObjParent = {};
    App.Scan.updatedpostObjUI = {};
    $("#WebAPI_main_screen").addClass('show-main-screen');
}

function hideHomeScreen() {
    if ($("#WebAPI_main_screen").hasClass('show-main-screen')) {
        $("#WebAPI_main_screen").removeClass('show-main-screen');
        $("#WebAPI_main_screen").addClass('hide-main-screen');
    } else {
        $("#WebAPI_main_screen").addClass('hide-main-screen');
    }
}
/*$('#accordian').collapse("hide");
$('#accordionDefault').collapse("hide");*/

$(document).on('show', '.accordion', function (e) {
    //$('.accordion-heading i').toggleClass(' ');
    $(e.target).prev('.accordion-heading').addClass('accordion-opened');
});

$(document).on('hide', '.accordion', function (e) {
    $(this).find('.accordion-heading').not($(e.target)).removeClass('accordion-opened');
    //$('.accordion-heading i').toggleClass('fa-chevron-right fa-chevron-down');
});

function loadCheckboxSelected(key, parent) {

    var chk_options = [];

    $('.dropdown-menu a').on('click', function (event) {

        var $target = $(event.currentTarget),
            val = $target.attr('data-value'),
            $inp = $target.find('input'),
            idx;

        if ((idx = chk_options.indexOf(val)) > -1) {
            chk_options.splice(idx, 1);
            setTimeout(function () {
                $inp.prop('checked', false)
            }, 0);
        } else {
            chk_options.push(val);
            setTimeout(function () {
                $inp.prop('checked', true)
            }, 0);
        }

        $(event.target).blur();

        console.log(chk_options);
        $("#length_of_arr").text("Length of array : " + chk_options.length);
        $('#' + parent + key).attr('data-selected', JSON.stringify(chk_options));
        return false;
    });
}


/* adding  textbox dynamically*/
function addTextBoxArray(parentElement, key) {
    var counter = 1;

    $("#addButton_" + parentElement + "_" + key + "").click(function () {

        if (counter > 10) {
            alert("Only 10 textboxes allow");
            return false;
        }

        var newTextBoxDiv = $(document.createElement('div'))
            .attr("id", "TextBoxDiv_" + parentElement + "_" + key + "" + counter);

        newTextBoxDiv.after().html('<label>' + key + counter + ' : </label>' +
            '<input type="text" name="textbox' + counter +
            '" id="textbox_' + parentElement + '_' + key + counter + '" value="" >');

        newTextBoxDiv.appendTo("#TextBoxesGroup_" + parentElement + "_" + key + "");


        counter++;
    });

    $("#removeButton_" + parentElement + "_" + key + "").click(function () {
        if (counter == 1) {
            alert("No more textbox to remove");
            return false;
        }

        counter--;

        $("#TextBoxDiv_" + parentElement + "_" + key + "" + counter).remove();

    });

    $("#getButtonValue_" + parentElement + "_" + key + "").click(function () {

        var msg = '';

        for (i = 1; i < counter; i++) {
            msg += "\n " + key + " #" + i + " : " + $('#textbox_' + parentElement + '_' + key + i).val();
            var ele = $('#textbox_' + parentElement + '_' + key + i).val();

        }
        console.log(JSON.stringify(arr));
        alert(msg);
    });


}

/* --------- adding form dynamically ------------ */

function addFormArray(parentElement, key) {
    var counter = 1;
    console.log("ENTERING HERE");
    $(".addButton_" + key + "").click(function () {

        $('#collapse_' + key + ' > .panel-body > #' + key + 1).clone().attr('id', key + ++counter).appendTo('#collapse_' + key + ' > .panel-body');
        $('#collapse_' + key + '> .panel-body').toggleClass('addingCss');

        counter++;
    });

    $(".removeButton_" + key + "").click(function () {
        if (counter == 1) {
            alert("No more textbox to remove");
            return false;
        }

        $('#collapse_' + key + ' > .panel-body > #' + key + counter).remove();
        counter--;

    });

    $(".getButtonValue_" + key + "").click(function () {

        var msg = '';

        for (i = 1; i < counter; i++) {
            msg += "\n " + key + " #" + i + " : " + $('#textbox_' + parentElement + '_' + key + i).val();
            var ele = $('#textbox_' + parentElement + '_' + key + i).val();

        }
        console.log(JSON.stringify(arr));
        alert(msg);
    });


}


///* -------- add form dynamically on button click ----------- */
//function addFormArrayOnClick(parentElement, key) {
//    var counter = 1;
//    console.log("ENTERING HERE @addFormArrayOnClick");
//    $(".addButton_" + key + "").click(function () {
//
//        if ($('#collapse_' + key + ' > .panel-body > #' + key + 1).length) // use this if you are using id to check
//        {
//            // it exists
//            $('#collapse_' + key + ' > .panel-body > #' + key + 1).clone().attr('id', key + ++counter).appendTo('#collapse_' + key + ' > .panel-body');
//            counter++;
//        } else {
//            
//            $('#collapse_' + parentElement + "-" + key + ' > .panel-body > .row').attr('id', key + 1);
//            $('#collapse_' + key + ' > .panel-body > .row').css({
//                "border-style": "ridge",
//                "margin-top": "5px"
//            });
//            App.Scan.render(properties[key].items.properties, key);
//
//        }
//
//    });
//
//    $(".removeButton_" + key + "").click(function () {
//        if (counter == 1) {
//            alert("No more textbox to remove");
//            return false;
//        }
//
//        $('#collapse_' + key + ' > .panel-body > #' + key + counter).remove();
//        counter--;
//
//    });
//
//    $(".getButtonValue_" + key + "").click(function () {
//
//        var msg = '';
//
//        for (i = 1; i < counter; i++) {
//            msg += "\n " + key + " #" + i + " : " + $('#textbox_' + parentElement + '_' + key + i).val();
//            var ele = $('#textbox_' + parentElement + '_' + key + i).val();
//
//        }
//        console.log(JSON.stringify(arr));
//        alert(msg);
//    });
//
//
//}
