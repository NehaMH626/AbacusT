/* Copyright(c) 2015-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
App.Scan = (function (global, $, undefined) {
        var DefaultParams = [];
        var keyValMapObj = {};
        var getDefaultParams;
        var postObjUI = {};
        var postObjParent = {};
        var updatedpostObjUI = {};


        var show = function () {

            $("#scanToApp-btn").on("click", function () {
                hideHomeScreen();
                $("#btn-start").html("<button type='button' class='btn btn-success btn-small start-btn' id='start-btn-scanToApp'>Start Job >></button>");
                $("#get-storage-fileList").remove();
                $("#get-appConv-fileList").remove();

                var scanBody = App.paths["/jobs/scan/scan_to_app"].post.parameters[0].schema.allOf[1].properties;
                var scanRequiredBody = App.paths["/jobs/scan/scan_to_app"].post.parameters[0].schema.allOf[0].properties;
                console.log(JSON.stringify(scanRequiredBody));
                console.log(JSON.stringify(scanBody));
                App.Util.serverRequest(App.URL.scanToAppURL, 'GET', false, function (response, error) {
                    if (response) {
                        console.log("GET_Success:" + JSON.stringify(response));
                        traverse_it(response);
                        getDefaultParams = App.Scan.DefaultParams.push(App.Scan.keyValMapObj);
                        console.log('getDefaultValues Keyvaluemap obj is' + JSON.stringify(App.Scan.DefaultParams));

                    } else {
                        console.log("@scan_to_app" + error.xhr.status + error.xhr.responseText);
                    }
                });

                console.log("value in obj is" + App.Scan.DefaultParams[0].auto_event);


                _parseSwaggerRequiredParam(scanRequiredBody, App.Scan.DefaultParams);
                _parseSwagger(scanBody, App.Scan.DefaultParams);

                _parseSwaggerRequiredParamPostBody(scanRequiredBody);
                _parseSwaggerPostBody(scanBody);

                _comparePostObj(App.Scan.postObjUI, App.Scan.postObjParent);
                console.log("getting post body data " + JSON.stringify(App.Scan.postObjUI));
                console.log("parent obj is " + JSON.stringify(App.Scan.postObjParent));
                console.log("@@@@@@@@@@@@@Updated parent obj is " + JSON.stringify(App.Scan.updatedpostObjUI));

            });
        };

        // get first set of objects on UI
        function _parseSwagger(swaggerJson) {


            for (var key in swaggerJson) {

                //console.log("KEY_TYPE " + swaggerJson[key].type);
                var swagKeyType = swaggerJson[key].type;

                if (swagKeyType === 'object') {
                    $('#accordion').append('<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse_' + key + '" class="accordion-toggle collapsed">' + key + '</a></h4></div><div id="collapse_' + key + '" class="panel-collapse collapse"><div class="panel-body ' + key + '"><div class="row"></div></div></div></div>');
                    var properties = swaggerJson[key].properties;
                    render(properties, key);
                } else if (swagKeyType === 'array') {
                    //console.log("Array of obj");
                    $('#accordion').append('<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse_' + key + '" class="accordion-toggle collapsed">' + key + '</a></h4></div><div id="collapse_' + key + '" class="panel-collapse collapse"><div class="panel-body ' + key + '"><div class="row"></div></div></div></div>');
                    var properties = swaggerJson[key].items.properties;
                    render(properties, key);

                    $('#collapse_' + key + '> .panel-body').toggleClass('addingCsss');

                    $('#collapse_' + key + '> .panel-body').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div arrBtn"><input type="button" value="Add Item" class="addButton_' + key + '"><input type="button" value="Remove Item" class="removeButton_' + key + '"></div>');

                    $('#collapse_' + key + ' > .panel-body > .row').attr('id', key + 1);
                    $('#collapse_' + key + ' > .panel-body > .row').css({
                        "border-style": "ridge",
                        "margin-top": "5px"
                    });


                    //$('#collapse_' + key + ' > .panel-body').addClass("scrollable");
                    addFormArray("accordion", key);



                } else if (swagKeyType === 'string' || 'integer') {
                    //render(properties, key);
                    parentElement = "";

                    if (swaggerJson[key].hasOwnProperty('enum')) {
                        $('#accordion').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><label for="' + parentElement + key + '">' + key + '</label><select class="form-control" name="select_ele" id="' + parentElement + key + '" data-type="' + swagKeyType + '"></select></div>');
                        for (enumKey in swaggerJson[key].enum) {
                            $('#' + parentElement + key).append('<option value="' + swaggerJson[key].enum[enumKey] + '" >' + swaggerJson[key].enum[enumKey] + '</option>');
                            App.Scan.postObjUI[parentElement] = key;

                            $.each(App.Scan.DefaultParams[0], function (keyDefaultParams, valDefaultParams) {

                                if (keyDefaultParams == key) {
                                    $('#' + parentElement + key).val(valDefaultParams);
                                }

                            });
                        }
                    } else {
                        $('#divOutPanel').removeClass("hide");
                        $('#divOutPanel').append('<label for="' + parentElement + key + '">' + key + '</label><input type="text" class="form-control" id="' + parentElement + key + '" data-type="' + swagKeyType + '">');


                        $.each(App.Scan.DefaultParams[0], function (keyDefaultParams, valDefaultParams) {

                            if (keyDefaultParams == key) {
                                $('#' + parentElement + key).val(valDefaultParams);
                            }

                        });
                    }
                }
            }
        }

        function _parseSwaggerRequiredParam(swaggerJsonRequiredParam) {
            render(swaggerJsonRequiredParam, "accordionDefault");

        }

        // get obj within obj on UI
        function render(properties, parentElement) {

            console.log("PROP === " + JSON.stringify(properties));
            for (var key in properties) {
                var keyType = properties[key].type;
                //console.log("key " + key + "keyType = " + keyType);
                if (keyType === 'object' || typeof (keyType) === 'undefined') {
                    if (properties[key].hasOwnProperty('properties')) {
                        $('#collapse_' + parentElement + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a data-toggle="collapse" data-parent="collapse_' + key + '" href="#collapse_' + key + '" class="accordion-toggle collapsed">' + key + '</a></h4></div><div id="collapse_' + key + '" class="panel-collapse collapse"><div class="panel-body"><div class="row"></div></div></div</div>');
                        render(properties[key].properties, key);
                    }
                } else if (keyType === 'array') {
                    if (properties[key].hasOwnProperty('items')) {
                        if ((properties[key].items).hasOwnProperty('enum')) {

                            var length_of_arr = properties[key].items.enum.length;
                            $('#collapse_' + parentElement + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><label for="' + parentElement + key + '">' + key + '</label></div><div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 left-div"><div class="button-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"><span id="' + parentElement + key + '" data-selected=""></span>&nbsp;&nbsp;<span class="caret"></span></button><ul class="dropdown-menu scrollable-menu" id="ul-' + parentElement + key + '"></ul></div></div><div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 left-div"><label for="len_' + parentElement + key + '" id="length_of_arr"></label></div></div>');
                            for (enumKey in properties[key].items.enum) {
                                $('#ul-' + parentElement + key).append('<li><a href="#" class="small" data-value="' + properties[key].items.enum[enumKey] + '" tabIndex="-1"><input type="checkbox" id="' + properties[key].items.enum[enumKey] + '"/>&nbsp;' + properties[key].items.enum[enumKey] + '</a></li>');

                                $.each(App.Scan.DefaultParams[0], function (keyDefaultParams, valDefaultParams) {

                                    if (keyDefaultParams == key) {
                                        $('#' + parentElement + key).text(valDefaultParams);
                                        //console.log("@array valueeeeeeeeeeee-----"+JSON.stringify(valDefaultParams)); 
                                        $('#' + parentElement + key).attr('data-selected', JSON.stringify(valDefaultParams));

                                    }

                                });

                            }
                            loadCheckboxSelected(key);

                        } else if ((properties[key].items).hasOwnProperty('properties')) {

                            console.log("key at arr of obj " + key);

                            $('#collapse_' + parentElement + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a data-toggle="collapse" data-parent="collapse_' + key + '" href="#collapse_' + key + '" class="accordion-toggle collapsed">' + key + '</a></h4></div><div id="collapse_' + key + '" class="panel-collapse collapse"><div class="panel-body"><div class="row"></div></div></div</div>');

                            $('#collapse_' + key + '> .panel-body').toggleClass('addingCss');

                            $('#collapse_' + key + '> .panel-body').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div arrBtn"><input type="button" value="Add Form" class="addButton_' + key + '"><input type="button" value="Remove Form" class="removeButton_' + key + '"></div>');

                            //$('#collapse_' + key + '> .panel-body').append('<style>.wrapper:after{content:"";display:block;height:50px;}</style>');
                            //$('<style>.wrapper:after{content:"";display:block;height:50px;}</style>').appendTo('#collapse_' + key + '> .panel-body');
                            //$('#collapse_' + key + '> .panel-body:after').css({"content":"","display":"block","height":"50px"});

                            console.log("key at arr of obj...................... " + key);


                            addFormArrayOnClick(parentElement, key, properties);


                            //                        $('#collapse_' + parentElement + "-" + key + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div scrollable"><div id="TextBoxesGroup_' + parentElement + "_" + key + '"><div id="TextBoxDiv1_' + parentElement + "_" + key + '"></div></div><input type="button" value="Add Item" id="addButton_' + parentElement + "_" + key + '"><input type="button" value="Remove Item" id="removeButton_' + parentElement + "_" + key + '"><input type="button" value="Get Value" id="getButtonValue_' + parentElement + "_" + key + '"></div>');

                            // addTextBoxArray(parentElement, key);

                            //console.log("@ array of objects... !!!");

                            //                        $('#collapse_' + parentElement + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a data-toggle="collapse" data-parent="collapse_' + key + '" href="#collapse_' + key + '" class="accordion-toggle collapsed">' + key + '</a></h4></div><div id="collapse_' + key + '" class="panel-collapse collapse"><div class="panel-body"><div class="row"></div></div></div</div>');
                            //
                            //                        //console.log("array of objects " + JSON.stringify(properties[key].items.properties));
                            //                        //render(properties[key].items.properties, key);
                            //
                            //
                            //
                            //                        $('#collapse_' + key + ' > .panel-body > .row').attr('id', key + 1);
                            //                        $('#collapse_' + key + ' > .panel-body > .row').css({
                            //                            "border-style": "ridge",
                            //                            "margin-top": "5px"
                            //                        });
                            //
                            //                        $('#collapse_' + key + '> .panel-body').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><input type="button" value="Add Form" class="addButton_' + key + '"><input type="button" value="Remove Form" class="removeButton_' + key + '"><input type="button" value="Get Value" class="getButtonValue_' + key + '"></div>');
                            //
                            //
                            //
                            //                        //$('#collapse_' + key + ' > .panel-body').addClass("scrollable");
                            //                        addFormArrayOnClick(parentElement, key);

                        } else {

                            //console.log("@arrayyyyyyyyyy " + key + "parent element is" + parentElement);

                            $('#collapse_' + parentElement + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><a data-toggle="collapse" data-parent="collapse_' + parentElement + "-" + key + '" href="#collapse_' + parentElement + "-" + key + '" class="accordion-toggle collapsed">' + key + '</a></h4></div><div id="collapse_' + parentElement + "-" + key + '" class="panel-collapse collapse"><div class="panel-body"><div class="row"></div></div></div</div>');


                            $('#collapse_' + parentElement + "-" + key + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div scrollable"><div id="TextBoxesGroup_' + parentElement + "_" + key + '"><div id="TextBoxDiv1_' + parentElement + "_" + key + '"></div></div><input type="button" value="Add Item" id="addButton_' + parentElement + "_" + key + '"><input type="button" value="Remove Item" id="removeButton_' + parentElement + "_" + key + '"><input type="button" value="Get Value" id="getButtonValue_' + parentElement + "_" + key + '"></div>');

                            addTextBoxArray(parentElement, key);


                        }
                    }

                } else if (keyType === 'string' || keyType === 'integer') {
                    if (properties[key].hasOwnProperty('enum')) {
                        $('#collapse_' + parentElement + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><label for="' + parentElement + key + '">' + key + '</label><select class="form-control" name="select_ele" id="' + parentElement + key + '" data-type="' + keyType + '"></select></div>');
                        for (enumKey in properties[key].enum) {
                            $('#' + parentElement + key).append('<option value="' + properties[key].enum[enumKey] + '" >' + properties[key].enum[enumKey] + '</option>');
                            App.Scan.postObjUI[parentElement] = key;

                            $.each(App.Scan.DefaultParams[0], function (keyDefaultParams, valDefaultParams) {

                                if (keyDefaultParams == key) {
                                    $('#' + parentElement + key).val(valDefaultParams);
                                }

                            });
                        }
                    } else {
                        $('#collapse_' + parentElement + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><label for="' + parentElement + key + '">' + key + '</label><input type="text" class="form-control" id="' + parentElement + key + '" data-type="' + keyType + '"></div>');


                        $.each(App.Scan.DefaultParams[0], function (keyDefaultParams, valDefaultParams) {

                            if (keyDefaultParams == key) {
                                $('#' + parentElement + key).val(valDefaultParams);
                            }

                        });

                        //console.log("@ string/int" + parentElement);
                        //setDefaultVal(key);
                        console.log("@ --- string/int");
                    }
                } else if (keyType === 'boolean') {
                    $('#collapse_' + parentElement + ' > .panel-body > .row').append('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 left-div"><label for="' + parentElement + key + '">' + key + '</label>  <input type="checkbox" id="' + parentElement + key + '" value="check"></label></div>');
                    //console.log("@ boolean");
                    $.each(App.Scan.DefaultParams[0], function (keyDefaultParams, valDefaultParams) {
                        if (keyDefaultParams == key) {
                            if (valDefaultParams == true) {
                                $("#" + parentElement + key).attr("checked", true);
                            }
                        }
                    });

                }
            }
        }


        /* -------- add form dynamically on button click ----------- */
        function addFormArrayOnClick(parentElement, key, properties) {
            var counter = 1;
            console.log("ENTERING HERE @addFormArrayOnClick");
            $(".addButton_" + key + "").click(function () {



                if ($('#collapse_' + key + ' > .panel-body > #' + key + 1).length) // use this if you are using id to check
                {
                    // it exists

                    $('#collapse_' + key + ' > .panel-body > #' + key + 1).clone().attr('id', key + ++counter).appendTo('#collapse_' + key + ' > .panel-body');
                    counter++;

                } else {

                    $('#collapse_' + key + ' > .panel-body > .row').attr('id', key + 1);
                    render(properties[key].items.properties, key);
                    $('#collapse_' + key + ' > .panel-body > .row').css({
                        "border-style": "ridge",
                        "margin-top": "5px"
                    });


                }

            });

            $(".removeButton_" + key + "").on("click", function () {
                if (counter == 0) {
                    alert("No more textbox to remove");
                    return false;
                }

                $('#collapse_' + key + ' > .panel-body > #' + key + counter).remove();
                counter--;

            });


        }


        function setDefaultVal(key) {
            $.each(App.Scan.DefaultParams[0], function (keyDefaultParams, valDefaultParams) {
                if (keyDefaultParams == key) {
                    $('#' + key).val(valDefaultParams);
                }

            });
        }

        function traverse_it(obj) {
            for (var prop in obj) {
                if (typeof obj[prop] == 'object') {
                    if (Array.isArray(obj[prop]) == true) {

                        var PropName = prop;
                        var PropVal = obj[prop];
                        App.Scan.keyValMapObj[PropName] = PropVal
                    }
                    traverse_it(obj[prop]);
                } else {
                    var PropName = prop;
                    var PropVal = obj[prop];
                    App.Scan.keyValMapObj[PropName] = PropVal
                };
            }

        }

        /* ------------ FORMING JSON FROM SCHEMA -------------- */
        function _parseSwaggerRequiredParamPostBody(swaggerJsonRequiredParam) {
            for (keyReqParam in swaggerJsonRequiredParam) {
                App.Scan.postObjParent[keyReqParam] = "";
                renderPostBody(swaggerJsonRequiredParam, App.Scan.postObjUI);
            }
        }

        function _parseSwaggerPostBody(swaggerJson) {
            for (var key in swaggerJson) {
                App.Scan.postObjUI[key] = {};
                App.Scan.postObjParent[key] = {};
                var swagKeyType = swaggerJson[key].type;
                if (swaggerJson[key].type === 'array') {
                    App.Scan.postObjUI[key] = {};
                    App.Scan.postObjParent[key] = {};
                    renderPostBody(swaggerJson[key].items.properties, App.Scan.postObjUI[key]);

                    var temp1 = App.Scan.postObjUI[key];
                    App.Scan.postObjUI[key] = [];
                    App.Scan.postObjUI[key].push(temp1);

                    var temp2 = App.Scan.postObjParent[key];
                    App.Scan.postObjParent[key] = [];
                    App.Scan.postObjParent[key].push(temp2);

                } else if (swaggerJson[key].type === 'string') {
                    App.Scan.postObjUI[key] = 'aaa';
                    App.Scan.postObjParent[key] = 'aaa';
                } else if (swaggerJson[key].type === 'integer') {
                    App.Scan.postObjUI[key] = 1;
                    App.Scan.postObjParent[key] = 1;
                }
                var properties = swaggerJson[key].properties;
                renderPostBody(properties, App.Scan.postObjUI[key]);
            }
        }

        function renderPostBody(properties, parentObj) {
            for (var key in properties) {
                var keyType = properties[key].type;
                if (keyType === 'object' || typeof (keyType) === 'undefined') {
                    if (properties[key].hasOwnProperty('properties')) {
                        parentObj[key] = {}
                        renderPostBody(properties[key].properties, parentObj[key]);
                    }
                } else if (keyType === 'array') {
                    parentObj[key] = [];

                    if ((properties[key].items).hasOwnProperty('properties')) {
                        parentObj[key] = {};
                        renderPostBody(properties[key].items.properties, parentObj[key]);
                        var temp = parentObj[key];
                        parentObj[key] = [];
                        parentObj[key].push(temp);
                    }

                } else if (keyType === 'string') {
                    parentObj[key] = 'aaa';
                } else if (keyType === 'integer') {
                    parentObj[key] = 1;
                } else if (keyType === 'boolean') {
                    parentObj[key] = true;
                }
            }
        }

        function _comparePostObj(postObjUI, postObjParent) {

            for (i in postObjUI) {

                for (k in postObjParent) {
                    if (i == k) {
                        App.Scan.updatedpostObjUI[k] = postObjUI[k];

                    }

                }

            }
        }



        var exampleUI = {};

        function buildObj(obj, parentObj, parent) {
            //console.log("formJsson------------------------ " + obj);
            for (key in obj) {
                //console.log("formJson :  parent key " + parent);
                //console.log("formJson : " + obj[key] + " key " + key);
                if (typeof (obj[key]) === 'object') {
                    //console.log("if obj.....")
                    //console.log(",...." + Array.isArray(obj[key]))
                    if (Array.isArray(obj[key])) {
                        //console.log("if obj[Array]....." + key);
                        //console.log(key);
                        var value = $('#' + key).data('selected');
                        //console.log("avalue ............." + value);
                        parentObj[key] = value;
                        if (value == undefined) {
                            //console.log("key if undefided " + key);


                            if (document.getElementById('TextBoxesGroup_' + parent + "_" + key) != null) {
                                var inputCount = document.getElementById('TextBoxesGroup_' + parent + "_" + key).getElementsByTagName('input').length;
                                //console.log("inputcount" + inputCount);
                                var arr = [];
                                for (var k = 1; k <= inputCount; k++) {

                                    value = $('#textbox_' + parent + "_" + key + k).val();
                                    console.log("value if undefined " + value);
                                    arr.push(value);
                                }
                                parentObj[key] = arr;

                            } else {

                                var arrlen1 = $('#collapse_' + key + ' > .panel-body > .row').length;
                                console.log("array length --- arr of obj " + arrlen1);
                                var arrOfObj = [];

                                if ($('#collapse_' + key + ' > .panel-body > #' + key + 1).length) {
                                    for (var j = 1; j <= arrlen1; j++) {
                                        var l = obj[key].length;

                                        for (var i = 0; i < l; i++) {
                                            var objCreation = {};
                                            console.log("data items" + JSON.stringify(obj[key][i]));
                                            $.each(obj[key][i], function (k, v) {

                                                value = $('#' + key + j + ' > div > #' + key + k).val();
                                                console.log("value @ arr of obj " + k + " " + value);
                                                if (value == "check") {
                                                    value = $('#' + key + j + ' > div > #' + key + k).is(':checked');
                                                } else if (value == undefined) {
                                                    console.log("i am here !!!!!!!!!!!!!!!!!!!");

                                                    //                                                arrlen1 = $('#collapse_' + key + ' > .panel-body > .row').length;
                                                    //                                                console.log("array length1111111 --- arr of obj " + arrlen1);
                                                    //                                                var arrOfObj_2 = [];
                                                    //
                                                    //                                                if ($('#collapse_' + key + ' > .panel-body > #' + key + 1).length) {
                                                    //                                                    console.log("i am here !!!!!!!!!!!!!!!!!!!");
                                                    //                                                    for (var j2 = 1; j2 <= arrlen1; j2++) {
                                                    //                                                        var l2 = obj[key].length;
                                                    //                                                        for (var i2 = 0; i2 < l2; i2++) {
                                                    //                                                            var objCreation_2 = {};
                                                    //                                                            console.log("i am here22 !!!!!!!!!!!!!!!!!!!");
                                                    //                                                            console.log("data items" + JSON.stringify(obj[key][i2]));
                                                    //                                                            $.each(obj[key][i2], function (k2, v2) {
                                                    //                                                                console.log("i am here333 !!!!!!!!!!!!!!!!!!!");
                                                    //                                                                value = $('#' + key + j2 + ' > div > #' + key + k2).val();
                                                    //                                                                console.log("value @@@ arr of obj " + k2 + " " + value);
                                                    //                                                                objCreation_2[k2] = value;
                                                    //                                                            });
                                                    //
                                                    //                                                        }
                                                    //                                                        arrOfObj_2.push(objCreation_2);
                                                    //                                                        console.log("array of obj's ..2 " + JSON.stringify(arrOfObj_2));
                                                    //                                                        
                                                    //                                                    }
                                                    //                                                }
                                                    //
                                                    //                                                parentObj[key] = arrOfObj_2;

                                                }
                                                objCreation[k] = value;
                                            });

                                        }
                                        arrOfObj.push(objCreation);
                                        console.log("array of obj's .. " + JSON.stringify(arrOfObj));
                                        //console.log("Object creation " + JSON.stringify(objCreation));
                                    }
                                }
                                parentObj[key] = arrOfObj;

                            }

                        }
                    }
                } else {
                    //console.log("else : " + obj[key] + " key " + key);
                    parentObj[key] = {}
                    buildObj(obj[key], parentObj[key], key);
                }
            } else if (Array.isArray(obj[key])) {
                console.log(" printing array ");
            } else {
                var value = $("#" + parent + key).val(); // get the value from UI here
                console.log("#" + parent + key + "============" + value);
                var dataType = $("#" + parent + key).attr("data-type");
                console.log("Type at build obj" + dataType);
                if (value == "check") {
                    value = $("#" + parent + key).is(':checked');
                } else if (value == undefined) {

                    value = $("#accordionDefault" + key).is(':checked');

                } else if (dataType === "string") {
                    value = value;
                } else if (dataType === "integer") {
                    console.log(" value is int !!!!!!!!!!!!!!!!!" + key + " " + value);
                    var v = parseInt(value);
                    value = v;
                }

                parentObj[key] = value;
            }
        }
    }
};

//function buildFormObj(obj, parentObj) {
//    for (key in obj) {
//        var arrlen1 = $('#collapse_' + key + ' > .panel-body > .row').length;
//        console.log("array length --- arr of obj " + arrlen1);
//        var arrOfObj = [];
//
//        if ($('#collapse_' + key + ' > .panel-body > #' + key + 1).length) {
//            for (var j = 1; j <= arrlen1; j++) {
//                var l = obj[key].length;
//
//                for (var i = 0; i < l; i++) {
//                    var objCreation = {};
//                    console.log("data items" + JSON.stringify(obj[key][i]));
//                    $.each(obj[key][i], function (k, v) {
//
//                        value = $('#' + key + j + ' > div > #' + key + k).val();
//                        console.log("value @ arr of obj " + k + " " + value);
//                        if (value == "check") {
//                            value = $('#' + key + j + ' > div > #' + key + k).is(':checked');
//                        }
//                        objCreation[k] = value;
//                    });
//
//                }
//                arrOfObj.push(objCreation);
//                console.log("array of obj's .. " + JSON.stringify(arrOfObj));
//                //console.log("Object creation " + JSON.stringify(objCreation));
//            }
//        }
//        parentObj[key] = arrOfObj;
//
//    }
//};

//       
//        for (key in obj) {
//             console.log("formJson : " + obj[key] + " key " + key);
//            if (Array.isArray(obj[key])) {
//                var arr = [];
//                var value = $("#" + key).val();
//                arr.push(value);
//                parentObj[key] = arr;
//                continue;
//            } else if (typeof (obj[key]) === 'object') {
//                parentObj[key] = {}
//                buildObj(obj[key], parentObj[key]);
//            } else {
//                var value = $("#" + key).val(); // get the value from UI here
//                if (value == "check") {
//                    value = $("#" + key).is(':checked');
//                }
//                parentObj[key] = value;
//            }
//        }
//    }



var scanWFID;

$('body').on('click', '#start-btn-scanToApp', function () {
    //var exampleScanBody = App.paths["/jobs/scan/scan_to_app"].post.parameters[0].schema.example;
    //console.log(JSON.stringify(exampleUI));
    //console.log(JSON.stringify(exampleScanBody));
    buildObj(App.Scan.updatedpostObjUI, exampleUI, "");
    console.log("POST BODY : " + JSON.stringify(exampleUI));


    if (App.currentScreen !== 'sectionScanScreen') {
        $('#WebAPI_Home').addClass('hide');
        $("#sectionScanScreen").removeClass("hide");
        App.scanPreview.show();
        $(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code017"));
    }



    App.Util.serverRequest(App.URL.scanToAppURL, "POST", true, function (response, error) {
        if (response) {
            console.log("Scanning Success...!!!");

            $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code018"));
            App.Scan.scanWFID = response.WFID;
            //console.log("scanWFID : " + App.Scan.scanWFID);

        } else {
            console.log("Scanning Fail...!!!");
            $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code021") + "<br />" + " Error : " + error.xhr.responseText);
        }

    }, exampleUI);


});



return {
    show: show,
    exampleUI: exampleUI,
    scanWFID: scanWFID,
    _parseSwagger: _parseSwagger,
    _parseSwaggerRequiredParam: _parseSwaggerRequiredParam,
    setDefaultVal: setDefaultVal,
    render: render,
    traverse_it: traverse_it,
    buildObj: buildObj,
    keyValMapObj: keyValMapObj,
    DefaultParams: DefaultParams,
    _parseSwaggerPostBody: _parseSwaggerPostBody,
    updatedpostObjUI: updatedpostObjUI,
    _parseSwaggerRequiredParamPostBody: _parseSwaggerRequiredParamPostBody,
    _comparePostObj: _comparePostObj,
    postObjUI: postObjUI,
    postObjParent: postObjParent

};

})(window, jQuery);
