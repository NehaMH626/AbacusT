/* Copyright(c) 2015-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
App.Scan_to_File = (function (global, $, undefined) {

    var getDefaultParams_file;
    var scanWFID;
    var exampleUI = {};

    var show = function () {
        console.log("@ scan to file....");
    };


    $("#scanToFile-btn").on("click", function () {
        hideHomeScreen();
        console.log("@ scan to file....");
        $("#btn-start").html("<button type='button' class='btn btn-success btn-small start-btn' id='start-btn-scanToFile'>Start Job >></button>");
        $("#get-storage-fileList").remove();
        $("#get-appConv-fileList").remove();
        var traversingScanBody = App.paths["/jobs/scan/scan_to_file"].post.parameters[0].schema.allOf;
        //var scanBody = App.paths["/jobs/scan/scan_to_file"].post.parameters[0].schema.allOf[1].properties;
        //var scanRequiredBody = App.paths["/jobs/scan/scan_to_file"].post.parameters[0].schema.allOf[0].properties;
       
        App.Util.serverRequest(App.URL.scan_to_file, 'GET', false, function (response, error) {
            if (response) {
                console.log("GET_Success:" + JSON.stringify(response));
                App.Scan.traverse_it(response);
                getDefaultParams_file = App.Scan.DefaultParams.push(App.Scan.keyValMapObj);
                console.log('getDefaultValues Keyvaluemap obj is' + JSON.stringify(App.Scan.DefaultParams));

            } else {
                console.log("@scan_to_file" + error.xhr.status + error.xhr.responseText);
            }
        });

        //console.log("value in obj is" + App.Scan.DefaultParams[0].auto_event);
        //App.Scan._parseSwaggerRequiredParam(scanRequiredBody, App.Scan.DefaultParams);
        //App.Scan._parseSwagger(scanBody, App.Scan.DefaultParams);

        //App.Scan._parseSwaggerRequiredParamPostBody(scanRequiredBody);
        //App.Scan._parseSwaggerPostBody(scanBody);
        App.Scan._parseInitialProps(traversingScanBody);
        App.Scan._comparePostObj(App.Scan.postObjUI, App.Scan.postObjParent);
        //console.log("getting post body data " + JSON.stringify(App.Scan.postObjUI));
        //console.log("parent obj is " + JSON.stringify(App.Scan.postObjParent));
        //console.log("@@@@@@@@@@@@@Updated parent obj is " + JSON.stringify(App.Scan.updatedpostObjUI));

    });



    $('body').on('click', '#start-btn-scanToFile', function () {

        console.log("Start file job...");
        var exampleScanBody = App.paths["/jobs/scan/scan_to_file"].post.parameters[0].schema.example;
        console.log(JSON.stringify(exampleUI));

        App.Scan.buildObj(App.Scan.updatedpostObjUI, exampleUI, "");
        //App.Scan.buildObj(exampleScanBody, exampleUI);

        if (App.currentScreen !== 'sectionScanScreen') {
            $('#WebAPI_Home').addClass('hide');
            $("#sectionScanScreen").removeClass("hide");
            App.scanPreview.show();
            $(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code017"));
        }



        App.Util.serverRequest(App.URL.scan_to_file, "POST", true, function (response, error) {
            if (response) {
                console.log("Scanning Success...!!!");


                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code018"));
                App.Scan_to_File.scanWFID = response.WFID;
                console.log("scanWFID : " + App.Scan_to_File.scanWFID);

            } else {
                console.log("Scanning Fail...!!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code021") + "<br />" + " Error : " + error.xhr.responseText);
                // $(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code021"));
            }

        }, exampleUI);


    });




    return {
        show: show
    };

})(window, jQuery);
