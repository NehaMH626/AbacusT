/* Copyright(c) 2015-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
App.Scan = (function (global, $, undefined) {
    
   

    /* ---------------------------  ScanToApp Button Click Event ----------------------------- */

    // traverse completely 
    //            function traverse_it(obj) {
    //                    for (var prop in obj) {
    //                        if (typeof obj[prop] == 'object') {
    //                            // object
    //                            traverse_it(obj[prop]);
    //                        } else {
    //                            // something else
    //                            console.log('The value of ' + prop + ' is ' + obj[prop] + '.');
    //                            //$('#checkboxes').append('<input type="checkbox" />' + prop + ' : <input type="text" name="'+ obj[prop] +'"><br /><br />');
    //                        }
    //                    }
    //                }


    function traverse_it(obj) {       
        for (var prop in obj) {
            if (typeof obj[prop] == 'object') {              
                // object
                traverse_it(obj[prop]);
            } else {
                // something else
                if (prop == 'type') {
                    console.log('The value of ' + prop + ' is ' + obj[prop] + '.');
                    //$('#checkboxes').append('<input type="checkbox" />' + prop + ' : <input type="text" name="'+ obj[prop] +'"><br /><br />');
                }
            }
        }
    }




    var checkBox_ele = document.createElement("INPUT");
    checkBox_ele.setAttribute("type", "checkbox");

    var parsingSwagger = function (parentElement, obj_parse) {
        alert("heyyyyyyyyyy");

        var i, l, list, li;

        for (var keyEle in obj_parse) {
            if (typeof obj_parse[keyEle] == 'object') {              

                list = $("<ul></ul>").appendTo(parentElement);

                if (obj_parse[keyEle].properties) {
                    var infoJson1 = obj_parse[keyEle].properties;

                    console.log("type is undefined ...... " + keyEle);
                    //                    li = $("<li></li>").text(keyEle);
                    //                    //$('#divTable').append('<ul><li>' + keyEle + '</ul></li>');
                    //
                    //                    // buildList(li, items[objs]);


                    parsingSwagger(li, infoJson1);
                    list.append(li);
                    console.log(keyEle + ", " + infoJson1.type);

                } else {
                    console.log("------------ " + keyEle + "," + obj_parse[keyEle].type);
                    li = $("<li></li>").text(keyEle);

                    if (obj_parse[keyEle].type === "boolean") {

                        var boolEle = ('<tr><td>' + keyEle + '</td><td><input type="checkbox"/></td></tr>');
                        $('#divTable').append('<li>' + boolEle + '</li>');
                        //                        console.log("At boolean.................");

                    } else if (obj_parse[keyEle].type === ("string" || "integer")) {
                        //$('#jsonTable').append('<tr><td>' + keyEle + '</td><td><input type="text"/></td></tr>');
                        //                        console.log("At integer/string.................");

                        if (obj_parse[keyEle].enum) {

                            console.log("enum val : " + obj_parse[keyEle].enum);

                            //                            var strEle = ('<tr><td>' + keyEle + '</td><td><select id=' + keyEle + '></select></td></tr>');
                            //                            $('#divTable').append('<li>' + strEle + '</li>');
                            $('#jsonTable').append('<tr><td>' + keyEle + '</td><td><select id=' + keyEle + '></select></td></tr>');

                            for (var i = 0; i < obj_parse[keyEle].enum.length; i++) {
                                var option = $('<option></option>').text(obj_parse[keyEle].enum[i]);
                                $("#" + keyEle).append(option);
                                //                                console.log("@ enum : option val ----- ");

                            }

                        } else {

                            //                            var intEle = ('<tr><td>' + keyEle + '</td><td><input type="text"/></td></tr>');
                            //                            $('#divTable').append('<li>' + intEle + '</li>');
                            $('#jsonTable').append('<tr><td>' + keyEle + '</td><td><input type="text"/></td></tr>');
                        }
                    }

                }

            } else {
                //list = $("<ul></ul>").appendTo(parentElement);
                console.log(keyEle + "," + obj_parse[keyEle]);
            }
        }
    };


    function buildList(parentElement, items) {
        var i, l, list, li;
        if (typeof items != 'object') {
            return;
        } // return here if there are no items

        list = $("<ul></ul>").appendTo(parentElement);

        for (var objs in items) {

            if (items[objs].properties) {
                var infoJson1 = items[objs].properties;
                li = $("<li></li>").text(objs);


                //li = $("<li></li>").html(objs + '<input type="text"/>');
                buildList(li, infoJson1);
                list.append(li);

            } else {

                if (items[objs].type === "boolean") {
                    console.log("--------- boolean");
                    li = $("<li></li>").html(objs + '<input style="margin-left:30px;" type="checkbox"/>');
                    list.append(li);

                } else if (items[objs].type === ("string" || "integer")) {

                    if (items[objs].enum) {

                        console.log(objs + " *****  enum values : ******" + items[objs].enum);

                        // console.log("1111" + JSON.stringify(li));
                        for (var i = 0; i < items[objs].enum.length; i++) {
                            var li = $("<li></li>").html(objs + '<select style="margin-left:30px;" id=' + objs + '></select>');

                            //console.log("length of enum : " + items[objs].enum[i]);
                            //console.log("objs : -----" + objs);
                            //var option = $("#"+objs).append($('<option></option>').text(items[objs].enum[i]));
                            //console.log("ggggggg"+JSON.stringify(option));
                            $("#" + objs).append($('<option></option>').text(items[objs].enum[i]));

                            // $('#xyz').append(option);
                            console.log("@ enum : option val ----- ");
                            //$("#"+objs).append(option);

                        }

                        list.append(li);

                    } else if (items[objs].type === "integer") {

                        console.log("---integer ");
                        li = $("<li></li>").html(objs + '<input type="text"/>');
                        list.append(li);
                    }
                }
                //                console.log("*****" + objs);
                //                li = $("<li></li>").text(objs);
                //                list.append(li);

            }

        }

    }


    $("#scanToApp-btn").on("click", function () {
        document.getElementById("overlayNav").style.width = "980px";
        //        console.log(App.Scan.paths);
        var scanbody = App.paths["/jobs/scan/scan_to_app"].post.parameters[0].schema.properties;
        console.log(scanbody);
        var scanRequiredBody = App.paths["/jobs/scan/scan_to_app"].post.parameters[0].schema.allOf[0].properties;
        $("#startScan-btn").removeClass("hide");
        //console.log(JSON.stringify(scanbody));
        //        parsingSwagger(scanRequiredBody);
        // parsingSwagger(scanbody);



        buildList($('#divJson').empty(), scanbody);

        //        App.Util.serverRequest(App.URL.scanToAppURL, "GET", true, function (response, error) {
        //            if (response) {
        //                
        //                
        //                
        //                
        //            } else {
        //               console.error("Scan to app parameters could not be fetched from the server.");       
        //            }
        //            
        //        });




        //        App.Util.serverRequest(App.URL.scanToAppURL, "GET", true, function (response, error) {
        //            if (response) {
        //                console.log(response);
        ////                // Set auto event to true.
        ////                response["auto_event"] = true;
        ////
        ////                // Set the file format to JPEG.
        ////                response["scan_to_app_storage_parameter"]["file_output_method"]["output_file_format"] = "jpeg";
        ////
        ////                response["scan_parameter"]["scan_color_mode"] = "full_color";
        ////
        ////                // Delete the securepdf_setting property.
        ////                delete response["scan_to_app_storage_parameter"]["file_output_method"]["securepdf_setting"];
        ////
        ////
        ////
        ////                // Set the paper size to a4.
        ////                response["scan_parameter"]["scan_paper_size"]["paper_size"] = "a4";
        ////
        ////                // Copy the parameters into different objects for reset.
        ////                App.Scan.defaultScanParams = $.extend(true, {}, response);
        ////                App.Scan.modifiedScanParams = $.extend(true, {}, response);
        //
        //
        //            } else {
        //                console.error("Scan to app parameters could not be fetched from the server.");
        //            }
        //        });

    });

    $("#closeNav-icon").on("click", function () {
        document.getElementById("overlayNav").style.width = "0%";
        $("#startScan-btn").addClass("hide");
    });


    var show = function () {

        $("#scan").removeClass("hide");
        _startScan();
    };

    var scanWFID;
    $("#startScan-btn").on("click", function () {

        if (App.currentScreen !== 'sectionScanScreen') {
            $('#WebAPI_Home').addClass('hide');
            $("#sectionScanScreen").removeClass("hide");
            App.scanPreview.show();
        }


        App.Util.serverRequest(App.URL.scanToAppURL, "POST", true, function (response, error) {
            if (response) {
                console.log("Scanning Success...!!!");
                
                App.Scan.scanWFID = response.WFID;
                console.log("scanWFID : " +App.Scan.scanWFID);

            } else {
                console.log("Scanning Fail...!!!");
            }

        }, {
            "auto_event": false,
            "auto_adjust": true,
            "scan_parameter": {
                "generate_preview": true,
                "scan_color_mode": "full_color",
                "scan_paper_size": {
                    "paper_size": "auto"
                }
            },
            "scan_to_app_storage_parameter": {
                "is_appconv_mode": false,
                "file_output_method": {
                    "output_file_format": "pdf_multi",
                    "file_name": ""
                },
                "storage_path": ""
            }
        });


    });








    var _renderUI = function () {
        // Reinitialization of modified params.
        //        App.Scan.modifiedScanParams = $.extend(true, {}, App.Scan.defaultScanParams);
        //
        //        // Get the status of ADF. 
        //        App.Util.serverRequest(App.URL.ADFStatusURL, "GET", true, function (response) {
        //            if (response) {
        //                if (response.has_paper === true) {
        //                    enableScreen();
        //                } else {
        //                    disableScreen();
        //                }
        //            } else {
        //                console.log("ADF state could not be fetched from the server.");
        //            }
        //        });

        // Check the color radio button.
        //        var color = App.Scan.defaultScanParams["scan_parameter"]["scan_color_mode"];
        //        if (color === "full_color") {
        //            $('input:radio[id=scan-color-full]').prop('checked', true);
        //            $('input:radio[id=scan-color-black]').prop('checked', false);
        //        } else {
        //            $('input:radio[id=scan-color-black]').prop('checked', true);
        //            $('input:radio[id=scan-color-full]').prop('checked', false);
        //        }

        // Populate Resolution
        //        $("#scan-resolution-dropdown").empty();
        //        var val, $optionResolution;
        //        for (val in dropdownTexts["resolution"]) {
        //            $optionResolution = $('<option value="' + val + '">' + dropdownTexts["resolution"][val] + '</option>');
        //            if (val === App.Scan.defaultScanParams["scan_parameter"]["scan_resolution"]) {
        //                $optionResolution.attr('selected', 'selected');
        //            }
        //            $("#scan-resolution-dropdown").append($optionResolution);
        //        }

        // Populate File Format
        //        $("#scan-file-format-dropdown").empty();
        //        var val2, $optionFileFormat;
        //        for (val2 in dropdownTexts["file_format"]) {
        //            $optionFileFormat = $('<option value="' + val2 + '">' + dropdownTexts["file_format"][val2] + '</option>');
        //            if (val2 === App.Scan.defaultScanParams["scan_to_app_storage_parameter"]["file_output_method"]["output_file_format"]) {
        //                $optionFileFormat.attr('selected', 'selected');
        //            }
        //            $("#scan-file-format-dropdown").append($optionFileFormat);
        //        }
    };

    //    var enableScreen = function () {
    //        $("#scan-alert-msg").addClass("hide");
    //        $("#scan-start-btn").removeClass("disabled");
    //    };
    //
    //    var disableScreen = function () {
    //        $("#scan-alert-msg").removeClass("hide");
    //        $("#scan-start-btn").addClass("disabled");
    //    };

    var init = function () {
        //        // Get the default scan parameters.
        //        App.Util.serverRequest(App.URL.scanToAppURL, "GET", true, function (response) {
        //            if (response) {
        //                // Set auto event to true.
        //                response["auto_event"] = true;
        //
        //                // Set the file format to JPEG.
        //                response["scan_to_app_storage_parameter"]["file_output_method"]["output_file_format"] = "jpeg";
        //
        //                response["scan_parameter"]["scan_color_mode"] = "full_color";
        //
        //                // Delete the securepdf_setting property.
        //                delete response["scan_to_app_storage_parameter"]["file_output_method"]["securepdf_setting"];
        //
        //
        //
        //                // Set the paper size to a4.
        //                response["scan_parameter"]["scan_paper_size"]["paper_size"] = "a4";
        //
        //                // Copy the parameters into different objects for reset.
        //                App.Scan.defaultScanParams = $.extend(true, {}, response);
        //                App.Scan.modifiedScanParams = $.extend(true, {}, response);
        //
        //
        //                show();
        //            } else {
        //                console.error("Scan to app parameters could not be fetched from the server.");
        //            }
        //        });
    };

    var hide = function () {
        //        // Unregister Hard Key callbacks
        //        App.Util.unregistHardKeyCallback();
        //
        //        $("#scan").addClass("hide");
    };

    var _startScan = function () {
        //        console.log(JSON.stringify(App.Scan.defaultScanParams));
        //        if (!$("#scan-start-btn").hasClass("disabled")) {
        //            // Beep Sound
        //            App.Util.soundBeep();
        //
        //            App.Scan.hide();
        //            App.Progress.show();
        //
        //            // Set the text in the progress screen.
        //            $("#progress-msg").removeClass("alert-success").addClass("alert-danger").text(App.Util.getMessage("code018"));
        //
        //            // Start scantoapp job.
        //            App.Util.serverRequest(App.URL.scanToAppURL, "POST", true, function (response) {
        //                if (response) {
        //                    if (response.status === "OK") {
        //                        console.log("scantoapp status : OK");
        //                    } else {
        //                        console.log("scantoapp status : FAIL");
        //                    }
        //                } else {
        //                    console.error("scantoapp failed.");
        //                }
        //            }, App.Scan.modifiedScanParams);
        //        }
    }

    // Event listeners
    //    // Start button handler.
    //    $("#scan-start-btn").on("click", function () {
    //        _startScan();
    //    });

    // Reset button handler
    //    $("#scan-reset-btn").click(function () {
    //        // Beep Sound
    //        App.Util.soundBeep();
    //
    //        App.Scan.modifiedScanParams = $.extend(true, {}, App.Scan.defaultScanParams);
    //        _renderUI();
    //    });

    // Color radio button change handler
    //    $('input[type=radio][name=scan-color-selector]').on('change', function () {
    //        // Beep Sound
    //        App.Util.soundBeep();
    //
    //        switch ($(this).attr('id')) {
    //            case 'scan-color-black':
    //                App.Scan.modifiedScanParams["scan_parameter"]["scan_color_mode"] = "black";
    //                break;
    //            case 'scan-color-full':
    //                App.Scan.modifiedScanParams["scan_parameter"]["scan_color_mode"] = "full_color";
    //                break;
    //        }
    //    });

    // Scan resolution dropdown change handler
    //    $("#scan-resolution-dropdown").change(function () {
    //        App.Scan.modifiedScanParams["scan_parameter"]["scan_resolution"] = $(this).val();
    //    })

    // Scan file format dropdown change handler
    //    $("#scan-file-format-dropdown").change(function () {
    //        App.Scan.modifiedScanParams["scan_to_app_storage_parameter"]["file_output_method"]["output_file_format"] = $(this).val();
    //    })

    return {
        init: init,
        show: show,
        hide: hide,
        scanWFID: scanWFID
        //        enableScreen: enableScreen,
        //        disableScreen: disableScreen,

    };

})(window, jQuery);
