/* Copyright(c) 2015-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
App.Locale = (function (global, $, undefined) {
    var messages = {
        // English
        en_US: {
            code001: "WebAPI TestHomeApp",
            code002: "ScanToApp",
            code003: "Start Scan",
            code004: "Swap Page",
            code005: "Rotate Page",
            code006: "Finish",
            code007: "Cancel",
            code008: "Resume",
            code009: "Suspend",
            code010: "Rotation Angle",
            code011: "0",
            code012: "90",
            code013: "180",
            code014: "270",
            code015: "Swapping Successful ..!!",
            code016: "Swapping Failed ..!!",
            code017: "Please place paper on ADF",
            code018: "Scanning Started...",
            code019: "Scanning Completed!!",
            code020: "OK",
            code021: "Scanning Failed ..!!",
            code022: "Scanned Page : ",
            code023: "Scan Cancelled ..!! ",
            code024: "Cancel Scan .. Failed",
            code025: "Scan Resumed ..!!",
            code026: "Resume Scan .. Failed",
            code027: ".....suspended !!",
            code028: "Suspend Scan .. Failed",
            code029: "Home",
            code030: "Scan job..... Started ",
            code031: "Paper placed on ADF",
            code032: "Page Rotation..... Success",
            code033: "Page Rotation..... Failed",
            code034: "Continue ADF Scanning",
            code035: "Copy Job .... Started",
            code036: "Copy Job .... Failed",
            code037: ".....completed !!",
            code038: "Printing Started... !!",
            code039: "Printing Failed... !!",
            code040: "Printing Cancelled... !!",
            code041: "Printing Cancel...Failed !!",
            code042: "Printing Resumed !!",
            code043: "Printing Resume...Failed !!",
            code044: "AppConv Job Started !!",
            code045: "AppConv Job...Failed !!",
            code046: "AppSend_Email Started !!",
            code047: "AppSend_Email Job...Failed !!",
            code048: "AppSend_FTP Started !!",
            code049: "AppSend_FTP Job...Failed !!",
            code050: "AppSend_FTP Started !!",
            code051: "AppSend_FTP Job...Failed !!",
            code052: "Status Reason: "



        },

        // Japanese
        ja_JP: {
            code001: "WebAPI TestHomeApp",
            code002: "ScanToApp",
            code003: "Start Scan",
            code004: "Swap Page",
            code005: "Rotate Page",
            code006: "Finish",
            code007: "Cancel",
            code008: "Resume",
            code009: "Suspend",
            code010: "Rotation Angle",
            code011: "0",
            code012: "90",
            code013: "180",
            code014: "270",
            code015: "Swapping Successful ..!!",
            code016: "Swapping Failed ..!!",
            code017: "Please place paper on ADF",
            code018: "Scanning Started...",
            code019: "Scanning Completed ..!!",
            code020: "OK",
            code021: "Scanning Failed ..!!",
            code022: "Scanned Page : ",
            code023: "Scan Cancelled ..!! ",
            code024: "Cancel Scan .. Failed",
            code025: "Scan Resumed ..!!",
            code026: "Resume Scan .. Failed",
        }
    };

    return {
        messages: messages
    };

})(window, jQuery);