/* Copyright(c) 2015-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
var App = (function (global, $, undefined) {

    var appId = "";
    var appToken = {};
    var currentScreen = '';
    var appLanguage = "en_US";
    var paths;
    var categoryPathMethodMap = {};

    // Initialize the application

    function getCookie(name) {
        var value = "; " + document.cookie;
        var parts = value.split("; " + name + "=");
        if (parts.length == 2) return parts.pop().split(";").shift();
    };

    var init = function () {
        console.log("Application initialized...");
        var location = "";
        var arr = [];

        App.appToken['X-WebAPI-AccessToken'] = getCookie('accessToken');
        console.log("X-WebAPI-AccessToken-");
        console.log(App.appToken['X-WebAPI-AccessToken']);
        App.appId = "22yz1f58-068b-11e6-9463-ffffffffff00";
        App.Util.updateMessages();
        App.renderSwagger();
        //        App.Scan.show();
        //App.Scan.init();

        // Subscribe for SSE events.
        App.Util.subscribeSSE();

        // Event subscription for paperOnADF event.
        App.Util.serverRequest(App.URL.deviceStatusEventSubscriptionURL, "POST", true, function (response) {
            if (response) {
                console.log("Subscription for event : device_adf_paper_changed : success");
            } else {
                console.error("Subscription for event : device_adf_paper_changed : fail");
            }
        }, {
            "event_names": ["device_adf_paper_changed"]
        });

        // Event subscription for jobs.
        App.Util.serverRequest(App.URL.jobEventSubscriptionURL, "POST", true, function (response) {
            if (response) {
                console.log("Subscription for event : job : success");
            } else {
                console.error("Subscription for event : job : fail");
            }
        }, {
            "event_names": []
        });
    };

    /* --------------------------------- Parse Swagger ---------------------------------------*/

    var renderSwagger = function () {
        console.log("@ renderSwagger")
        var parser = new SwaggerParser();
        parser.dereference("vendors/js/swagger.json")
            .then(function (api) {
                App.paths = api.paths;
                console.log(App.paths);
                for (var path in paths) {
                    for (var method in paths[path]) {
                        var category = paths[path][method]['tags'][0];
                        //console.log(category);
                        if (!categoryPathMethodMap.hasOwnProperty(category)) {
                            categoryPathMethodMap[category] = {};
                        }
                        if (!categoryPathMethodMap[category].hasOwnProperty(path)) {
                            categoryPathMethodMap[category][path] = [];
                        }
                        categoryPathMethodMap[category][path].push(method);
                        //console.log( categoryPathMethodMap[category][path]);
                    }
                }
                App.Scan.show();
                //App.Scan_to_Email.show();
                //App.Scan.parsingSwagger_1();
            })
            .catch(function (err) {
                console.error('The API is invalid. ' + err.message);
            });
    };

    return {
        init: init,
        appId: appId,
        appToken: appToken,
        appLanguage: appLanguage,
        renderSwagger: renderSwagger,
        categoryPathMethodMap: categoryPathMethodMap,
        paths: paths,
        currentScreen: currentScreen
    };
}(window, jQuery));
