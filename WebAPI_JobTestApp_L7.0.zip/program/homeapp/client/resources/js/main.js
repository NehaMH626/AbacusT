/* Copyright(c) 2015-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
$(function() {
    App.init();
});