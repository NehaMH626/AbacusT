/* Copyright(c) 2015-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
App.Util = (function(global, $, undefined) {

    // For beep sound
    var _isEwb = (typeof __ewb__ !== "undefined");

    var soundBeep = function() {
        if (_isEwb) {
            __ewb__.beep("normal");
        }
    };

    // variable that holds the start key callback.
    var _startKeyCallback = null;

    // variable that holds the function clear key callback.
    var _fcKeyCallback = null;

    var registHardKeyCallback = function(startKeyCallback, fcKeyCallback) {
        console.log("method : registHardkeyCallback()");
        App.Util._startKeyCallback = startKeyCallback;
        App.Util._fcKeyCallback = fcKeyCallback;
    };

    var unregistHardKeyCallback = function() {
        console.log("method : unregistHardKeyCallback()");
        App.Util._startKeyCallback = null;
        App.Util._fcKeyCallback = null;
    };

    // Hard Key handler.
    $(document).on("keydown", function(e) {
        var key = e.originalEvent.keyIdentifier;
        if (key === "F20") {
            console.log("Press StartKey");
            if (typeof App.Util._startKeyCallback !== "function") {
                console.log("This screen is not handled this key.");
                return;
            }
            App.Util._startKeyCallback();

        } else if (key === "F22") {
            console.log("Press FCKey");
            if (typeof App.Util._fcKeyCallback !== "function") {
                console.log("This screen is not handled this key.");
                return;
            }
            App.Util._fcKeyCallback();

        } else {
            // Our application does not use NumberSign and Asterisk key.
            console.log("Our application does not use this key: " + key);
        }
    });

    var getMessage = function(code) {
        return App.Locale["messages"][App.appLanguage][code];
    };


    var updateMessages = function() {
        console.log("Language: " + App.appLanguage)
        $.each($(".js-localize"), function() {
            $(this).text(App.Locale["messages"][App.appLanguage][$(this).attr("data-message-id")]);
        });
    };

   var subscribeSSE = function () {
        console.log('Subscribing for SSE');
        global.EventManager = new cAPIEventManager(App.appId, App.appToken['X-WebAPI-AccessToken']);
        global.EventManager.addEventListener(App.EventReceiver.eventReceiver);
	global.EventManager.startAPIEvents();

    };


    var serverRequest = function (URL, method, asyncStatus, callback, jsonData) {
        console.log('Request URL: ' + URL + ', Method: ' + method);
        if (jsonData) {
            jsonData = JSON.stringify(jsonData);
            console.log('POST Data : ' + jsonData);
        }

        $.ajax({
            url: URL,
            type: method,
            async: asyncStatus,
            headers: App.appToken,
            data: jsonData,
            contentType: 'application/json',
            dataType: 'json',
            /* Some web APIs doesn't handle the '_' appended in the query string, So making cache to true now, otherwise cache should be false. */
            cache: true,
            success: function (response, status, xhr) {
                console.log('Response Data: ' + JSON.stringify(response));
                console.log('Response Data: ' + JSON.stringify(status));
                console.log('Response Data: ' + JSON.stringify(xhr));
                callback(response);
            },
            error: function (xhr, status, error) {
                console.error(xhr.status + ', ' + status + ', ' + error);
                console.error(xhr.responseText);
                callback(null, {"xhr": xhr, "status": status, "error": error});
            }
        });
    };
    
    return {
        serverRequest: serverRequest,
        subscribeSSE: subscribeSSE,
        getMessage: getMessage,
        updateMessages: updateMessages,
        soundBeep: soundBeep,
        registHardKeyCallback: registHardKeyCallback,
        unregistHardKeyCallback: unregistHardKeyCallback
    };

})(window, jQuery);