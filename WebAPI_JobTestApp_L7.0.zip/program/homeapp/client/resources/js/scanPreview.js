App.scanPreview = (function (global, $, undefined) {

    var generate_preview_bool;
    var preview_option;
    var scanWFID;
    var fileFormatOption;
    var rotationAngleOption;

    var show = function () {
        //deteteStorageFiles();
        $('select[id=rotationAngle-select-val]').val("Please Select");
        $("#fromPage").val('');
        $("#toPage").val('');

    }

    var deteteStorageFiles = function () {

        App.Util.serverRequest(App.URL.deleteAppStorageFiles, "DELETE", true, function (response, error) {
            if (response) {
                console.log("Deleting App Storage Files.. Success!!");
            } else {
                console.log("Deleting App Storage Files.. Fail!!");
            }
        });
    };

    /* --------------------------------------Enable and Disable Screen -----------------------------------------*/
    var enableScreen = function () {
        //        $(".alert").addClass("hide");
        //$("#scan-start-btn").removeClass("disabled");
        $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code031"));

    };

    var disableScreen = function () {
        $(".alert").removeClass("hide");
        //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code024"));
        //$("#scan-start-btn").addClass("disabled");
    };




    var getTotalPage;

    var getScanData = function () {
        App.Util.serverRequest(App.URL.getScan + "/" + App.Scan.scanWFID, "GET", true, function (response, error) {
            console.log("get scanned data...!!")
            if (response) {
                App.Scan.getTotalPage = response.page_scanned_result.total_pages;
            } else {
                console.log("Failed to get scanned data...!!");
            }
        });
    };


    var hide = function () {
        $("#scan").addClass("hide");
    };


    var imgTag;
    var leftOffset;

    /* -------------------- Right Arrow and Left Arrow Click Events -------------------------------------------*/
    $("#rightArrow").click(function () {
        console.log("right arrow click event...!!!");
        var leftOffsetVal = '-=120px';
        applyLeftNavigationInitial();
        var $imageList = $("#image-list");
        var currentImgListLeftVal = $imageList.position().left;
        console.log("Pos" + App.EventReceiver.eventReceiver.lastImgListVal + " currentLeftVal" + currentImgListLeftVal);
        if (App.EventReceiver.eventReceiver.lastImgListVal <= currentImgListLeftVal) {

            $("#rightArrow").addClass("right-arrow");

            $("#image-list").animate({
                left: leftOffsetVal
            }, 300);

        } else {
            $("#rightArrow").removeClass("right-arrow");
        }
    });

    $("#leftArrow").click(function () {
        console.log("left arrow click event...!!!");
        var rightOffsetVal = '+=120px';
        var $imageList = $("#image-list");
        var firstPagePost = $imageList.position().left;

        applyLeftNavigationInitial();
        applyRightNavigationEnd();
        if ($("#leftArrow").hasClass("left-arrow")) {

            if (firstPagePost <= '-350') {
                $("#image-list").animate({
                    left: rightOffsetVal
                }, 300);
            }
        }
    });


    /* ------------------------------------ Enable and disble right and left arrow initially--------------------------*/

    var applyLeftNavigationInitial = function () {

        var $imageList = $("#image-list");
        var firstPagePos = $imageList.position().left;
        var firstDiv = $(".prev-item").first().position().left;

        if (firstPagePos <= '-450') {
            $("#leftArrow").addClass("left-arrow");

        } else {
            $("#leftArrow").removeClass("left-arrow");
        }

    };

    var applyRightNavigationInitial = function () {

        if (App.EventReceiver.totalCount > 4) {
            $("#rightArrow").addClass("right-arrow");

        } else {
            $("#rightArrow").removeClass("right-arrow");
        }
    };

    var applyRightNavigationEnd = function () {

        var $imageListDiv = $("#image-list");
        var curLeftVal = $imageListDiv.position().left;
        console.log("exceuting here ... " + curLeftVal + '>' + App.EventReceiver.eventReceiver.lastImgListVal);
        if (curLeftVal > App.EventReceiver.eventReceiver.lastImgListVal) {
            $("#rightArrow").addClass("right-arrow");
        }

    };

    /* ---------------------------------------------- Slide Preview  -------------------------------------------*/

    var pageId;
    var img;
    var previewSlider = function () {
        var imgTag;
        console.log("Path : " + App.EventReceiver.eventReceiver.previewPath + "  pagenum : " + App.EventReceiver.eventReceiver.pageNum);


        //$(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code022") + App.EventReceiver.eventReceiver.pageNum);

        //        imgTag = $("<div class='prev-item' style='left:" + (380 + ((130 + 25) * App.EventReceiver.totalCount)) + "px;'><div class='preview-pagenum'>" + App.EventReceiver.eventReceiver.pageNum + "</div><div class='preview-thumb pageId" + App.EventReceiver.eventReceiver.pageNum + "' style='background-image: url(" + App.EventReceiver.eventReceiver.previewPath + ");' data-page-id=" + App.EventReceiver.eventReceiver.pageNum + " ></div></div>");
        imgTag = $("<div class='prev-item' style='left:" + (380 + ((130 + 25) * App.EventReceiver.totalCount)) + "px;'><div class='preview-pagenum'>" + App.EventReceiver.eventReceiver.pageNum + "</div><img src=" + App.EventReceiver.eventReceiver.previewPath + " class='preview-thumb pageId" + App.EventReceiver.eventReceiver.pageNum + "' data-page-id=" + App.EventReceiver.eventReceiver.pageNum + "></div>");
        $("#image-list").append(imgTag);
        img = new Image();
        img.onload = function () {
            orientationType = (img.width > img.height ? "landscape" : "portrait");
            $('.pageId' + App.EventReceiver.eventReceiver.pageNum).attr("data-orientation-type", orientationType);
            console.log("get width and height " + img.width + "x" + img.height);
            if (orientationType === "landscape") {
                $(".pageId" + App.EventReceiver.eventReceiver.pageNum).css({
                        'height': "92px",
                        'width': "130px",
                        'margin-top': "67px"
                    })
                    //pageInfo.attr("data-orientation-type", "portrait");  
            } else if (orientationType === "portrait") {
                $(".pageId" + App.EventReceiver.eventReceiver.pageNum).css({
                        'height': "200px",
                        'width': "130px",
                        'margin': "0"
                    })
                    //pageInfo.attr("data-orientation-type", "landscape"); 
            }
        };

        img.src = App.EventReceiver.eventReceiver.previewPath + "?v=" + Math.random();

        leftOffset = '-=130px';

        $("#image-list").animate({
            left: leftOffset
        }, 300);

        // $("#leftArrow").addClass("left-arrow");
        $("#rightArrow").addClass("right-arrow");
        applyLeftNavigationInitial();
        applyRightNavigationInitial();

        $(".preview-thumb").click(function () {
            console.log("click event ..... preview-thumb");
            $(".selected").removeClass("selected");
            $(this).addClass("selected");
        });

    };


    /* ---------------------------------------------- Rotate Angle button click  -----------------------------------*/

    // dropdown change option ..
    $('select[id=rotationAngle-select-val]').change(function () {
        rotationAngleOption = $(this).val();
        console.log("Rotation-Angle Selected: " + rotationAngleOption);
    });

    $("#action-rotate").click(function () {
        var $imageList = $("#image-list");
        App.scanPreview.pageId = $imageList.find("img.selected").attr("data-page-id");
        console.log(App.scanPreview.pageId);
        console.log("Rotate Angle----click button event");
        if (rotationAngleOption != undefined || '') {

            if (App.scanPreview.pageId != undefined || '') {
                App.Util.serverRequest(App.URL.getScan + "/" + App.EventReceiver.eventReceiver.get_jobID + "/scanned/" + App.scanPreview.pageId + "/actions/rotate_page", "POST", true, function (response, error) {
                    if (response) {
                        console.log("Scanning Success...!!!");
                        if (response.status == "OK") {
                            console.log("rotation start...");
                            // ---- rotation operation(90, 180,270) ----
                            rotationOperation();
                            $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code032"));

                        }
                    } else {
                        console.log("Rotation Fail...!!!");
                        $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code033") + "<br />" + " Error : " + error.xhr.responseText);
                    }
                }, {
                    "rotation_angle": rotationAngleOption
                });
            } else {
                alert("Please select the page to be rotated");
            }
        } else {
            alert("Please select the Rotation Angle");
        }

    });

    // -------------------- rotation operation(90, 180, 270) ------------------------------

    var rotationOperation = function () {

        var $imageList = $("#image-list");
        console.log(App.scanPreview.pageId);
        var pageInfo = $imageList.find("img.selected");
        pageInfo.addClass("prev");
        var img_orientationType = pageInfo.attr("data-orientation-type");
        if (img_orientationType === "landscape") {
            if (parseInt(rotationAngleOption) == 90 || parseInt(rotationAngleOption) == 270) {
                console.log("inside 90 || 270");
                var angle = ((pageInfo.data('angle') + parseInt(rotationAngleOption)) || parseInt(rotationAngleOption));
                pageInfo.css({
                    'transform': 'rotate(' + angle + 'deg)'
                });
                console.log("pageInfo.height()_landscape " + pageInfo.height());
                if (pageInfo.height() < 90) {
                    pageInfo.animate({

                        //                        'height': "130px",
                        //                        'width': "200px",
                        'height': "130px",
                        'width': "200px",
                        'margin-top': "35px",
                        'margin-left': "-35px"

                    }, 50);

                } else if (pageInfo.height() >= 126) {
                    pageInfo.animate({
                        'height': "92px",
                        'width': "130px",
                        'margin': "0px",
                        'margin-top': "67px",
                    }, 50);
                }
                //pageInfo.attr("data-orientation-type", "portrait");
                pageInfo.data('angle', angle);

            } else if (parseInt(rotationAngleOption) == 0 || parseInt(rotationAngleOption) == 180) {
                console.log("inside 0 || 180");
                var angle = ((pageInfo.data('angle') + parseInt(rotationAngleOption)) || parseInt(rotationAngleOption));
                pageInfo.css({
                    'transform': 'rotate(' + angle + 'deg)'
                });
                pageInfo.data('angle', angle);
            }
            //pageInfo.attr("data-orientation-type", "portrait");  
        } else if (img_orientationType === "portrait") {
            if (parseInt(rotationAngleOption) == 90 || parseInt(rotationAngleOption) == 270) {
                var angle = ((pageInfo.data('angle') + parseInt(rotationAngleOption)) || parseInt(rotationAngleOption));
                pageInfo.css({
                    'transform': 'rotate(' + angle + 'deg)'
                });
                console.log("pageInfo.height()_portrait " + pageInfo.height());
                if (pageInfo.height() >= 196) {
                    pageInfo.animate({
                        'height': "130px",
                        'width': "92px",
                        'margin-top': "51px",
                        'margin-left': "19px"
                    }, 50);
                } else if (pageInfo.height() <= 126) {
                    pageInfo.animate({
                        'height': "200px",
                        'width': "130px",
                        'margin': "0"

                    }, 50);
                }
                //pageInfo.attr("data-orientation-type", "landscape");
                pageInfo.data('angle', angle);

            } else if (parseInt(rotationAngleOption) == 0 || parseInt(rotationAngleOption) == 180) {
                var angle = ((pageInfo.data('angle') + parseInt(rotationAngleOption)) || parseInt(rotationAngleOption));
                pageInfo.css({
                    'transform': 'rotate(' + angle + 'deg)'
                });
                pageInfo.data('angle', angle);
            }
        }

    };


    /* ----------------------------------------------Page Swapping -------------------------------------------*/
    var swap_event = false;
    $("#swap-page").click(function () {
        var fromPageNum = $("#fromPage").val(),
            toPageNum = $("#toPage").val();
        console.log("swap_event " + swap_event);
        if (swap_event == false) {
            changePageOrder(fromPageNum, toPageNum);
            console.log("inside swap_event " + swap_event)
        }

    });

    var changePageOrder = function (fromPageNum, toPageNum) {


        var sourcePageNumber = parseInt(fromPageNum),
            destinationPageNumber = parseInt(toPageNum),
            sourceLeftPos,
            sourceElem,
            destinationElem,
            toBeMovedElemsLeft,
            toBeMovedElems,
            destDataPageId,
            destTempLeft,
            sourceCount,
            $imageList = $("#image-list");
        $imageList.find("img.preview-thumb").removeClass("selected");
        if (sourcePageNumber != "" && destinationPageNumber != "") {
            swap_event = true;
            //$('#swap-page').unbind("click");
            //$('#swap-page').prop('disabled', true);
            App.Util.serverRequest(App.URL.getScan + "/" + App.EventReceiver.eventReceiver.get_jobID + "/scanned/" + sourcePageNumber + "/page_num", "PATCH", true, function (response, error) {
                if (response) {

                    if (sourcePageNumber < destinationPageNumber) {

                        destTempLeft = parseInt($imageList.find("img.preview-thumb").filter("[data-page-id=" + destinationPageNumber + "]").closest(".prev-item").css("left"));
                        sourceElem = $imageList.find("img.preview-thumb").filter("[data-page-id=" + sourcePageNumber + "]").closest(".prev-item");

                        console.log("destinationTempLeft Val : " + destTempLeft);
                        if (destTempLeft != 'NaN') {
                            sourceCount = sourcePageNumber + 1;

                            for (sourceCount; sourceCount <= destinationPageNumber; sourceCount++) {

                                toBeMovedElems = $imageList.find("img.preview-thumb").filter("[data-page-id=" + sourceCount + "]").closest(".prev-item");
                                toBeMovedElemsLeft = parseInt($imageList.find("img.preview-thumb").filter("[data-page-id=" + sourceCount + "]").closest(".prev-item").css("left"));

                                toBeMovedElems.find(".preview-thumb").attr("data-page-id", sourceCount - 1);
                                toBeMovedElems.find(".preview-pagenum").text(sourceCount - 1);
                                //                                toBeMovedElems.animate({
                                //                                    left: ((toBeMovedElemsLeft - 155) + 'px')
                                //                                }, 700, function(){
                                //                                    $('#swap-page').bind("click");
                                //                                });
                                toBeMovedElems.animate({
                                    left: ((toBeMovedElemsLeft - 155) + 'px')
                                }, 700, function () {
                                    console.log("animating....");
                                    //swap_event = false;
                                });
                            }

                            sourceElem.animate({
                                left: (destTempLeft + 'px')
                            }, 700, function () {
                                sourceElem.find(".preview-thumb").attr("data-page-id", destinationPageNumber);
                                sourceElem.find(".preview-pagenum").text(destinationPageNumber);
                                swap_event = false;
//                                setTimeout(function () {
//                                    swap_event == false;
//                                    //$('#swap-page').bind("click");
//                                }, 100);
                                //$('#swap-page').prop('disabled', false);
                            });
                        }

                    } else if (sourcePageNumber > destinationPageNumber) {

                        destTempLeft = parseInt($imageList.find("img.preview-thumb").filter("[data-page-id=" + destinationPageNumber + "]").closest(".prev-item").css("left"));

                        sourceElem = $imageList.find("img.preview-thumb").filter("[data-page-id=" + sourcePageNumber + "]").closest(".prev-item");
                        console.log("destinationTempLeft Val : " + destTempLeft);
                        if (destTempLeft != 'NaN') {
                            sourceCount = parseInt(sourcePageNumber) - 1;
                            for (sourceCount; sourceCount >= destinationPageNumber; sourceCount--) {
                                toBeMovedElems = $imageList.find("img.preview-thumb").filter("[data-page-id=" + sourceCount + "]").closest(".prev-item");
                                toBeMovedElemsLeft = parseInt($imageList.find("img.preview-thumb").filter("[data-page-id=" + sourceCount + "]").closest(".prev-item").css("left"));

                                toBeMovedElems.find(".preview-thumb").attr("data-page-id", sourceCount + 1);
                                toBeMovedElems.find(".preview-pagenum").text(sourceCount + 1);
                                toBeMovedElems.animate({
                                    left: ((toBeMovedElemsLeft + 155) + 'px')
                                }, 700, function () {
                                    console.log("animating....");
                                    //swap_event = false;
//                                    setTimeout(function () {
//                                        console.log("animating....");
//                                        //swap_event == false;
//                                    //$('#swap-page').bind("click");
//                                }, 100);
                                });

                            }

                            sourceElem.animate({
                                left: (destTempLeft + 'px')
                            }, 700, function () {
                                sourceElem.find(".preview-thumb").attr("data-page-id", destinationPageNumber);
                                sourceElem.find(".preview-pagenum").text(destinationPageNumber);
                                swap_event = false;
//                                setTimeout(function () {
//                                    swap_event == false;
//                                    //$('#swap-page').bind("click");
//                                }, 100);
                                //$('#swap-page').prop('disabled', false);
                            });

                        }
                    }
                    $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code015"));

                } else {
                    console.log("Failed to Swap Page...!!");
                    $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code016") + "<br />" + " Error : " + error.xhr.responseText);
                    // $(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code016"));
                }
            }, {
                "page_num": destinationPageNumber
            });
        }
        console.log("completing swap_event.....!!!!");
        //swap_event = false;
        console.log("completing swap_event.....!!!!" + swap_event);
    };

    /* ---------------------------------------------- Scan Finish -------------------------------------------*/
    $("#finish-scan").click(function () {
        console.log("Finish Scanning click event...!!");
        App.Util.serverRequest(App.URL.getScan + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Finish Scanning..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code019"));
                $("#image-list").empty();
                $("#image-list").css({
                    "width": "100%",
                    "position": "relative",
                    "height": "300px",
                    "left": "0px"
                });
                App.EventReceiver.totalCount = 0;
                $("#rightArrow").removeClass("right-arrow");
                $("#leftArrow").removeClass("left-arrow");

            } else {
                console.log("Failed to finish scan...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code021") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code021"));
            }
        }, {
            "job_action": "finish"
        });

    });


    /* ---------------------------------------------- Scan Cancel -------------------------------------------*/
    $("#cancel-scan").click(function () {
        console.log("Cancel Scanning click event...!!");
        App.Util.serverRequest(App.URL.getScan + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Cancel Scanning..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code023"));
                $("#image-list").empty();
                $("#image-list").css({
                    "width": "100%",
                    "position": "relative",
                    "height": "300px",
                    "left": "0px"
                });
                App.EventReceiver.totalCount = 0;
                $("#rightArrow").removeClass("right-arrow");
                $("#leftArrow").removeClass("left-arrow");

            } else {
                console.log("Failed to Cancel scan...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code024") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code024"));
            }
        }, {
            "job_action": "cancel"
        });
    });


    /* ---------------------------------------------- Resume  -------------------------------------------*/
    $("#resume-scan").click(function () {
        console.log("Resume Scanning click event...!!");
        App.Util.serverRequest(App.URL.getScan + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Resume Scanning..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code025"));
            } else {
                console.log("Failed to Resume scan...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code026") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code026"));
            }
        }, {
            "job_action": "resume"
        });
    });


    /* ---------------------------------------------- Suspend -------------------------------------------*/
    $("#suspend-scan").click(function () {
        console.log("Suspend Scanning click event...!!");
        App.Util.serverRequest(App.URL.getScan + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Suspend Scanning..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code027"));
            } else {
                console.log("Failed to Resume scan...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code028") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code028"));
            }
        }, {
            "job_action": "stop"
        });
    });

    /* ---------------------------------------------- Back_to_Home -------------------------------------------*/
    $("#back_to_home").click(function () {
        //alert(App.EventReceiver.eventReceiver.status);  
         $("#WebAPI_main_screen").addClass('show-main-screen');
        if (App.EventReceiver.eventReceiver.eventName !== "jobs_completed") {
            var r = confirm("Job is not yet completed, Are you sure you want to go back to home screen?");
            if (r == true) {
                console.log("Back_to_Home ....!!");
                //$('#accordion').empty();
                // $('#collapse_accordionDefault > .panel-body > .row').empty();
                if (App.currentScreen !== 'WebAPI_Home') {
                    $("#sectionScanScreen").addClass("hide");
                    $("#myNav").addClass("overlay_hide");
                    $('#WebAPI_Home').removeClass('hide');
                    closeNav();
                }

            } else {
                return false;
            }
        } else {
            console.log("inside else Back_to_Home ....!!");
            //$('#accordion').empty();
            //$('#collapse_accordionDefault > .panel-body > .row').empty();
            if (App.currentScreen !== 'WebAPI_Home') {
                $("#sectionScanScreen").addClass("hide");
                $("#myNav").addClass("overlay_hide");
                $('#WebAPI_Home').removeClass('hide');
                closeNav();
            }

        }


        App.Scan.DefaultParams = [];
        App.Scan.keyValMapObj = {};
        App.Scan.postObjUI = {};
        App.Scan.postObjParent = {};
        App.Scan.updatedpostObjUI = {};

    });

    return {
        show: show,
        enableScreen: enableScreen,
        disableScreen: disableScreen,
        pageId: pageId,
        getScanData: getScanData,
        previewSlider: previewSlider
    }


})(window, jQuery);
