App.Appsend_Samba = (function (global, $, undefined) {

    var getDefaultParams_appSendSamba;
    var appSendSamba_WFID;
    var exampleUI = {};


    var show = function () {
        console.log("@ appSendSamba....");
    };


    $("#appsend-samba-btn").on("click", function () {
        hideHomeScreen();
        show();
        $("#btn-start").html("<button type='button' class='btn btn-success btn-small start-btn' id='start-btn-appSendSamba'>Start Job >></button>");
        $("#get-storage-fileList").remove();
        $("#get-appConv-fileList").remove();


        // var appSendSambaBody = App.paths["/jobs/appsend/samba"].post.parameters[0].schema.allOf[1].properties;
        // var appSendSambaRequiredBody = App.paths["/jobs/appsend/samba"].post.parameters[0].schema.allOf[0].properties;
        // console.log(JSON.stringify(appSendSambaRequiredBody));
        // console.log(JSON.stringify(appSendSambaBody));
        var traversingScanBody = App.paths["/jobs/appsend/samba"].post.parameters[0].schema.allOf;
        App.Util.serverRequest(App.URL.appSendSamba, 'GET', false, function (response, error) {
            if (response) {
                console.log("GET_Success:" + JSON.stringify(response));
                App.Scan.traverse_it(response);
                getDefaultParams_appSendSamba = App.Scan.DefaultParams.push(App.Scan.keyValMapObj);
                console.log('getDefaultValues Keyvaluemap obj is' + JSON.stringify(App.Scan.DefaultParams));

            } else {
                console.log("@appSendSamba" + error.xhr.status + error.xhr.responseText);
            }
        });

        //console.log("value in obj is" + App.Scan.DefaultParams[0].auto_event);
        // App.Scan._parseSwaggerRequiredParam(appSendSambaRequiredBody, App.Scan.DefaultParams);
        // App.Scan._parseSwagger(appSendSambaBody, App.Scan.DefaultParams);

        // App.Scan._parseSwaggerRequiredParamPostBody(appSendSambaRequiredBody);
        // App.Scan._parseSwaggerPostBody(appSendSambaBody);
        App.Scan._parseInitialProps(traversingScanBody);
        App.Scan._comparePostObj(App.Scan.postObjUI, App.Scan.postObjParent);
        // console.log("getting post body data " + JSON.stringify(App.Scan.postObjUI));
        // console.log("parent obj is " + JSON.stringify(App.Scan.postObjParent));
        // console.log("@@@@@@@@@@@@@Updated parent obj is " + JSON.stringify(App.Scan.updatedpostObjUI));

    });


    $('body').on('click', '#start-btn-appSendSamba', function () {

        console.log("Start appSendSamba job...");
        //var exampleScanBody = App.paths["/jobs/scan/scan_to_email"].post.parameters[0].schema.example;
        console.log(JSON.stringify(exampleUI));
        //console.log(".........." + JSON.stringify(exampleScanBody));
        App.Scan.buildObj(App.Scan.updatedpostObjUI, exampleUI, "");
        //App.Scan.buildObj(exampleScanBody, exampleUI);

        if (App.currentScreen !== 'sectionAppconvScreen') {
            $('#WebAPI_Home').addClass('hide');
            $("#sectionAppconvScreen").removeClass("hide");
            //App.scanPreview.show();
            $(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code017"));
        }


        App.Util.serverRequest(App.URL.appSendSamba, "POST", true, function (response, error) {
            if (response) {
                console.log("appSendSamba Success...!!!");

                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code050"));
                appSendEmail_WFID = response.WFID;
                console.log("appSendSamba_WFID : " + appSendSamba_WFID);

            } else {
                console.log("appSendSamba Fail...!!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code051") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code021 " + "Error : " + error.error));
            }
        }, exampleUI);
    });

    
    return {
        show: show,
    };

})(window, jQuery);
