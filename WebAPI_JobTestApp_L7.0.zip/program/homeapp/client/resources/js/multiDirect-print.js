App.MultiDirect_Print = (function (global, $, undefined) {

    var getDefaultParams_multiDirectPrint;
    var printWFID;
    var exampleUI = {};


    var show = function () {

        console.log("@ multiDirectPrint....");

    };




    $("#multiDirPrint-btn").on("click", function () {
         hideHomeScreen();
        $("#btn-start").html("<button type='button' class='btn btn-success btn-small start-btn' id='start-btn-multiDirectPrint'>Start Job >></button>");
        $("#get-appConv-fileList").remove();
        
        $("#storage-fileList").html("<button type='button' class='btn btn-success btn-small appStorage-list' id='get-storage-fileList'>App_Storage Files >></button>");
        
        // var printBody = App.paths["/jobs/print/multi_direct_print"].post.parameters[0].schema.allOf[1].properties;
        // var printRequiredBody = App.paths["/jobs/print/multi_direct_print"].post.parameters[0].schema.allOf[0].properties;
        // console.log(JSON.stringify(printRequiredBody));
        // console.log(JSON.stringify(printBody));
        var traversingScanBody = App.paths["/jobs/print/multi_direct_print"].post.parameters[0].schema.allOf;
        App.Util.serverRequest(App.URL.direct_Print, 'GET', false, function (response, error) {
            if (response) {
                console.log("GET_Success:" + JSON.stringify(response));
                App.Scan.traverse_it(response);
                getDefaultParams_multiDirectPrint = App.Scan.DefaultParams.push(App.Scan.keyValMapObj);
                console.log('getDefaultValues KeyValueMap obj is' + JSON.stringify(App.Scan.DefaultParams));
            } else {
                console.log("@multiDirectPrint" + error.xhr.status + error.xhr.responseText);
            }
        });

        // console.log("value in obj is" + App.Scan.DefaultParams[0].auto_event);
        // App.Scan._parseSwaggerRequiredParam(printRequiredBody, App.Scan.DefaultParams);
        // App.Scan._parseSwagger(printBody, App.Scan.DefaultParams);

        // App.Scan._parseSwaggerRequiredParamPostBody(printRequiredBody);
        // App.Scan._parseSwaggerPostBody(printBody);
        App.Scan._parseInitialProps(traversingScanBody);
        App.Scan._comparePostObj(App.Scan.postObjUI, App.Scan.postObjParent);
        // console.log("getting post body data " + JSON.stringify(App.Scan.postObjUI));
        // console.log("parent obj is " + JSON.stringify(App.Scan.postObjParent));
        // console.log("@@@@@@@@@@@@@Updated parent obj is " + JSON.stringify(App.Scan.updatedpostObjUI));

    });


    $('body').on('click', '#start-btn-multiDirectPrint', function () {

        console.log("Start multiDirectPrint job...");
        //var exampleScanBody = App.paths["/jobs/scan/scan_to_email"].post.parameters[0].schema.example;
        console.log(JSON.stringify(exampleUI));
        //console.log(".........." + JSON.stringify(exampleScanBody));
        App.Scan.buildObj(App.Scan.updatedpostObjUI, exampleUI, "");
        //App.Scan.buildObj(exampleScanBody, exampleUI);

        if (App.currentScreen !== 'sectionPrintScreen') {
            $('#WebAPI_Home').addClass('hide');
            $("#sectionPrintScreen").removeClass("hide");
            //App.scanPreview.show();
            $(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code017"));
        }


        App.Util.serverRequest(App.URL.multiDirect_Print, "POST", true, function (response, error) {
            if (response) {
                console.log("multiDirect_Print Success...!!!");

                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code038"));
                App.MultiDirect_Print.printWFID = response.WFID;
                console.log("printWFID : " + App.MultiDirect_Print.printWFID);

            } else {
                console.log("multiDirect_Print Fail...!!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code038") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code021 " + "Error : " + error.error));
            }

        }, exampleUI);

    });


    /* ----------------------------------------------  Cancel -------------------------------------------*/
    $("#cancel-print").click(function () {
        console.log("Cancel Printing click event...!!");
        App.Util.serverRequest(App.URL.printJob + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Cancel Printing..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code040"));

            } else {
                console.log("Failed to Cancel print...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code041") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code024"));
            }
        }, {
            "job_action": "cancel"
        });
    });


    /* ---------------------------------------------- Resume  -------------------------------------------*/
    $("#resume-print").click(function () {
        console.log("Resume Scanning click event...!!");
        App.Util.serverRequest(App.URL.printJob + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Resume Printing..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code042"));
            } else {
                console.log("Failed to Resume print...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code043") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code026"));
            }
        }, {
            "job_action": "resume"
        });
    });


    /* ---------------------------------------------- Back_to_Home -------------------------------------------*/
    $("#back_to_home_print").click(function () {
        //alert(App.EventReceiver.eventReceiver.status);
        $("#WebAPI_main_screen").addClass('show-main-screen');
        if (App.EventReceiver.eventReceiver.eventName !== "jobs_completed") {
            var r = confirm("Job is not yet completed, Are you sure you want to go back to home screen?");
            if (r == true) {
                console.log("Back_to_Home ....!!");
                //$('#accordion').empty();
                // $('#collapse_accordionDefault > .panel-body > .row').empty();
                if (App.currentScreen !== 'WebAPI_Home') {
                    $("#sectionPrintScreen").addClass("hide");
                    $("#myNav").addClass("overlay_hide");
                    $('#WebAPI_Home').removeClass('hide');
                    closeNav();
                }
            } else {
                return false;
            }
        } else {
            console.log("inside else Back_to_Home ....!!");
            //$('#accordion').empty();
            //$('#collapse_accordionDefault > .panel-body > .row').empty();
            if (App.currentScreen !== 'WebAPI_Home') {
                $("#sectionPrintScreen").addClass("hide");
                $("#myNav").addClass("overlay_hide");
                $('#WebAPI_Home').removeClass('hide');
                closeNav();
            }
        }

        App.Scan.DefaultParams = [];
        App.Scan.keyValMapObj = {};
        App.Scan.postObjUI = {};
        App.Scan.postObjParent = {};
        App.Scan.updatedpostObjUI = {};

    });



    return {
        show: show,
    };

})(window, jQuery);