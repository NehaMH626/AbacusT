/* Copyright(c) 2015-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
App.EventReceiver = (function (global, $, undefined) {

    var previewPath;
    var pageNum;
    var totalCount = 0;
    var lastImgListVal;
    var get_jobID;

    var eventReceiver = function (data) {
        console.log("@eventssssssssssssss-----------" + JSON.stringify(data));
        App.EventReceiver.eventReceiver.eventName = data.event_name;
        App.EventReceiver.eventReceiver.status = data.job_status.status;
        App.EventReceiver.eventReceiver.status_reason = data.job_status.status_reason;
        App.EventReceiver.eventReceiver.job_type = data.job_status.job_type;


        // Event received in scan screen when paper is put or removed from the ADF.
        if (data.event_name === "device_adf_paper_changed") {

            if (data.paper_placed === true) {
                App.scanPreview.enableScreen();
                //                $("#scan-alert-msg").addClass("hide");
                //                $("#scan-start-btn").removeClass("disabled");


            } else {
                App.scanPreview.disableScreen();
                //                $("#scan-alert-msg").removeClass("hide");
                //                $("#scan-start-btn").addClass("disabled");
            }


        } else if (data.event_name === "jobs_page_scanned") {

            console.log("jobs_page_scanned event .....");
            App.EventReceiver.eventReceiver.get_jobID = data.job_status.job_id;
            console.log("get_jobID " + App.EventReceiver.eventReceiver.get_jobID);
            var page_scanned = data.page_num;
            console.log(page_scanned);
            $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code022") + page_scanned);


        } else if (data.event_name === "jobs_preview_img_created") {

            App.EventReceiver.totalCount++;
            App.EventReceiver.eventReceiver.previewPath = data.preview_url;
            App.EventReceiver.eventReceiver.pageNum = data.page_num;
            console.log("At jobs_preview_img_created event.... ");
            App.scanPreview.getScanData();
            if (App.EventReceiver.eventReceiver.pageNum >= 1) {

                var path = App.EventReceiver.eventReceiver.previewPath;
                console.log("Path :" + path);
                //                $('#img-holder').css('background', 'url(' + path + ')');
                App.scanPreview.previewSlider();


            }
        } else if (data.event_name === "jobs_suspended" && data.job_status.status === "suspended") {

            App.EventReceiver.eventReceiver.get_jobID = data.job_status.job_id;
            console.log("get_jobID " + App.EventReceiver.eventReceiver.get_jobID);
            $(".alert").removeClass("alert-success-msg").text(App.EventReceiver.eventReceiver.job_type +" : "+ App.EventReceiver.eventReceiver.status+ ", " +App.Util.getMessage("code052")+ App.EventReceiver.eventReceiver.status_reason);
            var imageList = $("#image-list");
            App.EventReceiver.eventReceiver.lastImgListVal = imageList.position().left;

        }

        // Event received in scan screen when scanning completes.
        else if (data.event_name === "jobs_completed" && data.job_status.status === "completed" && data.job_status.status_reason === "success") {           
            console.log("Job completed.");
            $(".alert").addClass("alert-success-msg").text(App.EventReceiver.eventReceiver.job_type + App.Util.getMessage("code037"));


        }


        // Event received in scan screen when scanning failed.
        else if (data.event_name === "jobs_completed" && data.job_status.status === "completed" && data.job_status.status_reason !== "success") {
            
            console.log("Job completed.");
            $(".alert").removeClass("alert-success-msg").text(App.EventReceiver.eventReceiver.job_type + App.Util.getMessage("code037") + " " + App.Util.getMessage("code052") + App.EventReceiver.eventReceiver.status_reason);

        }
    };

    return {
        eventReceiver: eventReceiver,
        previewPath: previewPath,
        pageNum: pageNum,
        totalCount: totalCount,
        lastImgListVal: lastImgListVal,
        get_jobID: get_jobID
            
    };
})(window, jQuery);
