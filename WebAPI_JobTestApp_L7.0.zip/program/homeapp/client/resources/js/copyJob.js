App.Copy = (function (global, $, undefined) {

    var getDefaultParams_copy;
    var copyWFID;
    var exampleUI = {};

    $("#copyJob-btn").on("click", function () {
        
        console.log("at copy job ...!!");
        hideHomeScreen();
        $("#btn-start").html("<button type='button' class='btn btn-success btn-small start-btn' id='start-btn-copyJob'>Start Job >></button>");
        $("#get-storage-fileList").remove();
        $("#get-appConv-fileList").remove();

        // var copyBody = App.paths["/jobs/copy"].post.parameters[0].schema.allOf[1].properties;
        // var copyRequiredBody = App.paths["/jobs/copy"].post.parameters[0].schema.allOf[0].properties;
        // console.log(JSON.stringify(copyRequiredBody));
        // console.log(JSON.stringify(copyBody));
        var traversingScanBody = App.paths["/jobs/copy"].post.parameters[0].schema.allOf;
        App.Util.serverRequest(App.URL.copyJob, 'GET', false, function (response, error) {
            if (response) {
                console.log("GET_Success:" + JSON.stringify(response));
                App.Scan.traverse_it(response);
                getDefaultParams_copy = App.Scan.DefaultParams.push(App.Scan.keyValMapObj);
                console.log('getDefaultValues Keyvaluemap obj is' + JSON.stringify(App.Scan.DefaultParams));

            } else {
                console.log("@copy_Job" + error.xhr.status + error.xhr.responseText);
            }
        });

        //console.log("value in obj is" + App.Scan.DefaultParams[0].auto_event);
        // App.Scan._parseSwaggerRequiredParam(copyRequiredBody, App.Scan.DefaultParams);
        // App.Scan._parseSwagger(copyBody, App.Scan.DefaultParams);

        // App.Scan._parseSwaggerRequiredParamPostBody(copyRequiredBody);
        // App.Scan._parseSwaggerPostBody(copyBody);
        // console.log("getting post body data " + JSON.stringify(App.Scan.postObjUI));
        // console.log("parent obj is " + JSON.stringify(App.Scan.postObjParent));
        App.Scan._parseInitialProps(traversingScanBody);
        App.Scan._comparePostObj(App.Scan.postObjUI, App.Scan.postObjParent);
        //console.log("@@@@@@@@@@@@@Updated parent obj is " + JSON.stringify(App.Scan.updatedpostObjUI));

    });



    $('body').on('click', '#start-btn-copyJob', function () {

        console.log("Start copy job...");
        var exampleScanBody = App.paths["/jobs/copy"].post.parameters[0].schema.example;
        console.log(JSON.stringify(exampleUI));

        App.Scan.buildObj(App.Scan.updatedpostObjUI, exampleUI, "");
        //App.Scan.buildObj(exampleScanBody, exampleUI);

        if (App.currentScreen !== 'sectionCopyScreen') {
            $('#WebAPI_Home').addClass('hide');
            $("#sectionCopyScreen").removeClass("hide");
            $(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code017"));
            App.scanPreview.show();

        }


        App.Util.serverRequest(App.URL.copyJob, "POST", true, function (response, error) {
            if (response) {
                console.log("Copy job Success...!!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code035"));
                //                App.Copy.copyWFID = response.WFID;
                //                console.log("scanWFID : " + App.Copy.copyWFID);

            } else {
                console.log("Scanning Fail...!!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code036") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code036"));
            }
        }, exampleUI);

    });


    /* ---------------------------------------------- Scan Finish -------------------------------------------*/
    $("#finish-copy").click(function () {
        console.log("Finish Copy click event...!!");
        App.Util.serverRequest(App.URL.copyJob + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Finish copying..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code019"));

            } else {
                console.log("Failed to finish copy...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code021") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code021"));
            }
        }, {
            "job_action": "finish"
        });

    });


    /* ----------------------------------------------  Cancel -------------------------------------------*/
    $("#cancel-copy").click(function () {
        console.log("Cancel Copying click event...!!");
        App.Util.serverRequest(App.URL.copyJob + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Cancel Copying..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code023"));

            } else {
                console.log("Failed to Cancel copy...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code024") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code024"));
            }
        }, {
            "job_action": "cancel"
        });
    });


    /* ---------------------------------------------- Resume  -------------------------------------------*/
    $("#resume-copy").click(function () {
        console.log("Resume Copying click event...!!");
        App.Util.serverRequest(App.URL.copyJob + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Resume Copying..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code025"));
            } else {
                console.log("Failed to Resume copy...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code026") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code026"));
            }
        }, {
            "job_action": "resume"
        });
    });


    /* ---------------------------------------------- Suspend -------------------------------------------*/
    $("#suspend-copy").click(function () {
        console.log("Suspend Copying click event...!!");
        App.Util.serverRequest(App.URL.copyJob + "/" + App.EventReceiver.eventReceiver.get_jobID, "PATCH", true, function (response, error) {
            if (response) {
                console.log("Suspend Copying..!!");
                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code027"));
            } else {
                console.log("Failed to Resume copy...!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code028") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code028"));
            }
        }, {
            "job_action": "stop"
        });
    });

    /* ---------------------------------------------- Back_to_Home -------------------------------------------*/
    $("#back_to_home_copy").click(function () {
        $("#WebAPI_main_screen").addClass('show-main-screen');
        //alert(App.EventReceiver.eventReceiver.status);        
        if (App.EventReceiver.eventReceiver.eventName !== "jobs_completed") {
            var r = confirm("Job is not yet completed, Are you sure you want to go back to home screen?");
            if (r == true) {
                console.log("Back_to_Home ....!!");
                //$('#accordion').empty();
                // $('#collapse_accordionDefault > .panel-body > .row').empty();
                if (App.currentScreen !== 'WebAPI_Home') {
                    $("#sectionCopyScreen").addClass("hide");
                    $("#myNav").addClass("overlay_hide");
                    $('#WebAPI_Home').removeClass('hide');
                    closeNav();
                }
            } else {
                return false;
            }
        } else {
            console.log("inside else Back_to_Home ....!!");
            //$('#accordion').empty();
            //$('#collapse_accordionDefault > .panel-body > .row').empty();
            if (App.currentScreen !== 'WebAPI_Home') {
                $("#sectionCopyScreen").addClass("hide");
                $("#myNav").addClass("overlay_hide");
                $('#WebAPI_Home').removeClass('hide');
                closeNav();
            }
        }

        App.Scan.DefaultParams = [];
        App.Scan.keyValMapObj = {};
        App.Scan.postObjUI = {};
        App.Scan.postObjParent = {};
        App.Scan.updatedpostObjUI = {};

    });


})(window, jQuery);
