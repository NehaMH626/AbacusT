/* Copyright(c) 2015-2017 TOSHIBA TEC CORPORATION, All Rights Reserved. */
App.URL = (function (global, $, undefined) {

    var _webapiContextRoot = "http://embapp-local.toshibatec.co.jp:50187/v1.0";
    var _servletBaseURL = "/server/1abe1f58-068b-11e6-9463-008091aec8b8";

    var languageURL = _webapiContextRoot + "/session/current";
    var eventSubscriptionURL = _webapiContextRoot + "/subscription/eventstream";
    var deviceStatusEventSubscriptionURL = _webapiContextRoot + "/subscription/eventstream/mfpdevice/status";
    var jobEventSubscriptionURL = _webapiContextRoot + "/subscription/eventstream/jobs";
    var scanToAppURL = _webapiContextRoot + "/jobs/scan/scan_to_app";
    var ADFStatusURL = _webapiContextRoot + "/mfpdevice/scanner/adf";
    var deleteAppStorageFiles = _webapiContextRoot + "/app/storage/self?type=normal";
    var getAppStorageFiles = _webapiContextRoot + "/app/storage/self/files?storage_type=normal";
    var getScan = _webapiContextRoot + "/jobs/scan";
    var scan_to_file = _webapiContextRoot + "/jobs/scan/scan_to_file";
    var scan_to_email = _webapiContextRoot + "/jobs/scan/scan_to_email";
    var scan_to_usb = _webapiContextRoot + "/jobs/scan/scan_to_usb";
    var copyJob = _webapiContextRoot + "/jobs/copy";
    var multiDirect_Print = _webapiContextRoot + "/jobs/print/multi_direct_print";
    var direct_Print = _webapiContextRoot + "/jobs/print/direct_print";
    var spool_Print = _webapiContextRoot + "/jobs/print/spool_print";
    var printJob = _webapiContextRoot + "/jobs/print/";
    var appConv = _webapiContextRoot + "/jobs/appconv";
    var appSendEmail = _webapiContextRoot + "/jobs/appsend/email";
    var appSendFtp = _webapiContextRoot + "/jobs/appsend/ftp";
    var appSendSamba = _webapiContextRoot + "/jobs/appsend/samba";
    var appConvFiles = _webapiContextRoot + "/jobs/appconv/files";

    return {
        languageURL: languageURL,
        eventSubscriptionURL: eventSubscriptionURL,
        deviceStatusEventSubscriptionURL: deviceStatusEventSubscriptionURL,
        jobEventSubscriptionURL: jobEventSubscriptionURL,
        ADFStatusURL: ADFStatusURL,
        scanToAppURL: scanToAppURL,
        deleteAppStorageFiles: deleteAppStorageFiles,
        getScan: getScan,
        scan_to_file: scan_to_file,
        scan_to_email: scan_to_email,
        scan_to_usb: scan_to_usb,
        copyJob: copyJob,
        multiDirect_Print: multiDirect_Print,
        direct_Print: direct_Print,
        spool_Print: spool_Print,
        printJob: printJob,
        getAppStorageFiles: getAppStorageFiles,
        appConv: appConv,
        appSendEmail: appSendEmail,
        appSendFtp: appSendFtp,
        appSendSamba: appSendSamba,
        appConvFiles: appConvFiles

    };

})(window, jQuery);
