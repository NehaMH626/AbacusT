App.Appsend_FTP = (function (global, $, undefined) {

    var getDefaultParams_appSendFtp;
    var appSendFtp_WFID;
    var exampleUI = {};


    var show = function () {
        console.log("@ appSendFtp....");
    };


    $("#appsend-ftp-btn").on("click", function () {
         hideHomeScreen();
        show();
        $("#btn-start").html("<button type='button' class='btn btn-success btn-small start-btn' id='start-btn-appSendFtp'>Start Job >></button>");
        $("#get-storage-fileList").remove();
        $("#get-appConv-fileList").remove();


        // var appSendFtpBody = App.paths["/jobs/appsend/ftp"].post.parameters[0].schema.allOf[1].properties;
        // var appSendFtpRequiredBody = App.paths["/jobs/appsend/ftp"].post.parameters[0].schema.allOf[0].properties;
        // console.log(JSON.stringify(appSendFtpRequiredBody));
        // console.log(JSON.stringify(appSendFtpBody));
        var traversingScanBody = App.paths["/jobs/appsend/ftp"].post.parameters[0].schema.allOf;
        App.Util.serverRequest(App.URL.appSendFtp, 'GET', false, function (response, error) {
            if (response) {
                console.log("GET_Success:" + JSON.stringify(response));
                App.Scan.traverse_it(response);
                getDefaultParams_appSendFtp = App.Scan.DefaultParams.push(App.Scan.keyValMapObj);
                console.log('getDefaultValues Keyvaluemap obj is' + JSON.stringify(App.Scan.DefaultParams));

            } else {
                console.log("@appSendFtp" + error.xhr.status + error.xhr.responseText);
            }
        });

        //console.log("value in obj is" + App.Scan.DefaultParams[0].auto_event);
        // App.Scan._parseSwaggerRequiredParam(appSendFtpRequiredBody, App.Scan.DefaultParams);
        // App.Scan._parseSwagger(appSendFtpBody, App.Scan.DefaultParams);

        // App.Scan._parseSwaggerRequiredParamPostBody(appSendFtpRequiredBody);
        // App.Scan._parseSwaggerPostBody(appSendFtpBody);
        App.Scan._parseInitialProps(traversingScanBody);
        App.Scan._comparePostObj(App.Scan.postObjUI, App.Scan.postObjParent);
        // console.log("getting post body data " + JSON.stringify(App.Scan.postObjUI));
        // console.log("parent obj is " + JSON.stringify(App.Scan.postObjParent));
        // console.log("@@@@@@@@@@@@@Updated parent obj is " + JSON.stringify(App.Scan.updatedpostObjUI));

    });


    $('body').on('click', '#start-btn-appSendFtp', function () {

        console.log("Start appSendFtp job...");
        //var exampleScanBody = App.paths["/jobs/scan/scan_to_email"].post.parameters[0].schema.example;
        console.log(JSON.stringify(exampleUI));
        //console.log(".........." + JSON.stringify(exampleScanBody));
        App.Scan.buildObj(App.Scan.updatedpostObjUI, exampleUI, "");
        //App.Scan.buildObj(exampleScanBody, exampleUI);

        if (App.currentScreen !== 'sectionAppconvScreen') {
            $('#WebAPI_Home').addClass('hide');
            $("#sectionAppconvScreen").removeClass("hide");
            //App.scanPreview.show();
            $(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code017"));
        }


        App.Util.serverRequest(App.URL.appSendFtp, "POST", true, function (response, error) {
            if (response) {
                console.log("appSendFtp Success...!!!");

                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code048"));
                appSendFtp_WFID = response.WFID;
                console.log("appSendFTP_WFID : " + appSendFtp_WFID);

            } else {
                console.log("appSendFtp Fail...!!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code049") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code021 " + "Error : " + error.error));
            }
        }, exampleUI);
    });

    
    return {
        show: show,
    };

})(window, jQuery);
