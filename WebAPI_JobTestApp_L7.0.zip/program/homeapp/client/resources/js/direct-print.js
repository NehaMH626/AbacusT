App.Direct_Print = (function (global, $, undefined) {

    var getDefaultParams_directPrint;
    var printWFID;
    var exampleUI = {};


    var show = function () {

        console.log("@ directPrint....");

    };


    $("#dirPrint-btn").on("click", function () {
        hideHomeScreen();
        App.Scan.allOfObj = 0;
        $("#btn-start").html("<button type='button' class='btn btn-success btn-small start-btn' id='start-btn-directPrint'>Start Job >></button>");
        $("#get-appConv-fileList").remove();
        
        $("#storage-fileList").html("<button type='button' class='btn btn-success btn-small appStorage-list' id='get-storage-fileList'>App_Storage Files >></button>");

        // var printBody = App.paths["/jobs/print/direct_print"].post.parameters[0].schema.allOf[1].properties;
        // var printRequiredBody = App.paths["/jobs/print/direct_print"].post.parameters[0].schema.allOf[0].properties;
        // console.log(JSON.stringify(printRequiredBody));
        // console.log(JSON.stringify(printBody));
        var traversingScanBody = App.paths["/jobs/print/direct_print"].post.parameters[0].schema.allOf;
        App.Util.serverRequest(App.URL.direct_Print, 'GET', false, function (response, error) {
            if (response) {
                console.log("GET_Success:" + JSON.stringify(response));
                App.Scan.traverse_it(response);
                getDefaultParams_directPrint = App.Scan.DefaultParams.push(App.Scan.keyValMapObj);
                console.log('getDefaultValues Keyvaluemap obj is' + JSON.stringify(App.Scan.DefaultParams));

            } else {
                console.log("@directPrint" + error.xhr.status + error.xhr.responseText);
            }
        });

        // console.log("value in obj is" + App.Scan.DefaultParams[0].auto_event);
        // App.Scan._parseSwaggerRequiredParam(printRequiredBody, App.Scan.DefaultParams);
        // App.Scan._parseSwagger(printBody, App.Scan.DefaultParams);

        // App.Scan._parseSwaggerRequiredParamPostBody(printRequiredBody);
        // App.Scan._parseSwaggerPostBody(printBody);
        App.Scan._parseInitialProps(traversingScanBody);
        App.Scan._comparePostObj(App.Scan.postObjUI, App.Scan.postObjParent);
        
        // console.log("getting post body data " + JSON.stringify(App.Scan.postObjUI));
        // console.log("parent obj is " + JSON.stringify(App.Scan.postObjParent));
        // console.log("@@@@@@@@@@@@@Updated parent obj is " + JSON.stringify(App.Scan.updatedpostObjUI));

    });

    /* -------------- Modal Box Content ------------ */
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    //var btn_appStorage = document.getElementById("get-storage-fileList");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on the button, open the modal

    $('body').on('click', '#get-storage-fileList', function () {
        console.log("@ get app_storage list");
        modal.style.display = "block";
       
        App.Util.serverRequest(App.URL.getAppStorageFiles, "GET", true, function (response, error) {
            if (response) {
                console.log("Get App Storage Files.. Success!!");
                $("#fileList_Table > tbody").empty();
                //                $("#directory-table > tbody").append("<tr><td>" + response.storage_path_list + "</td></tr>");
                fileList = response["storage_path_list"].map(function (element) {
                    var elementObj = {};
                    elementObj.name = element;
                    return elementObj;

                });
                $.each(fileList, function (index, value) {
                    $("#fileList_Table > tbody").append("<tr><td>" + value.name + "</td></tr>");
                });
            } else {
                console.log("Get App Storage Files.. Fail!!");
            }
        });
    });


    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

    $('body').on('click', '#start-btn-directPrint', function () {

        console.log("Start directPrint job...");
        //var exampleScanBody = App.paths["/jobs/scan/scan_to_email"].post.parameters[0].schema.example;
        console.log(JSON.stringify(exampleUI));
        //console.log(".........." + JSON.stringify(exampleScanBody));
        App.Scan.buildObj(App.Scan.updatedpostObjUI, exampleUI, "");
        //App.Scan.buildObj(exampleScanBody, exampleUI);

        if (App.currentScreen !== 'sectionPrintScreen') {
            $('#WebAPI_Home').addClass('hide');
            $("#sectionPrintScreen").removeClass("hide");
            //App.scanPreview.show();
            $(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code017"));
        }


        App.Util.serverRequest(App.URL.direct_Print, "POST", true, function (response, error) {
            if (response) {
                console.log("direct_Print Success...!!!");

                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code038"));
                App.Spool_Print.printWFID = response.WFID;
                console.log("printWFID : " + App.Spool_Print.printWFID);

            } else {
                console.log("direct_Print Fail...!!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code038") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code021 " + "Error : " + error.error));
            }
        }, exampleUI);
    });


    return {
        show: show,
    };

})(window, jQuery);