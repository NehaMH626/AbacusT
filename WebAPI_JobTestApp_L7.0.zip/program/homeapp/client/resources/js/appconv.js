App.AppConv = (function (global, $, undefined) {

    var getDefaultParams_appConv;
    var appConv_WFID;
    var exampleUI = {};


    var show = function () {
        console.log("@ appConv....");
    };


    $("#appConv-btn").on("click", function () {
        hideHomeScreen();
        show();
        $("#btn-start").html("<button type='button' class='btn btn-success btn-small start-btn' id='start-btn-appConv'>Start Job >></button>");
        $("#get-storage-fileList").remove();

        $("#storage-fileList").html("<button type='button' class='btn btn-success btn-small appStorage-list' id='get-appConv-fileList'>AppConv Files >></button>");



        // var appConvBody = App.paths["/jobs/appconv"].post.parameters[0].schema.allOf[1].properties;
        // var appConvRequiredBody = App.paths["/jobs/appconv"].post.parameters[0].schema.allOf[0].properties;
        // console.log(JSON.stringify(appConvRequiredBody));
        // console.log(JSON.stringify(appConvBody));
        var traversingScanBody = App.paths["/jobs/appconv"].post.parameters[0].schema.allOf;
        App.Util.serverRequest(App.URL.appConv, 'GET', false, function (response, error) {
            if (response) {
                console.log("GET_Success:" + JSON.stringify(response));
                App.Scan.traverse_it(response);
                getDefaultParams_appConv = App.Scan.DefaultParams.push(App.Scan.keyValMapObj);
                console.log('getDefaultValues Keyvaluemap obj is' + JSON.stringify(App.Scan.DefaultParams));

            } else {
                console.log("@appConv" + error.xhr.status + error.xhr.responseText);
            }
        });

        // console.log("value in obj is" + App.Scan.DefaultParams[0].auto_event);
        // App.Scan._parseSwaggerRequiredParam(appConvRequiredBody, App.Scan.DefaultParams);
        // App.Scan._parseSwagger(appConvBody, App.Scan.DefaultParams);

        // App.Scan._parseSwaggerRequiredParamPostBody(appConvRequiredBody);
        // App.Scan._parseSwaggerPostBody(appConvBody);
        App.Scan._parseInitialProps(traversingScanBody);
        App.Scan._comparePostObj(App.Scan.postObjUI, App.Scan.postObjParent);
        // console.log("getting post body data " + JSON.stringify(App.Scan.postObjUI));
        // console.log("parent obj is " + JSON.stringify(App.Scan.postObjParent));
        // console.log("@@@@@@@@@@@@@Updated parent obj is " + JSON.stringify(App.Scan.updatedpostObjUI));

    });


    $('body').on('click', '#start-btn-appConv', function () {

        console.log("Start appConv job...");
        //var exampleScanBody = App.paths["/jobs/scan/scan_to_email"].post.parameters[0].schema.example;
        console.log(JSON.stringify(exampleUI));
        //console.log(".........." + JSON.stringify(exampleScanBody));
        App.Scan.buildObj(App.Scan.updatedpostObjUI, exampleUI, "");
        //App.Scan.buildObj(exampleScanBody, exampleUI);

        if (App.currentScreen !== 'sectionAppconvScreen') {
            $('#WebAPI_Home').addClass('hide');
            $("#sectionAppconvScreen").removeClass("hide");
            //App.scanPreview.show();
            //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code017"));
        }


        App.Util.serverRequest(App.URL.appConv, "POST", true, function (response, error) {
            if (response) {
                console.log("appConv Success...!!!");

                $(".alert").addClass("alert-success-msg").text(App.Util.getMessage("code044"));
                appConv_WFID = response.WFID;
                console.log("appConv_WFID : " + appConv_WFID);

            } else {
                console.log("appConv Fail...!!!");
                $(".alert").removeClass("alert-success-msg").html(App.Util.getMessage("code045") + "<br />" + " Error : " + error.xhr.responseText);
                //$(".alert").removeClass("alert-success-msg").text(App.Util.getMessage("code021 " + "Error : " + error.error));
            }
        }, exampleUI);
    });


    /* -------------- Modal Box Content ------------ */
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    //var btn_appStorage = document.getElementById("get-storage-fileList");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on the button, open the modal

    $('body').on('click', '#get-appConv-fileList', function () {
        console.log("@ get appconv file list");
        modal.style.display = "block";
        
        App.Util.serverRequest(App.URL.appConvFiles, "GET", true, function (response, error) {
            if (response) {
                console.log("Get appconv Files.. Success!!");
                $("#fileList_Table > tbody").empty();
                //                $("#directory-table > tbody").append("<tr><td>" + response.storage_path_list + "</td></tr>");
                fileList = response["storage_path_list"].map(function (element) {
                    var elementObj = {};
                    elementObj.name = element;
                    return elementObj;

                });
                $.each(fileList, function (index, value) {
                    $("#fileList_Table > tbody").append("<tr><td>" + value.name + "</td></tr>");
                });
            } else {
                console.log("Get appconv Files.. Fail!!");
            }
        });
    });


    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }



    /* ---------------------------------------------- Back_to_Home -------------------------------------------*/
    $("#back_to_home_appconv").click(function () {
        $("#WebAPI_main_screen").addClass('show-main-screen');
        //alert(App.EventReceiver.eventReceiver.status);        
        if (App.EventReceiver.eventReceiver.eventName !== "jobs_completed") {
            var r = confirm("Job is not yet completed, Are you sure you want to go back to home screen?");
            if (r == true) {
                console.log("Back_to_Home ....!!");
                //$('#accordion').empty();
                // $('#collapse_accordionDefault > .panel-body > .row').empty();
                if (App.currentScreen !== 'WebAPI_Home') {
                    $("#sectionAppconvScreen").addClass("hide");
                    $("#myNav").addClass("overlay_hide");
                    $('#WebAPI_Home').removeClass('hide');
                    closeNav();
                }
            } else {
                return false;
            }
        } else {
            console.log("inside else Back_to_Home ....!!");
            //$('#accordion').empty();
            //$('#collapse_accordionDefault > .panel-body > .row').empty();
            if (App.currentScreen !== 'WebAPI_Home') {
                $("#sectionAppconvScreen").addClass("hide");
                $("#myNav").addClass("overlay_hide");
                $('#WebAPI_Home').removeClass('hide');
                closeNav();
            }
        }

        App.Scan.DefaultParams = [];
        App.Scan.keyValMapObj = {};
        App.Scan.postObjUI = {};
        App.Scan.postObjParent = {};
        App.Scan.updatedpostObjUI = {};

    });


    return {
        show: show,
    };

})(window, jQuery);
